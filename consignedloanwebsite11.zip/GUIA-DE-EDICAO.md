# Guia de Edição - Site UP Soluções

Este guia mostra como fazer alterações simples no site da UP Soluções.

## 📋 Índice
1. [Como Alterar o Banner Principal](#1-como-alterar-o-banner-principal)
2. [Como Mudar Textos e Cores](#2-como-mudar-textos-e-cores)
3. [Como Alterar Informações de Contato](#3-como-alterar-informações-de-contato)
4. [Como Adicionar ou Remover Serviços](#4-como-adicionar-ou-remover-serviços)
5. [Como Trocar Imagens](#5-como-trocar-imagens)
6. [Como Gerenciar Depoimentos](#6-como-gerenciar-depoimentos)
7. [Páginas com Imagens](#7-páginas-com-imagens)
8. [Banners Especiais](#8-banners-especiais)
9. [Página de Contato](#9-página-de-contato)
10. [Guia Completo de Imagens](#10-guia-completo-de-imagens)
11. [Como Trocar Logos dos Bancos Parceiros](#11-como-trocar-logos-dos-bancos-parceiros)
12. [Mapa Completo de Todas as Imagens por Página](#12-mapa-completo-de-todas-as-imagens-por-página)

---

## 1. Como Alterar o Banner Principal

### Banner da Página Inicial
**Arquivo:** `components/hero-principal.tsx`

O banner principal da página inicial tem:
- Título com gradiente: "Crédito Consignado"
- Subtítulo explicativo
- Cards flutuantes com valores e taxas
- Imagem de casal de aposentados
- Estatísticas (+10.000 clientes, 10 anos, 98% aprovação)

Para alterar o título:
```tsx
<span className="bg-gradient-to-r from-secondary via-emerald-400 to-secondary bg-clip-text text-transparent">
  Consignado  // <- Altere esta palavra
</span>
```

Para alterar as estatísticas:
```tsx
{ value: "+10.000", label: "Clientes Atendidos" },  // <- Altere aqui
{ value: "10 Anos", label: "De Experiência" },
{ value: "98%", label: "Taxa de Aprovação" },
```

### Banner da Página de Serviços (Cartão Consignado)
**Arquivo:** `components/hero-servicos.tsx`

O banner da página de serviços é sobre **Cartão Consignado** e tem:
- Fundo gradiente roxo/violeta
- Título "Cartão Consignado" com gradiente amarelo
- Cards de benefícios (Anuidade Zero, Limite Alto, etc.)
- Imagem de aposentado com cartão
- Cards flutuantes mostrando limite e aprovação

Para alterar o título:
```tsx
<span className="bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 bg-clip-text text-transparent">
  Consignado  // <- Altere esta palavra
</span>
```

Para alterar os benefícios:
```tsx
{ icon: Gift, label: "Anuidade Zero", desc: "Sem taxas escondidas" },  // <- Altere aqui
{ icon: Wallet, label: "Limite Alto", desc: "Até 1,6x o benefício" },
```

---

## 2. Como Mudar Textos e Cores

### Cores do site:
**Arquivo:** `app/globals.css`

As cores estão definidas nas linhas iniciais:
```css
--primary: 217 91% 60%;        /* Azul principal */
--secondary: 142 76% 36%;      /* Verde secundário */
--background: 0 0% 100%;       /* Branco */
```

Para alterar uma cor, modifique os valores. O formato é: `matiz saturação luminosidade`.

**Exemplo:** Para um azul mais escuro, mude a luminosidade:
```css
--primary: 217 91% 45%;  /* Azul mais escuro */
```

### Alterar textos das páginas:

- **Página Inicial:** `app/page.tsx`
- **Serviços:** `components/services.tsx`
- **Vantagens:** `components/benefits.tsx`
- **Sobre Nós:** `components/about.tsx`
- **Contato:** `components/contact.tsx`

Abra o arquivo desejado e procure pelo texto que quer alterar entre aspas `""`.

---

## 3. Como Alterar Informações de Contato

**Arquivo:** `components/contact.tsx`

### Alterar endereço:
Procure por (aproximadamente linha 80):
```tsx
<p className="text-base leading-relaxed">
  R. Érico Veríssimo 2340<br />
  Santa Mônica, Belo Horizonte - MG
</p>
```

### Alterar telefone:
Procure por (aproximadamente linha 96):
```tsx
<p className="text-base font-medium">(31) 98219-0475</p>
```

**IMPORTANTE:** Também altere nos seguintes arquivos:
- **Botão WhatsApp flutuante:** `components/whatsapp-button.tsx` (linha 6)
- **Banner promocional:** `components/hero-principal.tsx` (linha 7)
- **Banner de serviços:** `components/hero-servicos.tsx` (linha 7)

### Alterar horário de funcionamento:
Procure por (aproximadamente linha 111):
```tsx
<p className="text-base leading-relaxed">
  Segunda a Sexta: 9h às 17h
</p>
```

### Alterar email:
Procure por (aproximadamente linha 125):
```tsx
<p className="text-base font-medium">contato@upsolucoes.com.br</p>
```

---

## 4. Como Adicionar ou Remover Serviços

**Arquivo:** `components/services.tsx`

Os serviços estão em um array (aproximadamente linha 5):
```tsx
const services = [
  {
    icon: CreditCard,
    title: "Empréstimo Consignado INSS",
    description: "Crédito com desconto direto no benefício...",
    features: ["Taxas a partir de 1,80% a.m.", "Até 84 meses..."],
  },
  // ... mais serviços
]
```

### Para adicionar um novo serviço:
Copie um bloco completo (de `{` até `},`) e cole antes do fechamento do array `]`. Depois altere os dados:
```tsx
{
  icon: CreditCard,  // Ícone (não mexa se não souber)
  title: "Novo Serviço",  // Nome do serviço
  description: "Descrição do serviço aqui",
  features: ["Benefício 1", "Benefício 2", "Benefício 3"],
},
```

### Para remover um serviço:
Delete todo o bloco (de `{` até `},`) do serviço que deseja remover.

---

## 5. Como Trocar Imagens

### Imagens nas páginas principais:

As imagens usam placeholders que podem ser substituídos por imagens reais. Para trocar:

1. Adicione sua nova imagem na pasta `public/` com um nome simples (ex: `minha-imagem.jpg`)
2. Encontre o componente `<Image>` no arquivo desejado
3. Altere o `src` de `/placeholder.svg?...` para `/minha-imagem.jpg`
4. Altere o `alt` para descrever a nova imagem

### Logo da empresa:
**Arquivo:** `components/header.tsx`

Procure por (aproximadamente linha 24):
```tsx
<Image 
  src="/up-solucoes-logo.png" 
  alt="UP Soluções" 
  ...
/>
```

1. Adicione a nova logo na pasta `public/` (ex: `novo-logo.png`)
2. Altere o `src` para: `src="/novo-logo.png"`

---

## 6. Como Gerenciar Depoimentos

### 🔐 Acessar o Painel Administrativo

1. Acesse: `https://seusite.com/admin/depoimentos`
2. A senha padrão é: **admin123**
3. **IMPORTANTE:** Altere a senha assim que possível!

### Como Alterar a Senha de Administrador

Execute este comando SQL no banco de dados Supabase:
```sql
UPDATE admin_users 
SET senha = crypt('NOVA_SENHA_AQUI', gen_salt('bf')) 
WHERE username = 'admin';
```

### 📝 Gerenciar Depoimentos (Painel Admin)

No painel administrativo você pode:

1. **Aprovar Depoimentos** - Clique no botão "Aprovar" nos depoimentos pendentes
2. **Reprovar Depoimentos** - Clique no botão "Reprovar" para rejeitar
3. **Editar Depoimentos** - Clique em "Editar" para modificar o texto ou nome
4. **Excluir Depoimentos** - Clique no ícone de lixeira para deletar permanentemente

---

## 7. Fotos da Empresa (Página Principal)

### Seção de Fotos Logo Abaixo do Banner
**Arquivo:** `components/fotos-empresa.tsx`

Esta seção aparece logo após o banner principal e mostra 4 fotos da empresa:
- Nosso Escritório
- Nossa Equipe
- Atendimento
- Recepção

Para trocar as fotos, encontre o array `fotosEmpresa`:
```tsx
const fotosEmpresa = [
  {
    src: "/images/escritorio.jpg",  // <- Altere o caminho da imagem
    alt: "Escritório moderno",       // <- Descrição para acessibilidade
    titulo: "Nosso Escritório",      // <- Título exibido
    descricao: "Ambiente moderno",   // <- Descrição curta
    icon: Building2,                 // <- Ícone (não mexa)
  },
  // ... mais fotos
]
```

### Galeria da Empresa (Parte Inferior)
**Arquivo:** `components/galeria-empresa.tsx`

Esta seção aparece mais abaixo na página com mais fotos e cards de informações.

---

## 8. Banners Especiais

### Banner de Margem Extra (`/margem-extra`)
**Arquivo:** `components/banner-margem-extra.tsx`

O banner da página Margem Extra foi modernizado com:
- Gradiente vibrante azul/verde (cores da marca)
- Elementos decorativos animados (ícones flutuantes)
- Badge chamativo com animação
- Destaque visual do percentual (5% EXTRA)
- Botão com gradiente amarelo/laranja
- Imagem ilustrativa de aposentado feliz

Para alterar o texto do banner:
- Título: procure por `Margem Extra` e `Liberada!`
- Percentual: procure por `ATÉ 5% EXTRA`
- Descrição: procure pelo parágrafo abaixo do percentual

### Banner de Serviços/Cartão Consignado (`/servicos`)
**Arquivo:** `components/hero-servicos.tsx`

O banner foi redesenhado com tema de **Cartão Consignado**:
- Fundo gradiente roxo/violeta elegante
- Título "Cartão Consignado" com gradiente amarelo/laranja
- Badge "NOVO! Cartão Consignado"
- Cards de benefícios: Anuidade Zero, Limite Alto, 100% Seguro, Juros Baixos
- Imagem de aposentado segurando cartão de crédito
- Cards flutuantes: "Cartão Aprovado!", limite R$ 4.500, "Anuidade GRÁTIS!"
- Botão "Solicitar Meu Cartão" em amarelo/laranja
- Trust badges: Sem anuidade, Aprovação facilitada, Saque disponível

Para alterar o limite exibido:
```tsx
<p className="text-3xl font-bold">R$ 4.500</p>  // <- Altere o valor
```

Para alterar o gradiente de fundo:
```tsx
<section className="... bg-gradient-to-br from-violet-950 via-purple-900 to-fuchsia-900">
```

---

## 9. Página de Contato

**Arquivo:** `components/contact.tsx`

A página de contato possui:
- Header com imagem de fundo da equipe de atendimento
- Cards de motivos para contato (Segurança, Atendimento, Certificação, Suporte)
- Formulário "Solicite uma Proposta" com campos e botão WhatsApp
- **Imagem abaixo do formulário** mostrando atendimento personalizado
- Informações de contato (endereço, telefone, email, horário)
- Card de WhatsApp para atendimento rápido
- Mapa de localização

### Para alterar a imagem abaixo do formulário:
Procure por:
```tsx
<Image
  src="/professional-team-helping-customer-with-financial-.jpg"
  alt="Equipe atendendo cliente"
/>
```

Troque o `src` para sua imagem e atualize o `alt`.

---

## 10. Guia Completo de Imagens

### 📸 MAPA DE TODAS AS IMAGENS DO SITE

Esta seção lista **TODAS** as imagens de cada página do site e como alterá-las.

---

### 🏠 PÁGINA PRINCIPAL (`/`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Banner Principal | `components/hero-principal.tsx` | Procure por `<Image src=` | Casal de aposentados celebrando |
| Fotos da Empresa (abaixo do banner) | `components/fotos-empresa.tsx` | Array `fotosEmpresa` | 4 fotos: escritório, equipe, atendimento, recepção |
| Galeria da Empresa (parte inferior) | `components/galeria-empresa.tsx` | Array `imagensEmpresa` | 4 imagens do escritório e equipe |

**Para trocar fotos da empresa (seção superior):**
```tsx
// Arquivo: components/fotos-empresa.tsx
const fotosEmpresa = [
  {
    src: "/images/escritorio.jpg",  // <- Altere aqui
    alt: "Escritório UP Soluções",
    titulo: "Nosso Escritório",
    descricao: "Ambiente moderno e acolhedor",
    icon: Building2,
  },
  // ... mais fotos
]
```

**Para trocar imagens da galeria da empresa (seção inferior):**
```tsx
// Arquivo: components/galeria-empresa.tsx
const imagensEmpresa = [
  {
    src: "/images/escritorio.jpg",  // <- Altere aqui
    alt: "Escritório UP Soluções",
    titulo: "Nosso Escritório",
  },
  // ... mais imagens
]
```

---

### 📋 PÁGINA DE SERVIÇOS / CARTÃO CONSIGNADO (`/servicos`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Banner Principal | `components/hero-servicos.tsx` | Procure por `<Image src=` | Aposentado segurando cartão de crédito |

**Para trocar:**
```tsx
// Arquivo: components/hero-servicos.tsx
<Image
  src="/images/sua-imagem.jpg"  // <- Altere aqui
  alt="Aposentado feliz com cartão consignado"
  width={520}
  height={520}
/>
```

---

### 💰 PÁGINA MARGEM EXTRA (`/margem-extra`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Banner Principal | `components/banner-margem-extra.tsx` | Procure por `<Image src=` | Aposentado feliz com margem aprovada |

**Para trocar:**
```tsx
// Arquivo: components/banner-margem-extra.tsx
<Image
  src="/images/aposentado-feliz.jpg"  // <- Altere aqui
  alt="Aposentado feliz com margem extra aprovada"
  width={550}
  height={550}
/>
```

---

### 🏢 PÁGINA SOBRE NÓS (`/sobre`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Imagem Principal | `components/about.tsx` | Primeiro `<Image>` | Equipe UP Soluções |
| Atendimento | `components/about.tsx` | Segundo `<Image>` | Atendimento personalizado |
| Estrutura | `components/about.tsx` | Terceiro `<Image>` | Escritório moderno |

---

### 📞 PÁGINA DE CONTATO (`/contato`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Header | `components/contact.tsx` | Procure por `backgroundImage` | Imagem de fundo do cabeçalho |
| Abaixo do Formulário | `components/contact.tsx` | Procure por `<Image src=` | Equipe atendendo cliente |

---

### 📚 PÁGINA DE GUIAS (`/guias`)

| Localização | Arquivo | Como Encontrar | Descrição |
|-------------|---------|----------------|-----------|
| Imagens dos Artigos | `components/guias-educacionais.tsx` | Array `blogs` | 6 imagens de capa dos artigos |

---

### 📣 PÁGINA DE DEPOIMENTOS (`/depoimentos`)

As imagens dos depoimentos são enviadas pelos clientes e gerenciadas pelo painel admin.

---

### 🖼️ LOGO DA EMPRESA

| Localização | Arquivo | Como Encontrar |
|-------------|---------|----------------|
| Cabeçalho | `components/header.tsx` | Procure por `up-solucoes-logo` |
| Rodapé | `components/footer.tsx` | Procure por `up-solucoes-logo` |

---

## 11. Como Trocar Logos dos Bancos Parceiros

**Arquivo:** `components/secao-confianca.tsx`

A seção de bancos parceiros exibe os logos dos bancos com os quais a UP Soluções trabalha.

### Estrutura dos Bancos:
```tsx
const bancosParceiros = [
  {
    nome: "BMG",                    // Nome do banco
    cor: "from-orange-500 to-orange-600",  // Cor do efeito glow
    textoCor: "text-white",
    logo: "URL_DA_LOGO",           // <- ALTERE ESTA URL PARA TROCAR A LOGO
    bgColor: "bg-white",
  },
  // ... mais bancos
]
```

### Para trocar um logo de banco:

**Opção 1: Usando URL externa (Wikipedia ou site oficial)**
```tsx
logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Banco_BMG_logo.svg/1200px-Banco_BMG_logo.svg.png",
```

**Opção 2: Usando imagem local**
1. Salve a logo na pasta `public/images/bancos/` (ex: `bmg-logo.png`)
2. Altere o campo `logo` para:
```tsx
logo: "/images/bancos/bmg-logo.png",
```

### URLs de Logos Oficiais dos Bancos Atuais:

| Banco | URL da Logo |
|-------|-------------|
| BMG | `https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Banco_BMG_logo.svg/1200px-Banco_BMG_logo.svg.png` |
| Santander | `https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Banco_Santander_Logotipo.svg/2560px-Banco_Santander_Logotipo.svg.png` |
| Daycoval | `https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Banco_Daycoval_logo.svg/1200px-Banco_Daycoval_logo.svg.png` |
| Master | `https://www.bancomaster.com.br/assets/images/logo-banco-master.svg` |
| PAN | `https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Banco_Pan_logo.svg/2560px-Banco_Pan_logo.svg.png` |

### Para adicionar um novo banco:
Copie um bloco completo e altere os dados:
```tsx
{
  nome: "Novo Banco",
  cor: "from-blue-500 to-blue-600",  // Cores do gradiente
  textoCor: "text-white",
  logo: "/images/bancos/novo-banco-logo.png",  // <- Sua imagem
  bgColor: "bg-white",
},
```

### Para remover um banco:
Delete todo o bloco (de `{` até `},`) do banco que deseja remover.

### Dicas para Logos de Bancos:
- **Formato recomendado:** PNG ou SVG com fundo transparente
- **Tamanho recomendado:** 200x100px ou maior
- **Fundo:** As logos ficam sobre fundo branco, então prefira logos coloridas
- **Qualidade:** Use logos de alta resolução para não ficarem pixeladas

---

## 12. Mapa Completo de Todas as Imagens por Página

### 📍 RESUMO RÁPIDO - ONDE ESTÁ CADA IMAGEM

| Página | Componente | Imagens |
|--------|-----------|---------|
| **Página Inicial** | `hero-principal.tsx` | 1 imagem (banner) |
| **Página Inicial** | `fotos-empresa.tsx` | 4 imagens (empresa) |
| **Página Inicial** | `galeria-empresa.tsx` | 4 imagens (galeria) |
| **Serviços** | `hero-servicos.tsx` | 1 imagem (banner) |
| **Margem Extra** | `banner-margem-extra.tsx` | 1 imagem (banner) |
| **Sobre Nós** | `about.tsx` | 3 imagens (equipe e escritório) |
| **Sobre Nós** | `secao-confianca.tsx` | 5 logos de bancos |
| **Contato** | `contact.tsx` | 2 imagens (header e formulário) |
| **Header/Footer** | `header.tsx` e `footer.tsx` | Logo UP Soluções |

### 🎨 COMO TROCAR QUALQUER IMAGEM

1. **Encontre o arquivo** na tabela acima
2. **Abra o arquivo** na pasta `components/`
3. **Procure por** `<Image src=` ou o array de imagens
4. **Substitua o `src`** pelo caminho da sua nova imagem
5. **Atualize o `alt`** com a descrição da nova imagem

### 📁 ONDE COLOCAR AS NOVAS IMAGENS

Todas as imagens devem ser colocadas na pasta `public/`:
```
public/
├── images/
│   ├── bancos/
│   │   ├── bmg-logo.png
│   │   ├── santander-logo.png
│   │   └── ...
│   ├── empresa/
│   │   ├── escritorio-1.jpg
│   │   ├── equipe.jpg
│   │   └── ...
│   └── banners/
│       ├── hero-principal.jpg
│       ├── hero-servicos.jpg
│       └── ...
├── up-solucoes-logo.png
└── ...
```

### 🖼️ TAMANHOS RECOMENDADOS

| Tipo de Imagem | Tamanho Recomendado |
|----------------|---------------------|
| Banner Principal | 550x650px |
| Banner de Serviços | 520x520px |
| Banner Margem Extra | 550x550px |
| Fotos da Empresa | 400x300px |
| Galeria da Empresa | 600x400px |
| Logos de Bancos | 200x100px |
| Logo UP Soluções | 180x60px (horizontal) |

### 📷 FORMATOS RECOMENDADOS

- **JPG:** Para fotos (menor tamanho de arquivo)
- **PNG:** Para logos e imagens com transparência
- **SVG:** Para logos vetoriais (melhor qualidade)
- **WebP:** Melhor compressão (se o navegador suportar)

---

## ⚠️ Dicas Importantes

1. **Sempre salve o arquivo** após fazer alterações
2. **Teste o site** após cada mudança para ver se ficou como esperado
3. **Faça cópia de backup** antes de alterações grandes
4. **Respeite as aspas** - use `"texto"` ou `'texto'` mas não misture
5. **Cuidado com vírgulas** - cada item de lista precisa de vírgula, exceto o último
6. **Não altere** nomes de arquivos ou estruturas de pastas sem conhecimento técnico

---

## 🆘 Problemas Comuns

### O site não carrega após alteração:
- Verifique se não esqueceu de fechar aspas `"` ou chaves `{}`
- Verifique se todas as vírgulas estão no lugar correto
- Desfaça a última alteração e tente novamente

### Imagem não aparece:
- Verifique se o caminho do arquivo está correto
- Confirme que a imagem está na pasta `public/`
- Verifique a extensão do arquivo (.jpg, .png, etc)
- Para logos de bancos: verifique se a URL externa está funcionando

### Logo do banco não aparece:
- Verifique se a URL está correta e acessível
- Tente usar uma imagem local em vez de URL externa
- Certifique-se de que o formato é suportado (PNG, SVG, JPG)

### Cores não mudaram:
- Verifique se salvou o arquivo `globals.css`
- Atualize a página com Ctrl+F5 (Windows) ou Cmd+Shift+R (Mac)

### Não consigo acessar o painel de depoimentos:
- Verifique se a URL está correta: `/admin/depoimentos`
- Confirme se a senha está correta (padrão: **admin123**)
- Verifique se o banco de dados está conectado

### Depoimentos não aparecem:
- Verifique se foram aprovados no painel admin
- Atualize a página
- Verifique se o banco de dados está funcionando

---

## 📞 Suporte

Se encontrar dificuldades ou precisar de alterações mais complexas, entre em contato com um desenvolvedor web.

**Última atualização:** Dezembro 2024
