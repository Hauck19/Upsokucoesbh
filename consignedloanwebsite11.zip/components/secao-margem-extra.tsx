"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, TrendingUp, Percent, Clock, Shield, Gift, ArrowRight } from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

export function SecaoMargemExtra() {
  const beneficios = [
    {
      icon: TrendingUp,
      titulo: "Crédito Adicional",
      descricao: "Até 5% de margem extra além do limite normal do consignado",
    },
    {
      icon: Percent,
      titulo: "Taxas Competitivas",
      descricao: "As melhores taxas do mercado para margem extra",
    },
    {
      icon: Clock,
      titulo: "Liberação Rápida",
      descricao: "Dinheiro na conta em até 24 horas após aprovação",
    },
    {
      icon: Shield,
      titulo: "Sem Burocracia",
      descricao: "Processo 100% online, simples e seguro",
    },
  ]

  const quemTemDireito = [
    "Aposentados e pensionistas do INSS",
    "Servidores públicos federais, estaduais e municipais",
    "Militares das Forças Armadas",
    "Beneficiários do LOAS/BPC",
    "Funcionários de empresas conveniadas",
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Título da seção */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-full text-sm font-semibold mb-4">
            MARGEM EXTRA
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">O que é a Margem Extra?</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            A margem extra é um benefício que permite aos aposentados, pensionistas e servidores públicos contratarem
            crédito adicional além da margem consignável tradicional, sem comprometer ainda mais o orçamento.
          </p>
        </div>

        {/* Cards de benefícios */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {beneficios.map((beneficio, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-card to-purple-50/50 dark:to-purple-900/10"
            >
              <CardContent className="p-6 text-center">
                <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500 to-red-500 flex items-center justify-center">
                  <beneficio.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">{beneficio.titulo}</h3>
                <p className="text-sm text-muted-foreground">{beneficio.descricao}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Seção de quem tem direito */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-6">Quem tem direito à Margem Extra?</h3>
            <div className="space-y-4">
              {quemTemDireito.map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                  <span className="text-foreground">{item}</span>
                </div>
              ))}
            </div>
            <div className="mt-8">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-red-600 hover:from-purple-700 hover:to-red-700 text-white"
              >
                <a href={getWhatsAppLink(mensagensWhatsApp.elegibilidade)} target="_blank" rel="noopener noreferrer">
                  Verificar minha elegibilidade
                  <ArrowRight className="ml-2 w-5 h-5" />
                </a>
              </Button>
            </div>
          </div>

          {/* Card de destaque */}
          <Card className="border-0 shadow-2xl bg-gradient-to-br from-purple-600 to-red-600 text-white overflow-hidden relative">
            <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
            <CardContent className="p-8 relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <Gift className="w-10 h-10" />
                <span className="text-xl font-bold">Benefício Exclusivo</span>
              </div>
              <h4 className="text-3xl font-black mb-4">Até 5% de margem adicional</h4>
              <p className="text-white/90 mb-6">
                Além dos 35% da margem tradicional, você pode ter acesso a mais 5% de margem extra para cartão de
                crédito consignado ou saque.
              </p>
              <div className="bg-white/20 rounded-lg p-4">
                <p className="text-sm font-medium">
                  Exemplo: Se seu benefício é R$ 2.000, sua margem extra pode ser de até R$ 100 mensais adicionais!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
