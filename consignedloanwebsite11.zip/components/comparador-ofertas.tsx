"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, TrendingDown, Clock, Banknote, CheckCircle2, Info } from "lucide-react"

const ofertas = [
  {
    banco: "Banco BMG",
    taxa: "1,80%",
    taxaNum: 1.8,
    prazo: "84 meses",
    valorLiberado: "R$ 15.000",
    destaque: true,
    cor: "from-green-500 to-green-600",
  },
  {
    banco: "Banco Pan",
    taxa: "1,95%",
    taxaNum: 1.95,
    prazo: "84 meses",
    valorLiberado: "R$ 14.500",
    destaque: false,
    cor: "from-blue-500 to-blue-600",
  },
  {
    banco: "Banco Daycoval",
    taxa: "2,05%",
    taxaNum: 2.05,
    prazo: "72 meses",
    valorLiberado: "R$ 13.800",
    destaque: false,
    cor: "from-purple-500 to-purple-600",
  },
]

export function ComparadorOfertas() {
  const [valorSimulado] = useState(10000)

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 mb-4">
            <TrendingDown className="w-4 h-4 mr-2" />
            Compare e Economize
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Comparador de Ofertas</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Veja as melhores condições dos nossos bancos parceiros. Valores estimados para simulação de R${" "}
            {valorSimulado.toLocaleString("pt-BR")}.
          </p>
        </div>

        {/* Tabela Desktop */}
        <div className="hidden md:block overflow-hidden rounded-2xl border border-border shadow-xl bg-card">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-green-600 to-green-700 text-white">
                <th className="px-6 py-4 text-left font-semibold">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5" />
                    Banco
                  </div>
                </th>
                <th className="px-6 py-4 text-center font-semibold">
                  <div className="flex items-center justify-center gap-2">
                    <TrendingDown className="w-5 h-5" />
                    Taxa Mensal
                  </div>
                </th>
                <th className="px-6 py-4 text-center font-semibold">
                  <div className="flex items-center justify-center gap-2">
                    <Clock className="w-5 h-5" />
                    Prazo Máximo
                  </div>
                </th>
                <th className="px-6 py-4 text-center font-semibold">
                  <div className="flex items-center justify-center gap-2">
                    <Banknote className="w-5 h-5" />
                    Valor Liberado*
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {ofertas.map((oferta, index) => (
                <tr
                  key={index}
                  className={`border-b border-border transition-all duration-300 hover:bg-muted/50 ${
                    oferta.destaque ? "bg-green-50 dark:bg-green-950/30" : ""
                  }`}
                >
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-full bg-gradient-to-r ${oferta.cor} flex items-center justify-center text-white font-bold`}
                      >
                        {oferta.banco.charAt(6)}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{oferta.banco}</p>
                        {oferta.destaque && (
                          <Badge className="bg-green-500 text-white text-xs mt-1">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Melhor Taxa
                          </Badge>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span
                      className={`text-2xl font-bold ${oferta.destaque ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
                    >
                      {oferta.taxa}
                    </span>
                    <span className="text-muted-foreground text-sm block">ao mês</span>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span className="text-xl font-semibold text-foreground">{oferta.prazo}</span>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span
                      className={`text-xl font-bold ${oferta.destaque ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
                    >
                      {oferta.valorLiberado}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Cards Mobile */}
        <div className="md:hidden space-y-4">
          {ofertas.map((oferta, index) => (
            <Card key={index} className={`overflow-hidden bg-card ${oferta.destaque ? "ring-2 ring-green-500" : ""}`}>
              <div className={`h-2 bg-gradient-to-r ${oferta.cor}`} />
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-foreground">{oferta.banco}</CardTitle>
                  {oferta.destaque && <Badge className="bg-green-500 text-white">Melhor Taxa</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-muted-foreground text-sm">Taxa</p>
                    <p
                      className={`font-bold text-lg ${oferta.destaque ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
                    >
                      {oferta.taxa}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Prazo</p>
                    <p className="font-bold text-lg text-foreground">{oferta.prazo}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Valor</p>
                    <p
                      className={`font-bold text-lg ${oferta.destaque ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
                    >
                      {oferta.valorLiberado}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Aviso de transparência */}
        <div className="mt-8 p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-amber-800 dark:text-amber-300 font-medium">Transparência Total</p>
            <p className="text-amber-700 dark:text-amber-400 text-sm">
              *Valores estimados para fins de comparação. As condições finais dependem da análise de crédito, margem
              disponível e convênio. Consulte um de nossos especialistas para uma simulação personalizada.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
