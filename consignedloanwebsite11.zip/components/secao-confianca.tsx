"use client"

import { Shield, Lock, FileText, CheckCircle2, ShieldCheck, Star, Sparkles } from "lucide-react"
import { Card } from "@/components/ui/card"
import Image from "next/image"

const bancosParceiros = [
  {
    nome: "BMG",
    cor: "from-orange-500 to-orange-600",
    textoCor: "text-white",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Banco_BMG_logo.svg/1200px-Banco_BMG_logo.svg.png",
    bgColor: "bg-white",
  },
  {
    nome: "Santander",
    cor: "from-red-600 to-red-700",
    textoCor: "text-white",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Banco_Santander_Logotipo.svg/2560px-Banco_Santander_Logotipo.svg.png",
    bgColor: "bg-white",
  },
  {
    nome: "Daycoval",
    cor: "from-blue-700 to-blue-800",
    textoCor: "text-white",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Banco_Daycoval_logo.svg/1200px-Banco_Daycoval_logo.svg.png",
    bgColor: "bg-white",
  },
  {
    nome: "Master",
    cor: "from-yellow-500 to-yellow-600",
    textoCor: "text-black",
    logo: "https://www.bancomaster.com.br/assets/images/logo-banco-master.svg",
    bgColor: "bg-white",
  },
  {
    nome: "PAN",
    cor: "from-blue-500 to-blue-600",
    textoCor: "text-white",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Banco_Pan_logo.svg/2560px-Banco_Pan_logo.svg.png",
    bgColor: "bg-white",
  },
]

export function SecaoConfianca() {
  return (
    <section className="py-20 bg-gradient-to-br from-background via-primary/5 to-secondary/5 overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Título da Seção */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
            <Shield className="h-5 w-5 text-primary" />
            <span className="text-sm font-semibold text-primary">Segurança e Confiança</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-balance">
            Trabalhamos com os <span className="text-primary">Maiores Bancos</span> do Brasil
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Sua segurança é nossa prioridade. Somos uma empresa regularizada e trabalhamos apenas com instituições
            financeiras autorizadas pelo Banco Central.
          </p>
        </div>

        <div className="relative mb-16">
          {/* Background decorativo */}
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/10 to-primary/5 rounded-3xl" />

          <Card className="relative p-8 md:p-12 bg-card/80 backdrop-blur-xl border-2 border-primary/20 rounded-3xl overflow-hidden">
            {/* Efeitos de luz */}
            <div className="absolute top-0 left-1/4 w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-secondary/20 rounded-full blur-[100px]" />

            <div className="relative z-10">
              <div className="flex items-center justify-center gap-2 mb-8">
                <Sparkles className="h-6 w-6 text-secondary" />
                <h3 className="text-2xl md:text-3xl font-bold text-center">Nossos Parceiros Oficiais</h3>
                <Sparkles className="h-6 w-6 text-secondary" />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-6 items-center justify-items-center">
                {bancosParceiros.map((banco, index) => (
                  <div key={banco.nome} className="group relative" style={{ animationDelay: `${index * 0.1}s` }}>
                    {/* Glow effect */}
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${banco.cor} rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-all duration-500 scale-110`}
                    />

                    {/* Card do banco com logo real */}
                    <div
                      className={`relative w-36 h-24 md:w-44 md:h-28 ${banco.bgColor} rounded-2xl flex flex-col items-center justify-center p-4 shadow-lg transform transition-all duration-500 hover:scale-110 hover:-translate-y-2 hover:shadow-2xl cursor-pointer group-hover:ring-4 ring-primary/30 overflow-hidden`}
                    >
                      <div className="relative w-full h-full flex items-center justify-center p-2">
                        <Image
                          src={banco.logo || "/placeholder.svg"}
                          alt={`Logo ${banco.nome}`}
                          width={120}
                          height={60}
                          className="object-contain max-h-16"
                          unoptimized
                        />
                      </div>
                    </div>

                    {/* Badge de parceiro */}
                    <div className="absolute -top-2 -right-2 bg-secondary text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Parceiro
                    </div>
                  </div>
                ))}
              </div>

              {/* Texto de destaque */}
              <div className="mt-10 text-center">
                <p className="text-muted-foreground text-lg">
                  <span className="font-bold text-primary">+10.000 clientes</span> já contrataram através das nossas
                  parcerias
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Banner de segurança */}
        <div className="bg-gradient-to-r from-primary to-secondary p-8 rounded-2xl mb-12 text-white text-center shadow-2xl relative overflow-hidden">
          {/* Padrão decorativo */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full blur-2xl" />
            <div className="absolute bottom-0 right-0 w-40 h-40 bg-white rounded-full blur-2xl" />
          </div>

          <div className="relative z-10 flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="flex items-center gap-4 group hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm group-hover:bg-white/30 transition-colors">
                <Lock className="h-8 w-8" />
              </div>
              <div className="text-left">
                <p className="font-bold text-xl">Site Seguro</p>
                <p className="text-sm opacity-90">Certificado SSL Ativo</p>
              </div>
            </div>
            <div className="hidden md:block w-px h-16 bg-white/30" />
            <div className="flex items-center gap-4 group hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm group-hover:bg-white/30 transition-colors">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <div className="text-left">
                <p className="font-bold text-xl">Dados Protegidos</p>
                <p className="text-sm opacity-90">Nunca compartilhados</p>
              </div>
            </div>
            <div className="hidden md:block w-px h-16 bg-white/30" />
            <div className="flex items-center gap-4 group hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm group-hover:bg-white/30 transition-colors">
                <Shield className="h-8 w-8" />
              </div>
              <div className="text-left">
                <p className="font-bold text-xl">Criptografia 256-bit</p>
                <p className="text-sm opacity-90">Conexão totalmente segura</p>
              </div>
            </div>
          </div>
        </div>

        {/* Grid de Segurança */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* CNPJ Visível */}
          <Card className="p-8 text-center hover:shadow-2xl transition-all duration-300 bg-card/50 backdrop-blur border-2 hover:border-primary/50 group">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 mb-6 group-hover:scale-110 transition-transform">
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <h4 className="font-bold text-xl mb-2">Empresa Regularizada</h4>
            <p className="text-sm text-muted-foreground mb-4">CNPJ registrado e ativo</p>
            <p className="text-2xl font-black text-primary">56.086.552/0001-19</p>
            <p className="text-xs text-muted-foreground mt-3">Razão Social: UP Soluções Financeiras LTDA</p>
          </Card>

          {/* Site Seguro */}
          <Card className="p-8 text-center hover:shadow-2xl transition-all duration-300 bg-card/50 backdrop-blur border-2 hover:border-secondary/50 group">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-secondary/20 to-secondary/10 mb-6 group-hover:scale-110 transition-transform">
              <Lock className="h-8 w-8 text-secondary" />
            </div>
            <h4 className="font-bold text-xl mb-2">Site Seguro</h4>
            <p className="text-sm text-muted-foreground mb-4">Conexão criptografada SSL/TLS</p>
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-secondary/20 to-secondary/10 px-5 py-3 rounded-full">
              <Shield className="h-5 w-5 text-secondary" />
              <span className="text-sm font-bold text-secondary">Certificado SSL</span>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Seus dados estão protegidos</p>
          </Card>

          {/* Autorizado Banco Central */}
          <Card className="p-8 text-center hover:shadow-2xl transition-all duration-300 bg-card/50 backdrop-blur border-2 hover:border-primary/50 group">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 mb-6 group-hover:scale-110 transition-transform">
              <CheckCircle2 className="h-8 w-8 text-primary" />
            </div>
            <h4 className="font-bold text-xl mb-2">Instituição Autorizada</h4>
            <p className="text-sm text-muted-foreground mb-4">Regulamentado pelo Banco Central</p>
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-primary/20 to-primary/10 px-5 py-3 rounded-full">
              <div className="w-7 h-7 bg-blue-800 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">BC</span>
              </div>
              <span className="text-sm font-bold text-primary">BACEN</span>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Operações fiscalizadas</p>
          </Card>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {[
            { title: "Transparência", desc: "Sem letras miúdas, sem surpresas", icon: FileText },
            { title: "Agilidade", desc: "Aprovação em até 24 horas", icon: CheckCircle2 },
            { title: "Segurança", desc: "Dados 100% protegidos", icon: Shield },
            { title: "Confiança", desc: "+10 anos no mercado", icon: Star },
          ].map((item, index) => (
            <Card
              key={index}
              className="p-6 text-center bg-gradient-to-br from-card to-card/50 border hover:border-primary/30 transition-all duration-300 group hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <item.icon className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-bold mb-1">{item.title}</h4>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </Card>
          ))}
        </div>

        <div className="bg-card/30 backdrop-blur rounded-xl p-6 border border-border/50 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <p className="text-sm font-medium">Transparência e Segurança</p>
            </div>
            <div className="flex flex-wrap gap-4 justify-center">
              <a
                href="/politica-privacidade"
                className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors underline decoration-2"
              >
                Política de Privacidade
              </a>
              <a
                href="/termos-uso"
                className="text-sm text-muted-foreground hover:text-primary transition-colors underline"
              >
                Termos de Uso
              </a>
              <a href="/lgpd" className="text-sm text-muted-foreground hover:text-primary transition-colors underline">
                LGPD
              </a>
              <a
                href="/codigo-conduta"
                className="text-sm text-muted-foreground hover:text-primary transition-colors underline"
              >
                Código de Conduta
              </a>
            </div>
          </div>
        </div>

        <Card className="p-8 bg-gradient-to-r from-secondary/10 to-secondary/5 border-secondary/20">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-secondary to-secondary/80 flex items-center justify-center shadow-lg">
                <Lock className="h-10 w-10 text-white" />
              </div>
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="text-xl font-bold mb-2">Seus Dados Pessoais Estão 100% Protegidos</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Utilizamos criptografia de ponta a ponta para proteger todas as suas informações. Seus dados pessoais
                são tratados com total sigilo e <strong>NUNCA</strong> são compartilhados com terceiros sem sua
                autorização expressa. Estamos em conformidade com a Lei Geral de Proteção de Dados (LGPD).
              </p>
            </div>
            <div className="flex-shrink-0">
              <a
                href="/politica-privacidade"
                className="inline-flex items-center gap-2 bg-secondary text-white px-6 py-4 rounded-xl font-semibold hover:bg-secondary/90 transition-all hover:scale-105 shadow-lg"
              >
                <FileText className="h-5 w-5" />
                Ler Política Completa
              </a>
            </div>
          </div>
        </Card>

        {/* Aviso Legal */}
        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            A UP Soluções atua como correspondente bancário autorizado. As operações de crédito consignado são de
            responsabilidade das instituições financeiras parceiras. Sujeito à análise de crédito e disponibilidade de
            margem consignável.
          </p>
        </div>
      </div>
    </section>
  )
}
