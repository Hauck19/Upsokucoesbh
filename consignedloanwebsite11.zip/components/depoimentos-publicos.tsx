"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Star, Quote, User } from "lucide-react"

interface Depoimento {
  id: string
  nome_cliente: string
  depoimento: string
  avaliacao: number
  imagem_url?: string
  criado_em: string
}

export function DepoimentosPublicos() {
  const [depoimentos, setDepoimentos] = useState<Depoimento[]>([])
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    carregarDepoimentos()
  }, [])

  const carregarDepoimentos = async () => {
    try {
      const response = await fetch("/api/depoimentos")
      if (response.ok) {
        const data = await response.json()
        setDepoimentos(data)
      }
    } catch (error) {
      console.error("Erro ao carregar depoimentos:", error)
    } finally {
      setCarregando(false)
    }
  }

  if (carregando) {
    return (
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-muted-foreground">Carregando depoimentos...</p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-semibold mb-4">
            Depoimentos Aprovados
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Histórias de <span className="text-primary">Sucesso</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Conheça as experiências de quem confiou na UP Soluções para realizar seus objetivos financeiros
          </p>
        </div>

        {depoimentos.length === 0 ? (
          <div className="text-center py-12 bg-muted/30 rounded-2xl max-w-md mx-auto">
            <Quote className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground mb-2">Nenhum depoimento aprovado ainda.</p>
            <p className="text-sm text-muted-foreground">Seja o primeiro a compartilhar sua experiência!</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {depoimentos.map((dep) => (
              <Card
                key={dep.id}
                className="relative overflow-hidden hover:shadow-xl transition-all duration-300 group border-0 shadow-lg"
              >
                {/* Elemento decorativo */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-primary/5 to-secondary/5 rounded-bl-full" />

                <div className="p-6 relative">
                  {/* Ícone de citação */}
                  <Quote className="absolute top-4 right-4 w-8 h-8 text-primary/10" />

                  {/* Avaliação por estrelas */}
                  <div className="flex gap-1 mb-4">
                    {[1, 2, 3, 4, 5].map((estrela) => (
                      <Star
                        key={estrela}
                        className={`w-5 h-5 ${
                          estrela <= dep.avaliacao ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
                        }`}
                      />
                    ))}
                  </div>

                  {/* Texto do depoimento */}
                  <p className="text-foreground leading-relaxed mb-6 line-clamp-6">"{dep.depoimento}"</p>

                  {/* Informações do cliente */}
                  <div className="flex items-center gap-3 pt-4 border-t border-border">
                    <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white">
                      <User size={20} />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{dep.nome_cliente}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(dep.criado_em).toLocaleDateString("pt-BR", {
                          day: "2-digit",
                          month: "long",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
