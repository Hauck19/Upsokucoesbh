"use client"

import { useState } from "react"
import {
  CreditCard,
  Banknote,
  RefreshCw,
  ArrowRightLeft,
  Wallet,
  CheckCircle2,
  XCircle,
  Clock,
  DollarSign,
  FileText,
  Users,
  TrendingUp,
  HelpCircle,
  ChevronDown,
  ArrowRight,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getWhatsAppLink } from "@/lib/whatsapp"

const produtos = [
  {
    id: "consignado",
    nome: "Empréstimo Consignado",
    icon: Banknote,
    cor: "bg-blue-500",
    descricaoCurta: "Crédito com desconto direto na folha ou benefício",
    descricaoCompleta:
      "O empréstimo consignado é a modalidade de crédito mais vantajosa do mercado. O valor das parcelas é descontado diretamente do seu salário ou benefício do INSS, garantindo taxas de juros muito menores que outras linhas de crédito.",
    taxaJuros: "1,50% a 2,14% a.m.",
    prazoMaximo: "Até 84 meses",
    valorMinimo: "R$ 500,00",
    valorMaximo: "Conforme margem",
    margemUtilizada: "35% do salário/benefício",
    tempoAprovacao: "24 a 48 horas",
    mensagemWhatsApp: "Olá! Gostaria de fazer uma simulação de empréstimo consignado. Podem me ajudar?",
    vantagens: [
      "Menores taxas de juros do mercado",
      "Desconto automático na folha",
      "Sem consulta ao SPC/Serasa",
      "Prazo longo para pagamento",
      "Aprovação mesmo negativado",
      "Dinheiro direto na conta",
    ],
    desvantagens: ["Compromete margem consignável", "Desconto fixo mensal"],
    documentos: ["RG ou CNH", "CPF", "Comprovante de residência", "Contracheque ou extrato INSS"],
    quemPodeContratar: [
      "Aposentados INSS",
      "Pensionistas INSS",
      "Servidores Públicos",
      "Militares",
      "Trabalhadores CLT (algumas empresas)",
    ],
    idealPara: "Quem precisa de dinheiro na conta para quitar dívidas, fazer reformas, investir ou realizar sonhos.",
  },
  {
    id: "cartao",
    nome: "Cartão Consignado",
    icon: CreditCard,
    cor: "bg-purple-500",
    descricaoCurta: "Cartão de crédito com desconto em folha",
    descricaoCompleta:
      "O cartão consignado é um cartão de crédito com limite aprovado baseado na sua margem consignável. O pagamento mínimo é descontado automaticamente, e você pode usar o limite como um cartão normal.",
    taxaJuros: "2,50% a 3,00% a.m.",
    prazoMaximo: "Rotativo mensal",
    valorMinimo: "Conforme limite",
    valorMaximo: "Até 1,6x do benefício",
    margemUtilizada: "5% do salário/benefício",
    tempoAprovacao: "24 a 72 horas",
    mensagemWhatsApp: "Olá! Tenho interesse no cartão consignado. Podem me dar mais informações?",
    vantagens: [
      "Limite sempre disponível",
      "Aceito em todo Brasil",
      "Função saque no débito",
      "Sem anuidade",
      "Desconto mínimo de 5%",
      "Pode fazer saque suplementar",
    ],
    desvantagens: ["Taxas maiores que consignado", "Risco de usar além do necessário"],
    documentos: ["RG ou CNH", "CPF", "Comprovante de residência", "Contracheque ou extrato INSS"],
    quemPodeContratar: ["Aposentados INSS", "Pensionistas INSS", "Servidores Públicos"],
    idealPara: "Quem quer ter um limite de crédito disponível para emergências e compras do dia a dia.",
  },
  {
    id: "portabilidade",
    nome: "Portabilidade",
    icon: ArrowRightLeft,
    cor: "bg-green-500",
    descricaoCurta: "Transferência de dívida para outro banco",
    descricaoCompleta:
      "A portabilidade permite transferir seu empréstimo consignado de um banco para outro, buscando melhores condições. Você pode conseguir taxas menores e ainda liberar um troco (dinheiro extra) no processo.",
    taxaJuros: "Negociável (menor que atual)",
    prazoMaximo: "Pode aumentar prazo",
    valorMinimo: "Saldo devedor atual",
    valorMaximo: "Saldo + troco",
    margemUtilizada: "Mesma do contrato atual",
    tempoAprovacao: "5 a 10 dias úteis",
    mensagemWhatsApp: "Olá! Quero fazer a portabilidade do meu empréstimo para reduzir os juros. Como funciona?",
    vantagens: [
      "Reduz taxa de juros",
      "Pode liberar troco",
      "Mantém mesmo valor de parcela",
      "Sem custo para você",
      "Banco novo paga o antigo",
      "Pode alongar prazo",
    ],
    desvantagens: ["Processo mais demorado", "Depende da aprovação do novo banco"],
    documentos: ["RG ou CNH", "CPF", "Comprovante de residência", "Contracheque ou extrato INSS", "Contrato atual"],
    quemPodeContratar: ["Quem já tem consignado ativo", "Contratos com mais de 6 meses"],
    idealPara: "Quem já tem empréstimo consignado e quer reduzir as taxas de juros ou liberar dinheiro extra.",
  },
  {
    id: "refinanciamento",
    nome: "Refinanciamento",
    icon: RefreshCw,
    cor: "bg-orange-500",
    descricaoCurta: "Renegociação do contrato atual",
    descricaoCompleta:
      "O refinanciamento permite renegociar seu empréstimo consignado atual, aproveitando a margem que você já pagou para liberar novo dinheiro ou reduzir suas parcelas.",
    taxaJuros: "1,70% a 2,30% a.m.",
    prazoMaximo: "Até 84 meses",
    valorMinimo: "R$ 500,00",
    valorMaximo: "Margem liberada",
    margemUtilizada: "Margem paga + disponível",
    tempoAprovacao: "24 a 48 horas",
    mensagemWhatsApp: "Olá! Gostaria de refinanciar meu empréstimo e liberar crédito extra. Podem me ajudar?",
    vantagens: [
      "Diminui valor da parcela",
      "Libera novo dinheiro",
      "Aproveita margem já paga",
      "Estende prazo do contrato",
      "Processo rápido",
      "Mesmo no banco atual",
    ],
    desvantagens: ["Aumenta prazo da dívida", "Paga mais juros no total"],
    documentos: ["RG ou CNH", "CPF", "Comprovante de residência", "Contracheque ou extrato INSS"],
    quemPodeContratar: ["Quem já tem consignado ativo", "Contratos com parcelas pagas"],
    idealPara: "Quem precisa de mais dinheiro e quer aproveitar a margem que já pagou no contrato atual.",
  },
  {
    id: "saque-suplementar",
    nome: "Saque Suplementar",
    icon: Wallet,
    cor: "bg-teal-500",
    descricaoCurta: "Saque extra do cartão consignado",
    descricaoCompleta:
      "O saque suplementar permite transformar parte do limite do seu cartão consignado em dinheiro na conta, com desconto em parcelas fixas. É uma forma de ter crédito usando a margem do cartão.",
    taxaJuros: "2,00% a 2,70% a.m.",
    prazoMaximo: "Até 84 meses",
    valorMinimo: "R$ 300,00",
    valorMaximo: "Limite do cartão",
    margemUtilizada: "Margem do cartão (5%)",
    tempoAprovacao: "24 a 48 horas",
    mensagemWhatsApp: "Olá! Tenho interesse no saque suplementar. Podem me explicar como funciona?",
    vantagens: [
      "Usa margem do cartão",
      "Dinheiro direto na conta",
      "Sem burocracia extra",
      "Parcelas fixas",
      "Aprovação rápida",
      "Não compromete margem do consignado",
    ],
    desvantagens: ["Taxas maiores que consignado tradicional", "Limite conforme cartão"],
    documentos: ["RG ou CNH", "CPF", "Comprovante de residência", "Contracheque ou extrato INSS"],
    quemPodeContratar: ["Quem já tem cartão consignado", "Com limite disponível"],
    idealPara: "Quem já tem cartão consignado e precisa de dinheiro na conta sem comprometer a margem do empréstimo.",
  },
]

export function ComparativoProdutos() {
  const [expandido, setExpandido] = useState<string | null>(null)

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4">
        {/* Cabeçalho */}
        <div className="text-center mb-12 md:mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Comparativo de Produtos
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Compare todas as modalidades de crédito consignado e descubra qual é a melhor opção para você.
          </p>
        </div>

        {/* Tabela Comparativa Desktop */}
        <div className="hidden lg:block mb-16 overflow-x-auto">
          <Card className="p-6">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-4 font-semibold">Característica</th>
                  {produtos.map((produto) => (
                    <th key={produto.id} className="text-center p-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className={`w-12 h-12 ${produto.cor} rounded-xl flex items-center justify-center`}>
                          <produto.icon className="w-6 h-6 text-white" />
                        </div>
                        <span className="font-semibold text-sm">{produto.nome}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border/50">
                  <td className="p-4 font-medium">Taxa de Juros</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4 text-sm">
                      {produto.taxaJuros}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border/50 bg-muted/30">
                  <td className="p-4 font-medium">Prazo Máximo</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4 text-sm">
                      {produto.prazoMaximo}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border/50">
                  <td className="p-4 font-medium">Margem Utilizada</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4 text-sm">
                      {produto.margemUtilizada}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border/50 bg-muted/30">
                  <td className="p-4 font-medium">Tempo de Aprovação</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4 text-sm">
                      {produto.tempoAprovacao}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border/50">
                  <td className="p-4 font-medium">Ideal Para</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4 text-sm text-muted-foreground">
                      {produto.idealPara}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-medium">Simular</td>
                  {produtos.map((produto) => (
                    <td key={produto.id} className="text-center p-4">
                      <Button asChild size="sm" className={produto.cor + " hover:opacity-90"}>
                        <a href={getWhatsAppLink(produto.mensagemWhatsApp)} target="_blank" rel="noopener noreferrer">
                          Simular
                        </a>
                      </Button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </Card>
        </div>

        {/* Cards Detalhados */}
        <div className="space-y-6">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">Detalhes de Cada Produto</h2>

          {produtos.map((produto) => {
            const isExpanded = expandido === produto.id
            const Icon = produto.icon

            return (
              <Card key={produto.id} className="overflow-hidden">
                {/* Header do Card */}
                <button
                  onClick={() => setExpandido(isExpanded ? null : produto.id)}
                  className="w-full p-6 flex items-center justify-between hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 ${produto.cor} rounded-xl flex items-center justify-center`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xl font-bold">{produto.nome}</h3>
                      <p className="text-muted-foreground">{produto.descricaoCurta}</p>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </button>

                {/* Conteúdo Expandido */}
                {isExpanded && (
                  <div className="px-6 pb-6 border-t border-border">
                    <div className="pt-6">
                      <p className="text-muted-foreground mb-6">{produto.descricaoCompleta}</p>

                      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                        <div className="bg-muted/30 rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <DollarSign className="w-5 h-5 text-primary" />
                            <span className="font-semibold">Taxa de Juros</span>
                          </div>
                          <p className="text-lg font-bold text-primary">{produto.taxaJuros}</p>
                        </div>
                        <div className="bg-muted/30 rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Clock className="w-5 h-5 text-secondary" />
                            <span className="font-semibold">Prazo</span>
                          </div>
                          <p className="text-lg font-bold">{produto.prazoMaximo}</p>
                        </div>
                        <div className="bg-muted/30 rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="w-5 h-5 text-green-500" />
                            <span className="font-semibold">Margem</span>
                          </div>
                          <p className="text-lg font-bold">{produto.margemUtilizada}</p>
                        </div>
                        <div className="bg-muted/30 rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Clock className="w-5 h-5 text-orange-500" />
                            <span className="font-semibold">Aprovação</span>
                          </div>
                          <p className="text-lg font-bold">{produto.tempoAprovacao}</p>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        {/* Vantagens */}
                        <div>
                          <h4 className="font-semibold mb-3 flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                            Vantagens
                          </h4>
                          <ul className="space-y-2">
                            {produto.vantagens.map((vantagem, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm">
                                <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                {vantagem}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Desvantagens */}
                        <div>
                          <h4 className="font-semibold mb-3 flex items-center gap-2">
                            <XCircle className="w-5 h-5 text-red-500" />
                            Pontos de Atenção
                          </h4>
                          <ul className="space-y-2">
                            {produto.desvantagens.map((desvantagem, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm">
                                <XCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                                {desvantagem}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        {/* Documentos */}
                        <div className="bg-primary/5 rounded-lg p-4">
                          <h4 className="font-semibold mb-3 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-primary" />
                            Documentos Necessários
                          </h4>
                          <ul className="space-y-1">
                            {produto.documentos.map((doc, idx) => (
                              <li key={idx} className="text-sm flex items-center gap-2">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                                {doc}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Quem pode contratar */}
                        <div className="bg-secondary/5 rounded-lg p-4">
                          <h4 className="font-semibold mb-3 flex items-center gap-2">
                            <Users className="w-5 h-5 text-secondary" />
                            Quem Pode Contratar
                          </h4>
                          <ul className="space-y-1">
                            {produto.quemPodeContratar.map((quem, idx) => (
                              <li key={idx} className="text-sm flex items-center gap-2">
                                <div className="w-1.5 h-1.5 bg-secondary rounded-full" />
                                {quem}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Ideal Para */}
                      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-4 mb-6">
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <HelpCircle className="w-5 h-5 text-primary" />
                          Ideal Para
                        </h4>
                        <p className="text-muted-foreground">{produto.idealPara}</p>
                      </div>

                      <Button asChild size="lg" className="w-full md:w-auto">
                        <a
                          href={getWhatsAppLink(produto.mensagemWhatsApp)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2"
                        >
                          Simular {produto.nome}
                          <ArrowRight className="w-5 h-5" />
                        </a>
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            )
          })}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 md:p-12 max-w-4xl mx-auto shadow-xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Não sabe qual escolher?</h2>
            <p className="text-white/90 text-lg mb-6">
              Nossa equipe analisa seu perfil e indica a melhor opção para você. Simule grátis!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8">
                <a
                  href={getWhatsAppLink("Olá! Não sei qual produto é melhor para mim. Podem me ajudar a escolher?")}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Falar com Consultor
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
