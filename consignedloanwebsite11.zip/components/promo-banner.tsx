"use client"

import { ArrowRight, CheckCircle, TrendingUp, Sparkles } from "lucide-react"
import Image from "next/image"

export function PromoBanner() {
  const handleClick = () => {
    const message = encodeURIComponent("Olá, quero simular!")
    window.open(`https://wa.me/5531982190475?text=${message}`, "_blank")
  }

  return (
    <div className="relative w-full bg-gradient-to-br from-primary via-primary/95 to-secondary overflow-hidden">
      {/* Círculos animados decorativos */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-secondary/30 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse delay-1000" />

      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Lado esquerdo - Conteúdo */}
          <div className="text-center lg:text-left text-white space-y-6 relative z-10">
            {/* Badge animado */}
            <div className="inline-flex items-center gap-2 bg-secondary/80 text-white px-4 py-2 rounded-full text-sm font-semibold animate-bounce">
              <Sparkles size={16} />
              Crédito Rápido e Aprovado!
            </div>

            {/* Título principal */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
              Empréstimo Consignado com as <span className="text-secondary">Melhores Taxas</span>
            </h1>

            {/* Descrição */}
            <p className="text-lg md:text-xl text-white/90 text-pretty">
              Dinheiro rápido na sua conta! Parcelas que cabem no seu bolso com taxas reduzidas e aprovação facilitada.
            </p>

            {/* Lista de benefícios */}
            <ul className="space-y-3 text-left max-w-md mx-auto lg:mx-0">
              {[
                "Aprovação em até 24 horas",
                "Taxas até 30% menores",
                "Parcelas descontadas direto na folha",
                "Sem consulta ao SPC/Serasa",
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3 text-white/95">
                  <CheckCircle className="w-6 h-6 text-secondary flex-shrink-0" />
                  
                </li>
              ))}
            </ul>

            {/* Botão de ação */}
            <button
              onClick={handleClick}
              className="group bg-secondary hover:bg-secondary/90 text-white px-8 py-5 rounded-xl font-bold text-lg shadow-2xl hover:shadow-secondary/50 transition-all duration-300 hover:scale-105 flex items-center gap-3 mx-auto lg:mx-0 justify-center"
            >
              <TrendingUp className="w-6 h-6" />
              SIMULAR AGORA GRÁTIS
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </button>
          </div>

          <div className="hidden lg:block relative">
            <div className="absolute -inset-4 bg-gradient-to-br from-secondary/30 via-white/20 to-primary/30 rounded-3xl blur-2xl" />
            {/* IMAGEM DO BANNER PRINCIPAL - Para trocar: substitua o src pela sua imagem em public/ */}
            <Image
              src="/happy-couple-reviewing-financial-documents-with-co.jpg"
              alt="Casal feliz analisando documentos financeiros"
              width={600}
              height={500}
              className="relative z-10 rounded-3xl shadow-2xl object-cover"
              priority
            />
            {/* Badge de destaque */}
            <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-secondary to-green-500 text-white rounded-xl p-4 shadow-2xl z-20">
              <p className="text-sm font-medium">Libere até</p>
              <p className="text-2xl font-bold">R$ 150.000</p>
            </div>
          </div>
        </div>
      </div>

      {/* Onda decorativa na parte inferior */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg className="w-full h-auto" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path
            d="M0,0 C150,50 350,100 600,80 C850,60 1050,40 1200,60 L1200,120 L0,120 Z"
            className="fill-background"
          />
        </svg>
      </div>
    </div>
  )
}
