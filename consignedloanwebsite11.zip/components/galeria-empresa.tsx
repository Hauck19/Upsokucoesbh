import Image from "next/image"
import { Building2, Users, Award, MapPin } from "lucide-react"

const imagensEmpresa = [
  {
    src: "/open-plan-office-space-with-workstations-and-natur.jpg",
    alt: "Escritório UP Soluções - Ambiente moderno de trabalho",
    titulo: "Nosso Escritório",
  },
  {
    src: "/business-team-collaborating-around-table-with-lapt.jpg",
    alt: "Equipe UP Soluções trabalhando juntos",
    titulo: "Nossa Equipe",
  },
  {
    src: "/financial-consultant-shaking-hands-with-happy-seni.jpg",
    alt: "Atendimento personalizado ao cliente",
    titulo: "Atendimento Personalizado",
  },
  {
    src: "/corporate-lobby-reception-desk-with-company-logo-p.jpg",
    alt: "Recepção UP Soluções",
    titulo: "Recepção",
  },
]

export function GaleriaEmpresa() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Cabeçalho */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Building2 size={18} />
            <span>Conheça Nossa Estrutura</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">A UP Soluções Por Dentro</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Conheça nossa estrutura física e nossa equipe dedicada a oferecer o melhor atendimento em crédito consignado
            de Belo Horizonte.
          </p>
        </div>

        {/* Grid de imagens */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {imagensEmpresa.map((imagem, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Image
                src={imagem.src || "/placeholder.svg"}
                alt={imagem.alt}
                width={600}
                height={400}
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <p className="font-semibold text-lg">{imagem.titulo}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Cards de informações */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border flex items-start gap-4">
            <div className="bg-primary/10 p-3 rounded-xl">
              <MapPin className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Localização Privilegiada</h3>
              <p className="text-muted-foreground text-sm">
                Estamos no coração de Belo Horizonte, com fácil acesso.
              </p>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border flex items-start gap-4">
            <div className="bg-secondary/10 p-3 rounded-xl">
              <Users className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Equipe Especializada</h3>
              <p className="text-muted-foreground text-sm">Profissionais treinados e dedicados ao seu atendimento.</p>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border flex items-start gap-4">
            <div className="bg-primary/10 p-3 rounded-xl">
              <Award className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">10 Anos de Experiência</h3>
              <p className="text-muted-foreground text-sm">
                Uma década ajudando clientes a conquistar seus objetivos financeiros.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
