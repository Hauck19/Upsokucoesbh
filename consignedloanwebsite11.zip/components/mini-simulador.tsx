"use client"

import type React from "react"

import { useState } from "react"
import { Calculator, MessageCircle, TrendingUp, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function MiniSimulador() {
  const [valor, setValor] = useState("")
  const [parcelas, setParcelas] = useState("")
  const [convenio, setConvenio] = useState("")

  const formatarMoeda = (valor: string) => {
    // Remove tudo que não é número
    const numero = valor.replace(/\D/g, "")

    // Converte para número e formata
    if (numero === "") return ""
    const valorNumerico = Number.parseInt(numero) / 100
    return valorNumerico.toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const valorFormatado = formatarMoeda(e.target.value)
    setValor(valorFormatado)
  }

  const handleSimular = () => {
    if (!valor || !parcelas || !convenio) {
      alert("Por favor, preencha todos os campos!")
      return
    }

    const valorLimpo = valor.replace(/\./g, "").replace(",", ".")
    const mensagem = `Olá! Gostaria de simular um empréstimo consignado:\n\n💰 Valor: R$ ${valor}\n📅 Parcelas: ${parcelas}x\n👤 Convênio: ${convenio}\n\nPoderia me enviar a simulação?`

    const numeroWhatsApp = "5531982190475"
    const urlWhatsApp = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensagem)}`

    window.open(urlWhatsApp, "_blank")
  }

  return (
    <section className="py-16 bg-gradient-to-br from-primary via-primary/90 to-secondary relative overflow-hidden">
      {/* Elementos decorativos de fundo */}
      <div className="absolute inset-0 opacity-5 dark:opacity-10">
        <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-secondary rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Cabeçalho da seção */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur px-4 py-2 rounded-full mb-4">
              <Calculator className="h-5 w-5 text-white" />
              <span className="text-sm font-semibold text-white">Simulação Gratuita</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Simule seu Empréstimo Consignado em Segundos
            </h2>
            <p className="text-white/90 text-lg">
              Descubra quanto você pode pegar e quais as melhores condições para você
            </p>
          </div>

          <Card className="p-8 bg-background/95 backdrop-blur shadow-2xl border-border">
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              {/* Campo de Valor */}
              <div className="space-y-2">
                <Label htmlFor="valor" className="text-base font-semibold flex items-center gap-2 text-foreground">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Quanto você quer pegar?
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold">
                    R$
                  </span>
                  <Input
                    id="valor"
                    type="text"
                    placeholder="0,00"
                    value={valor}
                    onChange={handleValorChange}
                    className="pl-10 h-12 text-lg font-semibold bg-background text-foreground placeholder:text-muted-foreground border-input"
                  />
                </div>
                <p className="text-xs text-muted-foreground">De R$ 1.000 até R$ 100.000</p>
              </div>

              {/* Campo de Parcelas */}
              <div className="space-y-2">
                <Label htmlFor="parcelas" className="text-base font-semibold flex items-center gap-2 text-foreground">
                  <Calculator className="h-4 w-4 text-primary" />
                  Em quantas parcelas?
                </Label>
                <Select value={parcelas} onValueChange={setParcelas}>
                  <SelectTrigger
                    id="parcelas"
                    className="h-12 text-lg font-semibold bg-background text-foreground border-input"
                  >
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="12">12 parcelas</SelectItem>
                    <SelectItem value="24">24 parcelas</SelectItem>
                    <SelectItem value="36">36 parcelas</SelectItem>
                    <SelectItem value="48">48 parcelas</SelectItem>
                    <SelectItem value="60">60 parcelas</SelectItem>
                    <SelectItem value="72">72 parcelas</SelectItem>
                    <SelectItem value="84">84 parcelas</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">Até 84 meses</p>
              </div>

              {/* Campo de Convênio */}
              <div className="space-y-2">
                <Label htmlFor="convenio" className="text-base font-semibold flex items-center gap-2 text-foreground">
                  <Users className="h-4 w-4 text-primary" />
                  Qual é seu convênio?
                </Label>
                <Select value={convenio} onValueChange={setConvenio}>
                  <SelectTrigger
                    id="convenio"
                    className="h-12 text-lg font-semibold bg-background text-foreground border-input"
                  >
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INSS">INSS (Aposentado/Pensionista)</SelectItem>
                    <SelectItem value="Federal">Servidor Público Federal</SelectItem>
                    <SelectItem value="Estadual">Servidor Público Estadual</SelectItem>
                    <SelectItem value="Municipal">Servidor Público Municipal</SelectItem>
                    <SelectItem value="Forças Armadas">Forças Armadas</SelectItem>
                    <SelectItem value="CLT">Funcionário CLT (Empresa Privada)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">Escolha sua categoria</p>
              </div>
            </div>

            {/* Botão de Simulação */}
            <Button
              onClick={handleSimular}
              size="lg"
              className="w-full h-14 text-lg font-bold bg-gradient-to-r from-secondary to-secondary/90 hover:from-secondary/90 hover:to-secondary text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
            >
              <MessageCircle className="mr-2 h-6 w-6" />
              Receber Simulação no WhatsApp
            </Button>

            {/* Informações adicionais */}
            <div className="mt-6 grid grid-cols-3 gap-4 pt-6 border-t border-border">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">1,49%</p>
                <p className="text-xs text-muted-foreground">Taxa a partir de</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">24h</p>
                <p className="text-xs text-muted-foreground">Aprovação em até</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">100%</p>
                <p className="text-xs text-muted-foreground">Online e seguro</p>
              </div>
            </div>
          </Card>

          {/* Avisos */}
          <div className="mt-6 text-center">
            <p className="text-sm text-white/80">
              ✅ Simulação gratuita e sem compromisso • Resposta imediata via WhatsApp
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
