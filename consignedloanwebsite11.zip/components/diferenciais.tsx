import { RefreshCw, Globe, Zap, FileX, Eye, Building2, HeartHandshake, Calculator, FileCheck } from "lucide-react"

const diferenciais = [
  {
    icon: RefreshCw,
    title: "Taxas Atualizadas Diariamente",
    description: "Monitoramos o mercado todos os dias para garantir as melhores taxas para você.",
    cor: "from-blue-500 to-cyan-500",
  },
  {
    icon: Globe,
    title: "Atendimento 100% Online",
    description: "Faça tudo pelo celular ou computador, sem precisar sair de casa.",
    cor: "from-green-500 to-emerald-500",
  },
  {
    icon: Zap,
    title: "Liberação Mais Rápida da Região",
    description: "Processo ágil com dinheiro na conta em tempo recorde.",
    cor: "from-yellow-500 to-orange-500",
  },
  {
    icon: FileX,
    title: "Sem Burocracia",
    description: "Documentação simplificada e processo descomplicado do início ao fim.",
    cor: "from-red-500 to-pink-500",
  },
  {
    icon: Eye,
    title: "Acompanhamento em Tempo Real",
    description: "Saiba exatamente em qual etapa está seu processo a qualquer momento.",
    cor: "from-purple-500 to-violet-500",
  },
  {
    icon: Building2,
    title: "Todos os Bancos Principais",
    description: "Parceria com BMG, Santander, Daycoval, Master, PAN e muito mais.",
    cor: "from-indigo-500 to-blue-500",
  },
  {
    icon: HeartHandshake,
    title: "Atendimento Humanizado",
    description: "Consultores prontos para ajudar e tirar dúvidas do início ao fim.",
    cor: "from-pink-500 to-rose-500",
  },
  {
    icon: Calculator,
    title: "Simulação Gratuita e Sem Compromisso",
    description: "Cliente consegue simular antes de contratar, sem nenhuma obrigação.",
    cor: "from-teal-500 to-cyan-500",
  },
  {
    icon: FileCheck,
    title: "Transparência Total",
    description: "Sem taxas escondidas, contrato claro e explicativo para sua segurança.",
    cor: "from-amber-500 to-yellow-500",
  },
]

export function Diferenciais() {
  return (
    <section className="py-24 bg-accent/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-semibold mb-4">
            Nossos Diferenciais
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Por Que Somos a <span className="text-primary">Melhor Escolha</span>?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Combinamos tecnologia, agilidade e atendimento humanizado para oferecer a melhor experiência em crédito
            consignado.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {diferenciais.map((item, index) => {
            const Icon = item.icon
            return (
              <div
                key={index}
                className="group relative bg-card border border-border rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden"
              >
                {/* Gradiente de fundo no hover */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${item.cor} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
                />

                <div
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${item.cor} flex items-center justify-center mb-4 shadow-lg`}
                >
                  <Icon className="text-white" size={28} />
                </div>

                <h3 className="text-lg font-bold mb-2 text-foreground">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{item.description}</p>

                {/* Barra decorativa */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${item.cor} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300`}
                />
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
