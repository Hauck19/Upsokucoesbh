import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRightLeft, TrendingDown, Wallet, FileCheck, ShieldCheck, ArrowRight } from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

const beneficiosPortabilidade = [
  {
    icon: TrendingDown,
    titulo: "Reduza os Juros",
    descricao: "Troque taxas altas por taxas menores sem aumentar sua dívida.",
  },
  {
    icon: Wallet,
    titulo: "Parcela Menor",
    descricao: "Diminua o valor da parcela e tenha mais dinheiro no bolso.",
  },
  {
    icon: FileCheck,
    titulo: "Processo Gratuito",
    descricao: "A portabilidade é um direito seu e não tem nenhum custo.",
  },
  {
    icon: ShieldCheck,
    titulo: "Garantido por Lei",
    descricao: "O banco é obrigado a permitir a transferência da sua dívida.",
  },
]

export function SecaoPortabilidade() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Lado esquerdo - Conteúdo */}
          <div>
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
              <ArrowRightLeft size={18} />
              Portabilidade de Crédito
            </div>

            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
              Reduza Sua Taxa Sem Mexer no Seu Benefício
            </h2>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              A portabilidade permite que você transfira seu empréstimo para um banco com taxas menores. É um{" "}
              <strong className="text-foreground">direito garantido por lei</strong> e pode representar uma economia
              significativa ao longo do contrato.
            </p>

            <div className="bg-accent/50 rounded-2xl p-6 mb-8 border-l-4 border-primary">
              <p className="text-lg font-medium text-foreground mb-2">Exemplo de economia:</p>
              <p className="text-muted-foreground">
                Um cliente que pagava <strong className="text-foreground">R$ 450/mês</strong> passou a pagar
                <strong className="text-secondary"> R$ 380/mês</strong> após a portabilidade. Economia de{" "}
                <strong className="text-secondary">R$ 70 por mês</strong>!
              </p>
            </div>

            <Button asChild size="lg" className="font-semibold">
              <a href={getWhatsAppLink(mensagensWhatsApp.portabilidade)} target="_blank" rel="noopener noreferrer">
                Quero Fazer Portabilidade
                <ArrowRight className="ml-2" size={18} />
              </a>
            </Button>
          </div>

          {/* Lado direito - Cards de benefícios */}
          <div className="grid sm:grid-cols-2 gap-4">
            {beneficiosPortabilidade.map((beneficio, index) => {
              const Icon = beneficio.icon
              return (
                <Card key={index} className="border-2 hover:border-primary transition-colors">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-4">
                      <Icon className="text-secondary" size={24} />
                    </div>
                    <h3 className="font-bold text-foreground mb-2">{beneficio.titulo}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{beneficio.descricao}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
