"use client"

import { useState, useEffect } from "react"
import { Clock, Zap } from "lucide-react"

export function CronometroUrgencia() {
  const [tempo, setTempo] = useState({ horas: 0, minutos: 0, segundos: 0 })

  useEffect(() => {
    const calcularTempoRestante = () => {
      const agora = new Date()
      const fimDoDia = new Date()
      fimDoDia.setHours(23, 59, 59, 999)

      const diferenca = fimDoDia.getTime() - agora.getTime()

      if (diferenca > 0) {
        const horas = Math.floor((diferenca / (1000 * 60 * 60)) % 24)
        const minutos = Math.floor((diferenca / (1000 * 60)) % 60)
        const segundos = Math.floor((diferenca / 1000) % 60)

        setTempo({ horas, minutos, segundos })
      } else {
        setTempo({ horas: 0, minutos: 0, segundos: 0 })
      }
    }

    // Atualizar imediatamente
    calcularTempoRestante()

    // Atualizar a cada segundo
    const intervalo = setInterval(calcularTempoRestante, 1000)

    return () => clearInterval(intervalo)
  }, [])

  return (
    <div className="bg-gradient-to-r from-red-600 via-orange-500 to-red-600 text-white py-3 px-4 animate-pulse-slow">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-center gap-3 text-center">
        <div className="flex items-center gap-2">
          <Zap className="h-5 w-5 animate-bounce" />
          <span className="font-bold text-lg">OFERTA ESPECIAL VÁLIDA ATÉ HOJE ÀS 23:59</span>
        </div>
        <div className="flex items-center gap-2 bg-white/20 backdrop-blur px-4 py-2 rounded-lg">
          <Clock className="h-5 w-5" />
          <div className="flex gap-1 font-mono text-xl font-bold">
            <div className="flex flex-col items-center">
              <span className="bg-black/30 px-2 py-1 rounded min-w-[2.5rem]">
                {String(tempo.horas).padStart(2, "0")}
              </span>
              <span className="text-[10px] mt-1">HORAS</span>
            </div>
            <span className="self-center text-2xl">:</span>
            <div className="flex flex-col items-center">
              <span className="bg-black/30 px-2 py-1 rounded min-w-[2.5rem]">
                {String(tempo.minutos).padStart(2, "0")}
              </span>
              <span className="text-[10px] mt-1">MIN</span>
            </div>
            <span className="self-center text-2xl">:</span>
            <div className="flex flex-col items-center">
              <span className="bg-black/30 px-2 py-1 rounded min-w-[2.5rem]">
                {String(tempo.segundos).padStart(2, "0")}
              </span>
              <span className="text-[10px] mt-1">SEG</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
