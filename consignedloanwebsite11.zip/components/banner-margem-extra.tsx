"use client"

import { Button } from "@/components/ui/button"
import {
  Sparkles,
  TrendingUp,
  Wallet,
  ArrowRight,
  Percent,
  DollarSign,
  Zap,
  Gift,
  Star,
  BadgeCheck,
} from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"
import Image from "next/image"

export function BannerMargemExtra() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-blue-700 to-secondary" />

      <div className="absolute inset-0 overflow-hidden">
        {/* Círculos brilhantes mais impactantes */}
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-secondary/40 rounded-full blur-3xl animate-pulse" />
        <div
          className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-primary/30 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-white/5 rounded-full blur-3xl" />

        {/* Grid pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />

        {/* Ícones flutuantes animados */}
        <div
          className="absolute top-[10%] left-[5%] animate-bounce"
          style={{ animationDelay: "0s", animationDuration: "3s" }}
        >
          <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-xl">
            <DollarSign className="w-10 h-10 text-yellow-300" />
          </div>
        </div>
        <div
          className="absolute top-[15%] right-[8%] animate-bounce"
          style={{ animationDelay: "0.5s", animationDuration: "3.5s" }}
        >
          <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-xl">
            <TrendingUp className="w-12 h-12 text-green-300" />
          </div>
        </div>
        <div
          className="absolute bottom-[30%] left-[10%] animate-bounce"
          style={{ animationDelay: "1s", animationDuration: "4s" }}
        >
          <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-xl">
            <Percent className="w-8 h-8 text-yellow-200" />
          </div>
        </div>
        <div
          className="absolute bottom-[20%] right-[15%] animate-bounce"
          style={{ animationDelay: "1.5s", animationDuration: "3.2s" }}
        >
          <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-xl">
            <Wallet className="w-14 h-14 text-cyan-200" />
          </div>
        </div>

        {/* Estrelas decorativas */}
        <div className="absolute top-[25%] left-[25%] animate-pulse">
          <Star className="w-6 h-6 text-yellow-300 fill-yellow-300" />
        </div>
        <div className="absolute top-[35%] right-[30%] animate-pulse" style={{ animationDelay: "0.5s" }}>
          <Star className="w-4 h-4 text-yellow-200 fill-yellow-200" />
        </div>
        <div className="absolute bottom-[40%] left-[35%] animate-pulse" style={{ animationDelay: "1s" }}>
          <Star className="w-5 h-5 text-white fill-white" />
        </div>
      </div>

      {/* Padrão de ondas */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-24 fill-background">
          <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Conteúdo textual */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-orange-400 text-yellow-900 px-6 py-3 rounded-full text-sm font-black mb-8 shadow-2xl shadow-yellow-400/40 animate-pulse">
              <Gift className="w-5 h-5" />
              <span>OPORTUNIDADE EXCLUSIVA 2024/2025</span>
              <Zap className="w-5 h-5" />
            </div>

            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-white mb-6 text-balance leading-tight">
              Margem Extra
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-orange-300 to-green-300">
                Liberada!
              </span>
            </h2>

            <div className="inline-flex items-center justify-center gap-4 bg-white/15 backdrop-blur-md px-10 py-6 rounded-3xl border-2 border-white/30 mb-8 shadow-2xl">
              <Sparkles className="w-10 h-10 text-yellow-300 animate-pulse" />
              <span className="text-4xl md:text-5xl font-black text-white">
                ATÉ <span className="text-yellow-300 text-6xl">5%</span> EXTRA
              </span>
              <Sparkles className="w-10 h-10 text-yellow-300 animate-pulse" />
            </div>

            {/* Subtítulo */}
            <p className="text-2xl md:text-3xl text-white/95 mb-4 font-bold">Veja se você tem direito!</p>

            {/* Descrição */}
            <p className="text-lg md:text-xl text-white/85 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Consiga crédito adicional sem aumentar sua parcela! Beneficiários do INSS podem ter até{" "}
              <span className="text-yellow-300 font-bold">5% de margem extra</span> além do limite normal.
            </p>

            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-yellow-400 via-orange-400 to-yellow-500 hover:from-yellow-300 hover:via-orange-300 hover:to-yellow-400 text-yellow-900 font-black text-xl px-14 py-10 rounded-full shadow-2xl shadow-yellow-400/50 transition-all duration-300 hover:scale-110 hover:shadow-yellow-400/70 border-4 border-yellow-200/50"
            >
              <a href={getWhatsAppLink(mensagensWhatsApp.margemExtra)} target="_blank" rel="noopener noreferrer">
                <BadgeCheck className="mr-3 w-7 h-7" />
                Consultar Minha Margem
                <ArrowRight className="ml-3 w-7 h-7" />
              </a>
            </Button>

            {/* Informação adicional */}
            <p className="mt-8 text-white/70 text-base flex items-center justify-center lg:justify-start gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              Consulta gratuita e sem compromisso | Atendimento em até 24h
            </p>
          </div>

          <div className="hidden lg:block">
            <div className="relative">
              {/* Efeito de brilho atrás da imagem */}
              <div className="absolute -inset-8 bg-gradient-to-br from-yellow-400/40 via-white/20 to-secondary/40 rounded-3xl blur-3xl" />

              <Image
                src="/placeholder.svg?height=550&width=550"
                alt="Aposentado feliz recebendo notícia de margem extra aprovada"
                width={550}
                height={550}
                className="relative z-10 rounded-3xl shadow-2xl object-cover border-4 border-white/20"
              />

              {/* Badge flutuante de aprovação */}
              <div
                className="absolute -top-6 -left-6 bg-white rounded-2xl p-5 shadow-2xl z-20 animate-bounce"
                style={{ animationDuration: "3s" }}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-3 rounded-full">
                    <BadgeCheck className="text-green-600" size={28} />
                  </div>
                  <div>
                    <p className="text-green-600 font-black text-xl">+5% Liberado!</p>
                    <p className="text-gray-500 text-sm">Margem Extra</p>
                  </div>
                </div>
              </div>

              {/* Badge de valor */}
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-secondary to-green-500 text-white rounded-2xl p-5 shadow-2xl z-20">
                <p className="text-sm font-medium">Crédito adicional de até</p>
                <p className="text-3xl font-black">R$ 20.000</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
