"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calculator, FileText, CheckCircle, Banknote, ArrowRight, Clock, Shield } from "lucide-react"

const etapas = [
  {
    numero: 1,
    titulo: "Simulação",
    descricao: "Faça uma simulação gratuita e descubra quanto pode liberar. Sem compromisso!",
    icone: Calculator,
    tempo: "5 minutos",
    cor: "from-blue-500 to-blue-600",
  },
  {
    numero: 2,
    titulo: "Envio de Documentos",
    descricao: "Envie RG, CPF, comprovante de benefício e extrato pelo WhatsApp. Simples e seguro.",
    icone: FileText,
    tempo: "10 minutos",
    cor: "from-purple-500 to-purple-600",
  },
  {
    numero: 3,
    titulo: "Aprovação",
    descricao: "Nossa equipe analisa sua proposta e você recebe a aprovação rapidamente.",
    icone: CheckCircle,
    tempo: "Até 24h",
    cor: "from-orange-500 to-orange-600",
  },
  {
    numero: 4,
    titulo: "Liberação do Dinheiro",
    descricao: "Após assinatura digital do contrato, o dinheiro cai na sua conta!",
    icone: Banknote,
    tempo: "Até 48h",
    cor: "from-green-500 to-green-600",
  },
]

export function LinhaTempoProcesso() {
  const [etapaAtiva, setEtapaAtiva] = useState(0)

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300 mb-4">
            <Clock className="w-4 h-4 mr-2" />
            Processo Simplificado
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Como Funciona o Processo</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Do início ao fim, acompanhe cada etapa da sua contratação. Transparência e agilidade em todo o processo.
          </p>
        </div>

        {/* Linha do Tempo Desktop */}
        <div className="hidden lg:block relative">
          {/* Linha conectora */}
          <div className="absolute top-16 left-0 right-0 h-1 bg-muted z-0">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-green-600 transition-all duration-500"
              style={{ width: `${(etapaAtiva / (etapas.length - 1)) * 100}%` }}
            />
          </div>

          <div className="grid grid-cols-4 gap-8 relative z-10">
            {etapas.map((etapa, index) => {
              const Icone = etapa.icone
              const isAtiva = index <= etapaAtiva

              return (
                <div
                  key={index}
                  className="flex flex-col items-center cursor-pointer group"
                  onClick={() => setEtapaAtiva(index)}
                >
                  {/* Círculo com ícone */}
                  <div
                    className={`
                    w-32 h-32 rounded-full flex items-center justify-center mb-6
                    transition-all duration-500 shadow-lg
                    ${
                      isAtiva
                        ? `bg-gradient-to-r ${etapa.cor} text-white scale-110`
                        : "bg-card text-muted-foreground border-4 border-muted group-hover:border-green-300"
                    }
                  `}
                  >
                    <Icone className="w-12 h-12" />
                  </div>

                  {/* Número */}
                  <div
                    className={`
                    w-8 h-8 rounded-full flex items-center justify-center mb-4
                    font-bold text-sm transition-all duration-300
                    ${isAtiva ? "bg-green-600 text-white" : "bg-muted text-muted-foreground"}
                  `}
                  >
                    {etapa.numero}
                  </div>

                  {/* Conteúdo */}
                  <h3
                    className={`text-xl font-bold mb-2 transition-colors ${isAtiva ? "text-foreground" : "text-muted-foreground"}`}
                  >
                    {etapa.titulo}
                  </h3>
                  <p
                    className={`text-center text-sm mb-3 transition-colors ${isAtiva ? "text-muted-foreground" : "text-muted-foreground/60"}`}
                  >
                    {etapa.descricao}
                  </p>
                  <Badge
                    className={`${isAtiva ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300" : "bg-muted text-muted-foreground"}`}
                  >
                    <Clock className="w-3 h-3 mr-1" />
                    {etapa.tempo}
                  </Badge>
                </div>
              )
            })}
          </div>
        </div>

        {/* Linha do Tempo Mobile */}
        <div className="lg:hidden space-y-4">
          {etapas.map((etapa, index) => {
            const Icone = etapa.icone

            return (
              <Card key={index} className="overflow-hidden bg-card">
                <div className={`h-2 bg-gradient-to-r ${etapa.cor}`} />
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-14 h-14 rounded-full bg-gradient-to-r ${etapa.cor} flex items-center justify-center text-white flex-shrink-0`}
                    >
                      <Icone className="w-7 h-7" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-6 h-6 rounded-full bg-green-600 text-white flex items-center justify-center text-sm font-bold">
                          {etapa.numero}
                        </span>
                        <h3 className="font-bold text-foreground">{etapa.titulo}</h3>
                      </div>
                      <p className="text-muted-foreground text-sm mb-2">{etapa.descricao}</p>
                      <Badge className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                        <Clock className="w-3 h-3 mr-1" />
                        {etapa.tempo}
                      </Badge>
                    </div>
                  </div>
                  {index < etapas.length - 1 && (
                    <div className="flex justify-center mt-4">
                      <ArrowRight className="w-5 h-5 text-muted-foreground/50 rotate-90" />
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Garantia */}
        <div className="mt-12 p-6 bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-2xl flex flex-col md:flex-row items-center justify-center gap-4 text-center md:text-left">
          <Shield className="w-12 h-12 text-green-600 dark:text-green-400" />
          <div>
            <p className="font-bold text-green-800 dark:text-green-300 text-lg">Processo 100% Seguro e Transparente</p>
            <p className="text-green-700 dark:text-green-400">
              Nunca fez consignado? Fique tranquilo! Nossa equipe acompanha você em cada etapa.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
