"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Search, CheckCircle2, HelpCircle, Shield, Banknote, ArrowRight, Sparkles, Lock } from "lucide-react"

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
)

export function VerificadorMargem() {
  const [cpf, setCpf] = useState("")
  const [nome, setNome] = useState("")
  const [telefone, setTelefone] = useState("")

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers
      .slice(0, 11)
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})$/, "$1-$2")
  }

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers
      .slice(0, 11)
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
  }

  const handleSubmit = () => {
    const mensagem = `Olá! Gostaria de consultar minha margem disponível.%0A%0ANome: ${nome}%0ACPF: ${cpf}%0ATelefone: ${telefone}`
    window.open(`https://wa.me/5531999999999?text=${mensagem}`, "_blank")
  }

  const beneficios = [
    {
      icone: Banknote,
      titulo: "O que é margem?",
      descricao:
        "É o valor máximo que pode ser descontado do seu benefício para empréstimo consignado. Geralmente é 35% do valor do benefício.",
    },
    {
      icone: CheckCircle2,
      titulo: "Por que é gratuita?",
      descricao:
        "A consulta de margem é um direito seu! Não cobramos nada para verificar quanto você tem disponível para empréstimo.",
    },
    {
      icone: Shield,
      titulo: "Sem compromisso",
      descricao: "Consultar sua margem não gera nenhum compromisso. Você só contrata se quiser e quando quiser.",
    },
  ]

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 mb-4">
            <Sparkles className="w-4 h-4 mr-2" />
            Consulta Gratuita
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Verificador de Margem Grátis</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Descubra quanto você tem disponível para empréstimo. É rápido, gratuito e sem compromisso!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Formulário */}
          <Card className="shadow-2xl border-border overflow-hidden bg-card">
            <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-500" />
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
              <CardTitle className="flex items-center gap-3 text-2xl">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                  <Search className="w-6 h-6" />
                </div>
                Consulte Sua Margem Disponível
              </CardTitle>
              <p className="text-green-100 mt-2">
                Preencha seus dados e nossa equipe entrará em contato com o resultado.
              </p>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-2">
                <Label htmlFor="nome" className="text-foreground font-medium">
                  Nome Completo
                </Label>
                <Input
                  id="nome"
                  placeholder="Digite seu nome completo"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="h-12 border-border focus:border-green-500 focus:ring-green-500 bg-background text-foreground"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cpf" className="text-foreground font-medium">
                  CPF
                </Label>
                <Input
                  id="cpf"
                  placeholder="000.000.000-00"
                  value={cpf}
                  onChange={(e) => setCpf(formatCPF(e.target.value))}
                  className="h-12 border-border focus:border-green-500 focus:ring-green-500 bg-background text-foreground"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="telefone" className="text-foreground font-medium">
                  WhatsApp
                </Label>
                <Input
                  id="telefone"
                  placeholder="(00) 00000-0000"
                  value={telefone}
                  onChange={(e) => setTelefone(formatPhone(e.target.value))}
                  className="h-12 border-border focus:border-green-500 focus:ring-green-500 bg-background text-foreground"
                />
              </div>

              <Button
                onClick={handleSubmit}
                className="w-full h-14 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-lg font-semibold shadow-lg text-white"
              >
                <WhatsAppIcon className="w-5 h-5 mr-2" />
                Consultar Margem Grátis
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>

              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Lock className="w-4 h-4" />
                Seus dados estão seguros e protegidos
              </div>
            </CardContent>
          </Card>

          {/* Explicações */}
          <div className="space-y-6">
            {beneficios.map((beneficio, index) => {
              const Icone = beneficio.icone
              return (
                <Card
                  key={index}
                  className="border-border shadow-lg hover:shadow-xl transition-shadow duration-300 bg-card"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center text-white flex-shrink-0">
                        <Icone className="w-7 h-7" />
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground text-lg mb-2 flex items-center gap-2">
                          {beneficio.titulo}
                          <HelpCircle className="w-4 h-4 text-muted-foreground" />
                        </h3>
                        <p className="text-muted-foreground">{beneficio.descricao}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}

            <Card className="border-0 bg-slate-950 shadow-2xl overflow-hidden">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center mx-auto mb-4">
                  <WhatsAppIcon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-white text-xl mb-2">Prefere falar diretamente?</h3>
                <p className="text-slate-300 mb-6">Chame no WhatsApp e consulte sua margem agora mesmo!</p>
                <Button
                  className="bg-green-500 hover:bg-green-600 text-white font-semibold h-12 px-6"
                  onClick={() => window.open("https://wa.me/5531999999999", "_blank")}
                >
                  <WhatsAppIcon className="w-5 h-5 mr-2" />
                  Chamar no WhatsApp
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
