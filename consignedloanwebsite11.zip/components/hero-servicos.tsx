"use client"

import { ArrowRight, CreditCard, Shield, Percent, CheckCircle, Sparkles, Gift, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const TELEFONE_WHATSAPP = "5531982190475"
const MENSAGEM_WHATSAPP = "Olá, quero saber mais sobre o Cartão Consignado!"

export function HeroServicos() {
  const handleWhatsAppClick = () => {
    const mensagemCodificada = encodeURIComponent(MENSAGEM_WHATSAPP)
    const url = `https://wa.me/${TELEFONE_WHATSAPP}?text=${mensagemCodificada}`
    window.open(url, "_blank")
  }

  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-gradient-to-br from-violet-950 via-purple-900 to-fuchsia-900">
      {/* Efeitos de luz de fundo */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[700px] h-[700px] bg-fuchsia-500/30 rounded-full blur-[150px] -translate-y-1/3 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-violet-500/25 rounded-full blur-[120px] translate-y-1/3 -translate-x-1/4" />
        <div className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-pink-500/20 rounded-full blur-[100px] -translate-x-1/2 -translate-y-1/2" />
      </div>

      {/* Grid pattern sutil */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
          backgroundSize: "50px 50px",
        }}
      />

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Lado esquerdo - Conteúdo */}
          <div className="text-white space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 backdrop-blur-sm border border-yellow-400/30 px-5 py-2.5 rounded-full">
              <CreditCard className="w-5 h-5 text-yellow-400" />
              <span className="text-sm font-semibold text-yellow-300">NOVO! Cartão Consignado</span>
            </div>

            {/* Título principal */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight">
                <span className="text-white">Cartão</span>
                <br />
                <span className="bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 bg-clip-text text-transparent">
                  Consignado
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-white/80 max-w-lg leading-relaxed">
                O cartão de crédito exclusivo para aposentados e pensionistas do INSS.
                <span className="text-yellow-300 font-semibold"> Limite alto e desconto em folha!</span>
              </p>
            </div>

            {/* Cards de benefícios */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Gift, label: "Anuidade Zero", desc: "Sem taxas escondidas" },
                { icon: Wallet, label: "Limite Alto", desc: "Até 1,6x o benefício" },
                { icon: Shield, label: "100% Seguro", desc: "Bandeira Mastercard" },
                { icon: Percent, label: "Juros Baixos", desc: "Menores do mercado" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="group bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 hover:bg-white/15 hover:border-white/30 hover:scale-105 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 rounded-xl bg-gradient-to-br from-yellow-400/30 to-orange-400/30 text-yellow-300 group-hover:scale-110 transition-transform">
                      <item.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm">{item.label}</p>
                      <p className="text-white/60 text-xs">{item.desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleWhatsAppClick}
                size="lg"
                className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black shadow-lg shadow-yellow-500/30 text-lg px-8 py-7 h-auto font-bold group transition-all hover:scale-105"
              >
                <CreditCard className="mr-2 w-5 h-5" />
                Solicitar Meu Cartão
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <div className="flex items-center gap-2 text-white/70 text-sm bg-white/5 px-3 py-1.5 rounded-full">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Sem anuidade
              </div>
              <div className="flex items-center gap-2 text-white/70 text-sm bg-white/5 px-3 py-1.5 rounded-full">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Aprovação facilitada
              </div>
              <div className="flex items-center gap-2 text-white/70 text-sm bg-white/5 px-3 py-1.5 rounded-full">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Saque disponível
              </div>
            </div>
          </div>

          {/* Lado direito - Imagem e Cards flutuantes */}
          <div className="relative hidden lg:block">
            {/* Círculos decorativos */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-[480px] h-[480px] rounded-full border border-white/10 animate-pulse" />
              <div className="absolute w-[380px] h-[380px] rounded-full border border-fuchsia-500/20" />
            </div>

            <div className="relative z-10">
              <Image
                src="/happy-senior-woman-holding-golden-credit-card-smil.jpg"
                alt="Aposentada feliz com cartão consignado"
                width={520}
                height={520}
                className="rounded-3xl shadow-2xl shadow-purple-900/50 object-cover"
                priority
              />

              {/* Card flutuante - Cartão Aprovado */}
              <div className="absolute -top-6 -left-6 bg-white rounded-2xl p-4 shadow-2xl animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-green-600 font-bold text-sm">Cartão Aprovado!</p>
                    <p className="text-gray-500 text-xs">Mastercard Gold</p>
                  </div>
                </div>
              </div>

              {/* Card flutuante - Limite */}
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-br from-violet-600 to-purple-700 text-white rounded-2xl p-5 shadow-2xl animate-float-delayed">
                <p className="text-xs font-medium opacity-80">Seu Limite</p>
                <p className="text-3xl font-bold">R$ 4.500</p>
                <div className="flex items-center gap-1 mt-1">
                  <Sparkles className="w-3 h-3 text-yellow-300" />
                  <p className="text-xs opacity-80">Disponível agora</p>
                </div>
              </div>

              {/* Card flutuante - Benefícios */}
              <div
                className="absolute top-1/3 -right-10 bg-white rounded-2xl p-3 shadow-2xl animate-float"
                style={{ animationDelay: "0.8s" }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                    <Gift className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Anuidade</p>
                    <p className="text-sm font-bold text-green-600">GRÁTIS!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Onda decorativa inferior */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path d="M0,60 C360,120 1080,0 1440,60 L1440,120 L0,120 Z" fill="hsl(var(--background))" />
        </svg>
      </div>
    </section>
  )
}
