"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Sparkles,
  Clock,
  User,
  CreditCard,
  Target,
  PartyPopper,
} from "lucide-react"

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
)

const perguntas = [
  {
    id: 1,
    pergunta: "Você é aposentado ou pensionista do INSS?",
    icone: User,
    opcoes: [
      { texto: "Sim, sou aposentado(a)", valor: "aposentado" },
      { texto: "Sim, sou pensionista", valor: "pensionista" },
      { texto: "Sou servidor público", valor: "servidor" },
      { texto: "Nenhuma das opções", valor: "outro" },
    ],
  },
  {
    id: 2,
    pergunta: "Você já tem algum empréstimo consignado ativo?",
    icone: CreditCard,
    opcoes: [
      { texto: "Sim, tenho consignado ativo", valor: "sim" },
      { texto: "Não, nunca fiz consignado", valor: "nao" },
      { texto: "Tive, mas já quitei", valor: "quitado" },
      { texto: "Não sei informar", valor: "nao_sei" },
    ],
  },
  {
    id: 3,
    pergunta: "Para que você precisa do dinheiro?",
    icone: Target,
    opcoes: [
      { texto: "Pagar dívidas", valor: "dividas" },
      { texto: "Reforma ou compra", valor: "reforma" },
      { texto: "Emergência médica", valor: "saude" },
      { texto: "Outro motivo", valor: "outro" },
    ],
  },
]

const resultados: Record<string, { titulo: string; descricao: string; servico: string }> = {
  aposentado_sim: {
    titulo: "Portabilidade com Troco!",
    descricao: "Você pode transferir seu consignado para uma taxa menor e ainda receber dinheiro extra na conta.",
    servico: "Portabilidade",
  },
  aposentado_nao: {
    titulo: "Empréstimo Consignado Novo",
    descricao: "Você tem margem disponível para um novo empréstimo com as melhores taxas do mercado.",
    servico: "Consignado Novo",
  },
  pensionista_sim: {
    titulo: "Refinanciamento",
    descricao: "Refinancie seu consignado atual e reduza suas parcelas ou libere mais dinheiro.",
    servico: "Refinanciamento",
  },
  pensionista_nao: {
    titulo: "Primeiro Consignado",
    descricao: "Parabéns! Você pode fazer seu primeiro consignado com condições especiais.",
    servico: "Consignado Novo",
  },
  servidor_sim: {
    titulo: "Portabilidade Servidor",
    descricao: "Servidores públicos têm acesso às melhores taxas. Transfira e economize!",
    servico: "Portabilidade",
  },
  servidor_nao: {
    titulo: "Consignado para Servidor",
    descricao: "Taxas exclusivas para servidores públicos. Simule agora!",
    servico: "Consignado Novo",
  },
  default: {
    titulo: "Temos uma solução para você!",
    descricao: "Nossa equipe vai analisar seu caso e encontrar a melhor opção.",
    servico: "Consultoria",
  },
}

export function QuizRapido() {
  const [iniciado, setIniciado] = useState(false)
  const [etapaAtual, setEtapaAtual] = useState(0)
  const [respostas, setRespostas] = useState<Record<number, string>>({})
  const [finalizado, setFinalizado] = useState(false)

  const handleResposta = (valor: string) => {
    const novasRespostas = { ...respostas, [etapaAtual]: valor }
    setRespostas(novasRespostas)

    if (etapaAtual < perguntas.length - 1) {
      setEtapaAtual(etapaAtual + 1)
    } else {
      setFinalizado(true)
    }
  }

  const handleVoltar = () => {
    if (etapaAtual > 0) {
      setEtapaAtual(etapaAtual - 1)
    }
  }

  const handleReiniciar = () => {
    setIniciado(false)
    setEtapaAtual(0)
    setRespostas({})
    setFinalizado(false)
  }

  const getResultado = () => {
    const perfil = respostas[0] || "default"
    const temConsignado = respostas[1] || "nao"
    const chave = `${perfil}_${temConsignado}`
    return resultados[chave] || resultados.default
  }

  const handleWhatsApp = () => {
    const resultado = getResultado()
    const mensagem = `Olá! Fiz o quiz no site e descobri que a melhor opção para mim é: ${resultado.servico}. Gostaria de mais informações!`
    window.open(`https://wa.me/5531999999999?text=${encodeURIComponent(mensagem)}`, "_blank")
  }

  if (!iniciado) {
    return (
      <section className="py-16 bg-gradient-to-r from-green-600 to-emerald-600">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto border-0 shadow-2xl overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <Badge className="bg-green-100 text-green-700 mb-4">
                <Clock className="w-4 h-4 mr-2" />
                Apenas 30 segundos
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Descubra a Melhor Opção Para Você</h2>
              <p className="text-gray-600 text-lg mb-8">
                Responda 3 perguntas rápidas e descubra qual serviço de crédito consignado é ideal para o seu perfil.
              </p>
              <Button
                onClick={() => setIniciado(true)}
                className="h-14 px-8 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-lg font-semibold shadow-lg"
              >
                Começar Quiz Grátis
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  if (finalizado) {
    const resultado = getResultado()
    return (
      <section className="py-16 bg-gradient-to-r from-green-600 to-emerald-600">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto border-0 shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-yellow-400 to-orange-500" />
            <CardContent className="p-8 md:p-12 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6 animate-bounce">
                <PartyPopper className="w-10 h-10 text-white" />
              </div>
              <Badge className="bg-green-100 text-green-700 mb-4">
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Resultado do Quiz
              </Badge>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">{resultado.titulo}</h2>
              <p className="text-gray-600 text-lg mb-8">{resultado.descricao}</p>

              <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
                <p className="text-green-800 font-medium">
                  Serviço recomendado: <span className="font-bold">{resultado.servico}</span>
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleWhatsApp}
                  className="h-14 px-8 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-lg font-semibold shadow-lg"
                >
                  <WhatsAppIcon className="w-5 h-5 mr-2" />
                  Falar com Especialista
                </Button>
                <Button
                  onClick={handleReiniciar}
                  variant="outline"
                  className="h-14 px-8 border-gray-300 bg-transparent"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Refazer Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  const perguntaAtual = perguntas[etapaAtual]
  const Icone = perguntaAtual.icone
  const progresso = ((etapaAtual + 1) / perguntas.length) * 100

  return (
    <section className="py-16 bg-gradient-to-r from-green-600 to-emerald-600">
      <div className="container mx-auto px-4">
        <Card className="max-w-2xl mx-auto border-0 shadow-2xl overflow-hidden">
          {/* Barra de progresso */}
          <div className="h-2 bg-gray-200">
            <div
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-500"
              style={{ width: `${progresso}%` }}
            />
          </div>

          <CardContent className="p-8 md:p-12">
            <div className="text-center mb-8">
              <div className="flex items-center justify-between mb-6">
                {etapaAtual > 0 && (
                  <Button variant="ghost" onClick={handleVoltar} className="text-gray-500 hover:text-gray-700">
                    <ArrowLeft className="w-5 h-5 mr-2" />
                    Voltar
                  </Button>
                )}
                <Badge className="bg-gray-100 text-gray-600 ml-auto">
                  Pergunta {etapaAtual + 1} de {perguntas.length}
                </Badge>
              </div>

              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6">
                <Icone className="w-8 h-8 text-white" />
              </div>

              <h3 className="text-2xl font-bold text-gray-900 mb-8">{perguntaAtual.pergunta}</h3>
            </div>

            <div className="space-y-4">
              {perguntaAtual.opcoes.map((opcao, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleResposta(opcao.valor)}
                  className="w-full h-14 text-left justify-start text-base font-medium border-2 border-gray-200 hover:border-green-500 hover:bg-green-50 transition-all duration-300"
                >
                  <span className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mr-4 text-gray-600 font-bold">
                    {String.fromCharCode(65 + index)}
                  </span>
                  {opcao.texto}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
