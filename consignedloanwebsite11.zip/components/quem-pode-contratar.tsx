"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Heart, Building2, Shield, HandHeart, AlertCircle, ArrowRight } from "lucide-react"
import { getWhatsAppLink } from "@/lib/whatsapp"

export function QuemPodeContratar() {
  const perfis = [
    {
      icon: User,
      titulo: "Aposentado",
      descricao: "Aposentados do INSS por idade, tempo de contribuição ou invalidez",
      cor: "from-blue-500 to-blue-600",
      destaque: "Margem de até 35%",
      mensagem: "Olá! Sou aposentado do INSS e gostaria de simular um empréstimo consignado.",
    },
    {
      icon: Heart,
      titulo: "Pensionista",
      descricao: "Pensionistas do INSS que recebem pensão por morte",
      cor: "from-pink-500 to-pink-600",
      destaque: "Margem de até 35%",
      mensagem: "Olá! Sou pensionista do INSS e gostaria de simular um empréstimo consignado.",
    },
    {
      icon: Building2,
      titulo: "Servidor Público",
      descricao: "Servidores federais, estaduais e municipais ativos ou inativos",
      cor: "from-emerald-500 to-emerald-600",
      destaque: "Taxas diferenciadas",
      mensagem: "Olá! Sou servidor público e gostaria de simular um empréstimo consignado.",
    },
    {
      icon: Shield,
      titulo: "Militar",
      descricao: "Militares das Forças Armadas (Exército, Marinha e Aeronáutica)",
      cor: "from-amber-500 to-amber-600",
      destaque: "Condições especiais",
      mensagem: "Olá! Sou militar e gostaria de simular um empréstimo consignado.",
    },
    {
      icon: HandHeart,
      titulo: "LOAS/BPC",
      descricao: "Beneficiários do Benefício de Prestação Continuada",
      cor: "from-purple-500 to-purple-600",
      destaque: "Crédito acessível",
      mensagem: "Olá! Sou beneficiário do LOAS/BPC e gostaria de simular um empréstimo consignado.",
    },
    {
      icon: AlertCircle,
      titulo: "Negativados",
      descricao: "Pessoas com nome negativado também podem contratar o consignado",
      cor: "from-red-500 to-red-600",
      destaque: "Sem consulta ao SPC/Serasa",
      mensagem: "Olá! Estou negativado e gostaria de saber se posso contratar empréstimo consignado.",
    },
  ]

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-semibold mb-4">
            QUEM PODE CONTRATAR
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Identifique seu perfil</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            O crédito consignado é a melhor opção para diversos perfis. Veja se você se enquadra em uma das categorias
            abaixo.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {perfis.map((perfil, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 overflow-hidden group"
            >
              <CardContent className="p-0">
                {/* Header do card com gradiente */}
                <div className={`bg-gradient-to-r ${perfil.cor} p-6 text-white`}>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <perfil.icon className="w-7 h-7" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{perfil.titulo}</h3>
                      <span className="text-sm text-white/80">{perfil.destaque}</span>
                    </div>
                  </div>
                </div>

                {/* Corpo do card */}
                <div className="p-6 bg-card">
                  <p className="text-muted-foreground mb-4">{perfil.descricao}</p>
                  <Button asChild variant="outline" className="w-full bg-transparent">
                    <a href={getWhatsAppLink(perfil.mensagem)} target="_blank" rel="noopener noreferrer">
                      Simular para meu perfil
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Nota importante */}
        <div className="mt-12 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl p-6 md:p-8">
          <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-8 h-8 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-foreground mb-2">Importante: Análise personalizada</h3>
              <p className="text-muted-foreground">
                Cada caso é único. Entre em contato conosco para uma análise personalizada da sua situação e descubra as
                melhores condições disponíveis para o seu perfil.
              </p>
            </div>
            <Button asChild size="lg">
              <a
                href={getWhatsAppLink(
                  "Olá! Gostaria de fazer uma análise personalizada do meu perfil para crédito consignado.",
                )}
                target="_blank"
                rel="noopener noreferrer"
              >
                Falar com Consultor
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
