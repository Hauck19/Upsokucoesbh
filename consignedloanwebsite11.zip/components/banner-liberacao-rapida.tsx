"use client"

import { motion } from "framer-motion"
import { Zap, Clock, CheckCircle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

export function BannerLiberacaoRapida() {
  return (
    <section className="py-16 relative overflow-hidden">
      {/* Background com gradiente */}
      <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500" />

      {/* Efeito de raios/velocidade */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-1 bg-white/30 rounded-full"
            style={{
              width: `${100 + Math.random() * 200}px`,
              top: `${10 + i * 12}%`,
              left: "-200px",
            }}
            animate={{
              x: [0, 1500],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 1.5,
              repeat: Number.POSITIVE_INFINITY,
              delay: i * 0.2,
              ease: "easeOut",
            }}
          />
        ))}
      </div>

      {/* Ícones de relógio flutuantes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-10 left-[10%]"
          animate={{ y: [0, -15, 0], rotate: [0, 10, 0] }}
          transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
        >
          <Clock className="w-12 h-12 text-white/20" />
        </motion.div>
        <motion.div
          className="absolute top-20 right-[15%]"
          animate={{ y: [0, 15, 0], rotate: [0, -10, 0] }}
          transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY, delay: 0.5 }}
        >
          <Zap className="w-16 h-16 text-yellow-300/30" />
        </motion.div>
        <motion.div
          className="absolute bottom-10 left-[20%]"
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 1 }}
        >
          <CheckCircle className="w-10 h-10 text-white/20" />
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            {/* Ícone principal */}
            <motion.div
              className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mb-6"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
            >
              <Zap className="w-10 h-10 text-yellow-300" />
            </motion.div>

            {/* Título */}
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
              Aprovação Rápida — Dinheiro Cai na Conta <span className="text-yellow-300">no Mesmo Dia!</span>
            </h2>

            {/* Subtexto */}
            <p className="text-xl md:text-2xl text-white/90 mb-8">Processo 100% digital. Sem complicação. Sem filas.</p>

            {/* Indicadores de velocidade */}
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              <motion.div
                className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full"
                whileHover={{ scale: 1.05 }}
              >
                <Clock className="w-5 h-5 text-yellow-300" />
                <span className="text-white font-medium">Análise em minutos</span>
              </motion.div>
              <motion.div
                className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full"
                whileHover={{ scale: 1.05 }}
              >
                <CheckCircle className="w-5 h-5 text-green-300" />
                <span className="text-white font-medium">Aprovação instantânea</span>
              </motion.div>
              <motion.div
                className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full"
                whileHover={{ scale: 1.05 }}
              >
                <Zap className="w-5 h-5 text-yellow-300" />
                <span className="text-white font-medium">Crédito no mesmo dia</span>
              </motion.div>
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                asChild
                size="lg"
                className="bg-white text-orange-600 hover:bg-yellow-100 text-lg px-8 py-6 rounded-full font-bold shadow-2xl"
              >
                <a
                  href={getWhatsAppLink(mensagensWhatsApp.creditoRapido)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  Quero Meu Crédito Agora
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
