import { Building2, MapPin, Users, Award } from "lucide-react"
import Image from "next/image"

export function About() {
  return (
    <section id="about" className="py-24 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl font-bold text-balance mb-6">
              Conheça a <span className="text-primary">UP Soluções</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Somos uma empresa especializada em crédito consignado, comprometida em oferecer as melhores soluções
              financeiras para servidores públicos, aposentados e pensionistas. Trabalhamos com transparência, agilidade
              e as menores taxas do mercado, porque acreditamos que todos merecem acesso facilitado ao crédito de forma
              segura e responsável.
            </p>
          </div>

          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl blur-xl" />
              <Image
                src="/professional-business-team-meeting-in-modern-offic.jpg"
                alt="Equipe UP Soluções em reunião"
                width={500}
                height={400}
                className="relative z-10 rounded-3xl shadow-xl"
              />
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-balance text-center mb-6">
            Sobre a <span className="text-primary">UP Soluções</span>
          </h2>

          <p className="text-lg text-muted-foreground leading-relaxed text-center mb-4">
            Com mais de 15 anos de experiência no mercado de crédito consignado, a UP Soluções se consolidou como
            referência em Belo Horizonte, oferecendo soluções financeiras personalizadas com ética, transparência e
            respeito.
          </p>

          <p className="text-lg text-muted-foreground leading-relaxed text-center mb-8">
            Nossa missão é facilitar o acesso ao crédito consciente, ajudando nossos clientes a realizar seus sonhos e
            superar desafios financeiros com as melhores condições do mercado.
          </p>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <div className="relative group overflow-hidden rounded-2xl shadow-lg">
              <Image
                src="/financial-advisor-consulting-with-senior-couple-in.jpg"
                alt="Consultor financeiro atendendo casal de idosos"
                width={400}
                height={280}
                className="w-full h-[280px] object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                <p className="text-white font-semibold">Atendimento Personalizado</p>
              </div>
            </div>
            <div className="relative group overflow-hidden rounded-2xl shadow-lg">
              <Image
                src="/modern-corporate-office-interior-with-computers-an.jpg"
                alt="Escritório moderno da empresa"
                width={400}
                height={280}
                className="w-full h-[280px] object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                <p className="text-white font-semibold">Estrutura Moderna</p>
              </div>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Building2 className="text-primary" size={24} />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Empresa Sólida</h4>
                <p className="text-sm text-muted-foreground">15 anos no mercado</p>
              </div>
            </div>

            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Users className="text-secondary" size={24} />
              </div>
              <div>
                <h4 className="font-semibold mb-1">+5.000 Clientes</h4>
                <p className="text-sm text-muted-foreground">Atendidos com sucesso</p>
              </div>
            </div>

            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <MapPin className="text-primary" size={24} />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Belo Horizonte</h4>
                <p className="text-sm text-muted-foreground">Atendimento local</p>
              </div>
            </div>

            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Award className="text-secondary" size={24} />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Reconhecida</h4>
                <p className="text-sm text-muted-foreground">Excelência em serviço</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
