import { FileText, Camera, MapPin, Receipt, Briefcase, CheckCircle2, AlertCircle } from "lucide-react"
import { Card } from "@/components/ui/card"

const documentos = [
  {
    icon: FileText,
    titulo: "RG ou CNH",
    descricao: "Documento de identificação com foto, válido e legível",
    dica: "Frente e verso, sem cortes",
    obrigatorio: true,
  },
  {
    icon: Camera,
    titulo: "Selfie",
    descricao: "Foto do rosto segurando o documento de identidade",
    dica: "Ambiente bem iluminado",
    obrigatorio: true,
  },
  {
    icon: MapPin,
    titulo: "Comprovante de Residência",
    descricao: "Conta de luz, água, telefone ou correspondência bancária",
    dica: "Emitido nos últimos 3 meses",
    obrigatorio: true,
  },
  {
    icon: Receipt,
    titulo: "Extrato de Benefício",
    descricao: "Extrato do INSS com dados do benefício atualizado",
    dica: "Para aposentados e pensionistas",
    obrigatorio: false,
  },
  {
    icon: Briefcase,
    titulo: "Contracheque",
    descricao: "Último holerite ou demonstrativo de pagamento",
    dica: "Para servidores públicos",
    obrigatorio: false,
  },
]

export function DocumentosNecessarios() {
  return (
    <section className="py-16 bg-gradient-to-br from-background to-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-secondary/10 px-4 py-2 rounded-full mb-4">
            <FileText className="h-5 w-5 text-secondary" />
            <span className="text-sm font-semibold text-secondary">Documentação</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Documentos Necessários</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Tenha em mãos os documentos abaixo para agilizar sua contratação. O processo é 100% digital!
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {documentos.map((doc, index) => {
            const Icon = doc.icon
            return (
              <Card
                key={index}
                className="p-6 hover:shadow-lg transition-all duration-300 hover:border-primary/50 relative overflow-hidden"
              >
                {doc.obrigatorio && (
                  <div className="absolute top-3 right-3">
                    <span className="bg-primary/10 text-primary text-xs font-semibold px-2 py-1 rounded-full">
                      Obrigatório
                    </span>
                  </div>
                )}

                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>

                  <div className="flex-1">
                    <h3 className="font-bold text-lg mb-1">{doc.titulo}</h3>
                    <p className="text-muted-foreground text-sm mb-3">{doc.descricao}</p>

                    <div className="flex items-center gap-2 text-xs bg-secondary/10 text-secondary px-3 py-1.5 rounded-full w-fit">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {doc.dica}
                    </div>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Dicas importantes */}
        <div className="mt-12 max-w-4xl mx-auto">
          <Card className="p-6 bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              Dicas para Envio dos Documentos
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                  Envie fotos nítidas e sem reflexos
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                  Certifique-se que todas as informações estão legíveis
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                  Documentos não podem estar vencidos
                </li>
              </ul>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-secondary rounded-full mt-2" />
                  Comprovante de residência em seu nome ou de familiar
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-secondary rounded-full mt-2" />
                  Selfie com documento visível ao lado do rosto
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-secondary rounded-full mt-2" />
                  Evite sombras e cortes nas imagens
                </li>
              </ul>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
