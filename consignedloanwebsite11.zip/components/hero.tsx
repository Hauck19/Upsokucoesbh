"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle, Shield, Clock, Star, TrendingUp } from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"
import Image from "next/image"

export function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background with gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/95 to-primary/90" />

      {/* Decorative elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-secondary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-0 w-72 h-72 bg-white/10 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 text-white">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium border border-white/30">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span>Mais de 10.000 clientes satisfeitos</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance leading-tight">
              Seu Crédito Consignado <span className="text-secondary">Aprovado em 24h</span>
            </h1>

            <p className="text-lg md:text-xl text-white/90 leading-relaxed max-w-xl">
              As melhores taxas de Belo Horizonte para aposentados, pensionistas do INSS e servidores públicos.
              Atendimento humanizado e sem burocracia.
            </p>

            {/* Feature pills */}
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm">
                <Shield className="w-4 h-4 text-secondary" />
                <span>100% Seguro</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm">
                <Clock className="w-4 h-4 text-secondary" />
                <span>Rápido e Fácil</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm">
                <TrendingUp className="w-4 h-4 text-secondary" />
                <span>Menores Taxas</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                asChild
                size="lg"
                className="bg-secondary text-secondary-foreground hover:bg-secondary/90 text-base h-14 px-8 font-semibold shadow-lg shadow-secondary/30"
              >
                <a href={getWhatsAppLink(mensagensWhatsApp.proposta)} target="_blank" rel="noopener noreferrer">
                  Simular Agora
                  <ArrowRight className="ml-2" size={20} />
                </a>
              </Button>
              <Button
                onClick={() => {
                  const element = document.getElementById("services")
                  if (element) element.scrollIntoView({ behavior: "smooth" })
                }}
                size="lg"
                variant="outline"
                className="text-base h-14 px-8 bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white backdrop-blur-sm"
              >
                Ver Serviços
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-white/20">
              <div>
                <p className="text-3xl font-bold text-secondary">+10.000</p>
                <p className="text-sm text-white/70">Clientes atendidos</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-secondary">10 anos</p>
                <p className="text-sm text-white/70">No mercado</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-secondary">98%</p>
                <p className="text-sm text-white/70">Satisfação</p>
              </div>
            </div>
          </div>

          {/* Right Content - Image and floating cards */}
          <div className="relative hidden lg:block">
            {/* Main Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white/20">
              <Image
                src="/happy-senior-brazilian-couple-smiling-celebrating-.jpg"
                alt="Casal de aposentados felizes"
                width={500}
                height={600}
                className="w-full h-auto object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary/40 to-transparent" />
            </div>

            {/* Floating Card - Top Right */}
            <div className="absolute -top-4 -right-4 bg-white rounded-2xl p-4 shadow-xl animate-bounce-slow">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">Crédito Aprovado!</p>
                  <p className="text-xs text-muted-foreground">Em apenas 24 horas</p>
                </div>
              </div>
            </div>

            {/* Floating Card - Bottom Left */}
            <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl p-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">1,49%</p>
                  <p className="text-xs text-muted-foreground">Taxa a partir de</p>
                </div>
              </div>
            </div>

            {/* Stars decoration */}
            <div className="absolute top-1/2 -right-8 flex gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave decoration */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            className="fill-background"
          />
        </svg>
      </div>
    </section>
  )
}
