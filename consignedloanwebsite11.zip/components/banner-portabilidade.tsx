"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingDown, Percent, Clock, CheckCircle } from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

export function BannerPortabilidade() {
  return (
    <section className="relative py-16 overflow-hidden">
      {/* Background com gradiente */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/90 to-secondary" />

      {/* Padrão decorativo */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      {/* Ícones flutuantes */}
      <div className="absolute top-10 left-10 opacity-20">
        <Percent className="text-white" size={60} />
      </div>
      <div className="absolute bottom-10 right-10 opacity-20">
        <TrendingDown className="text-white" size={80} />
      </div>

      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Clock size={16} />
            Processo rápido e sem burocracia
          </div>

          {/* Título principal */}
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4 text-balance leading-tight">
            Está Pagando Juros Altos?
            <br />
            <span className="text-yellow-300">Faça a Portabilidade!</span>
          </h2>

          {/* Subtítulo */}
          <p className="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
            Reduza sua taxa sem mexer no seu benefício.
            <br />
            Traga sua dívida para uma taxa menor.
          </p>

          {/* Benefícios em linha */}
          <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-10">
            {["Sem custo", "Sem burocracia", "Processo 100% online", "Economia garantida"].map((beneficio, idx) => (
              <div key={idx} className="flex items-center gap-2 text-white">
                <CheckCircle className="text-yellow-300" size={20} />
                <span className="font-medium">{beneficio}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              asChild
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-bold text-lg px-8 py-6 shadow-xl"
            >
              <a href={getWhatsAppLink(mensagensWhatsApp.portabilidade)} target="_blank" rel="noopener noreferrer">
                Simular Portabilidade Grátis
                <ArrowRight className="ml-2" size={20} />
              </a>
            </Button>
          </div>

          {/* Estatística */}
          <p className="mt-8 text-white/80 text-sm">
            Mais de <strong className="text-white">500 clientes</strong> já economizaram com nossa portabilidade
          </p>
        </div>
      </div>
    </section>
  )
}
