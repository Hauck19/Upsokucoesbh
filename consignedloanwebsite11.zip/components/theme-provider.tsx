"use client"
import { ThemeProvider as NextThemesProvider, type ThemeProviderProps, useTheme as useNextTheme } from "next-themes"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>
}

export function useTheme() {
  const { theme, setTheme } = useNextTheme()

  const toggleTheme = () => {
    console.log("[v0] Current theme:", theme)
    const newTheme = theme === "light" ? "dark" : "light"
    console.log("[v0] Changing to:", newTheme)
    setTheme(newTheme)
  }

  return {
    theme,
    setTheme,
    toggleTheme,
  }
}
