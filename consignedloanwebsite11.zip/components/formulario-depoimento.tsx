"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Star, Send, CheckCircle, AlertCircle } from "lucide-react"

export function FormularioDepoimento() {
  const [nome, setNome] = useState("")
  const [depoimento, setDepoimento] = useState("")
  const [avaliacao, setAvaliacao] = useState(0)
  const [enviando, setEnviando] = useState(false)
  const [mensagem, setMensagem] = useState("")
  const [hoverAvaliacao, setHoverAvaliacao] = useState(0)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (avaliacao === 0) {
      setMensagem("Por favor, selecione pelo menos 1 estrela para avaliar.")
      return
    }

    setEnviando(true)
    setMensagem("")

    try {
      // Enviar depoimento
      const response = await fetch("/api/depoimentos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome_cliente: nome,
          depoimento,
          avaliacao,
          imagem_url: "",
        }),
      })

      if (response.ok) {
        setMensagem("Depoimento enviado com sucesso! Aguarde a aprovação.")
        setNome("")
        setDepoimento("")
        setAvaliacao(0)
      } else {
        setMensagem("Erro ao enviar depoimento. Tente novamente.")
      }
    } catch (error) {
      console.error("Erro ao enviar depoimento:", error)
      setMensagem("Erro ao enviar depoimento. Tente novamente.")
    } finally {
      setEnviando(false)
    }
  }

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 max-w-2xl">
        <Card className="p-8 shadow-xl border-0 bg-gradient-to-br from-card to-muted/30">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">Compartilhe Sua Experiência</h2>
            <p className="text-muted-foreground">Sua opinião é muito importante para nós e para outros clientes</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nome */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">Seu Nome Completo</label>
              <input
                type="text"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                required
                className="w-full px-4 py-3 border border-border rounded-xl focus:ring-2 focus:ring-primary focus:border-primary bg-background transition-all"
                placeholder="Digite seu nome"
              />
            </div>

            {/* Avaliação */}
            <div>
              <label className="block text-sm font-semibold mb-3 text-foreground">
                Como você avalia nosso atendimento?
              </label>
              <div className="flex gap-2 justify-center bg-muted/50 p-4 rounded-xl">
                {[1, 2, 3, 4, 5].map((estrela) => (
                  <button
                    key={estrela}
                    type="button"
                    onClick={() => setAvaliacao(estrela)}
                    onMouseEnter={() => setHoverAvaliacao(estrela)}
                    onMouseLeave={() => setHoverAvaliacao(0)}
                    className="transition-all duration-200 hover:scale-125 focus:outline-none"
                  >
                    <Star
                      className={`w-10 h-10 transition-colors ${
                        estrela <= (hoverAvaliacao || avaliacao)
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-muted-foreground/30"
                      }`}
                    />
                  </button>
                ))}
              </div>
              {avaliacao > 0 && (
                <p className="text-center text-sm text-muted-foreground mt-2">
                  {avaliacao === 5 && "Excelente! Obrigado!"}
                  {avaliacao === 4 && "Muito bom! Agradecemos!"}
                  {avaliacao === 3 && "Bom! Podemos melhorar."}
                  {avaliacao === 2 && "Regular. Vamos melhorar!"}
                  {avaliacao === 1 && "Precisamos conversar..."}
                </p>
              )}
            </div>

            {/* Depoimento */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">Seu Depoimento</label>
              <textarea
                value={depoimento}
                onChange={(e) => setDepoimento(e.target.value)}
                required
                rows={5}
                className="w-full px-4 py-3 border border-border rounded-xl focus:ring-2 focus:ring-primary focus:border-primary bg-background resize-none transition-all"
                placeholder="Conte-nos sobre sua experiência com a UP Soluções..."
              />
              <p className="text-xs text-muted-foreground mt-1 text-right">{depoimento.length}/500 caracteres</p>
            </div>

            {/* Mensagem de status */}
            {mensagem && (
              <div
                className={`flex items-center gap-3 p-4 rounded-xl ${
                  mensagem.includes("sucesso")
                    ? "bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400"
                    : "bg-red-50 text-red-800 dark:bg-red-900/20 dark:text-red-400"
                }`}
              >
                {mensagem.includes("sucesso") ? (
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                )}
                <p className="text-sm font-medium">{mensagem}</p>
              </div>
            )}

            {/* Botão enviar */}
            <Button
              type="submit"
              disabled={enviando || avaliacao === 0}
              className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-white font-semibold py-6 rounded-xl transition-all disabled:opacity-50"
              size="lg"
            >
              {enviando ? (
                <span className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Enviando...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  Enviar Depoimento
                </span>
              )}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Seu depoimento será analisado pela nossa equipe antes de ser publicado. Isso garante a qualidade e
              autenticidade das avaliações.
            </p>
          </form>
        </Card>
      </div>
    </section>
  )
}
