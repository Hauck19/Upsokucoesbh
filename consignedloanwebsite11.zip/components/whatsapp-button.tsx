"use client"

import { WhatsAppIcon } from "./whatsapp-icon"

export function WhatsAppButton() {
  // NÚMERO DO WHATSAPP - EDITE AQUI (formato: código do país + DDD + número)
  const phoneNumber = "5531982190475"

  // MENSAGEM PADRÃO - EDITE O TEXTO AQUI
  const message = "Olá! Gostaria de saber mais sobre os serviços da UP Soluções."

  const handleClick = () => {
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`
    window.open(url, "_blank")
  }

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] shadow-lg transition-all hover:scale-110 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-[#25D366]/50"
      aria-label="Contato via WhatsApp"
    >
      <WhatsAppIcon className="h-7 w-7 text-white" />
    </button>
  )
}
