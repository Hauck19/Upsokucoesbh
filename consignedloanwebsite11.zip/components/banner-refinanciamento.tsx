"use client"

import { motion } from "framer-motion"
import { DollarSign, TrendingUp, RefreshCw, ArrowRight, Banknote } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

export function BannerRefinanciamento() {
  return (
    <section className="py-16 relative overflow-hidden">
      {/* Background com gradiente verde/azul */}
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600" />

      {/* Padrão de fundo */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Ícones de dinheiro flutuantes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${10 + i * 15}%`,
              top: `${20 + (i % 3) * 25}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Number.POSITIVE_INFINITY,
              delay: i * 0.3,
            }}
          >
            <DollarSign className="w-8 h-8 text-white/30" />
          </motion.div>
        ))}
      </div>

      {/* Notas animadas entrando */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute right-0 top-1/4"
          animate={{ x: [100, -50, 100] }}
          transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
        >
          <Banknote className="w-24 h-24 text-green-300/20" />
        </motion.div>
        <motion.div
          className="absolute left-0 bottom-1/4"
          animate={{ x: [-100, 50, -100] }}
          transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, delay: 1 }}
        >
          <Banknote className="w-20 h-20 text-green-300/20" />
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            {/* Badge */}
            <motion.div
              className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              <TrendingUp className="w-5 h-5 text-green-300" />
              <span className="text-white font-medium">Oportunidade Especial</span>
            </motion.div>

            {/* Ícone principal */}
            <motion.div
              className="inline-flex items-center justify-center w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mb-6"
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            >
              <RefreshCw className="w-12 h-12 text-green-300" />
            </motion.div>

            {/* Título */}
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
              Quer Dinheiro Extra? <span className="text-green-300">Faça Seu Refinanciamento!</span>
            </h2>

            {/* Subtexto */}
            <p className="text-xl md:text-2xl text-white/90 mb-4">
              Libere crédito agora mesmo mantendo a mesma parcela ou até menor.
            </p>

            <p className="text-lg text-white/80 mb-8">
              Saque Suplementar disponível para quem já tem consignado ativo.
            </p>

            {/* Benefícios */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <motion.div
                className="bg-white/15 backdrop-blur-sm p-4 rounded-xl"
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.25)" }}
              >
                <DollarSign className="w-8 h-8 text-green-300 mx-auto mb-2" />
                <h3 className="text-white font-bold">Dinheiro Extra</h3>
                <p className="text-white/80 text-sm">Sem precisar de novo empréstimo</p>
              </motion.div>
              <motion.div
                className="bg-white/15 backdrop-blur-sm p-4 rounded-xl"
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.25)" }}
              >
                <TrendingUp className="w-8 h-8 text-green-300 mx-auto mb-2" />
                <h3 className="text-white font-bold">Taxas Menores</h3>
                <p className="text-white/80 text-sm">Aproveite condições melhores</p>
              </motion.div>
              <motion.div
                className="bg-white/15 backdrop-blur-sm p-4 rounded-xl"
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.25)" }}
              >
                <RefreshCw className="w-8 h-8 text-green-300 mx-auto mb-2" />
                <h3 className="text-white font-bold">Parcela Renovada</h3>
                <p className="text-white/80 text-sm">Estenda o prazo se precisar</p>
              </motion.div>
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                asChild
                size="lg"
                className="bg-white text-emerald-600 hover:bg-green-100 text-lg px-8 py-6 rounded-full font-bold shadow-2xl"
              >
                <a
                  href={getWhatsAppLink(mensagensWhatsApp.refinanciamento)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  Solicitar Análise Gratuita
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
