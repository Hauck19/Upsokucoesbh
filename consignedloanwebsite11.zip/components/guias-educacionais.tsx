"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  BookOpen,
  Calculator,
  ArrowLeftRight,
  TrendingUp,
  ShieldAlert,
  ChevronRight,
  Clock,
  User,
  Calendar,
} from "lucide-react"
import Image from "next/image"

const guias = [
  {
    id: "margem-consignavel",
    icon: Calculator,
    titulo: "O Que É Margem Consignável?",
    descricao: "Entenda como funciona o limite de desconto no seu benefício ou salário.",
    tempoLeitura: "5 min",
    conteudo: `
      <h3>O que é a Margem Consignável?</h3>
      <p>A margem consignável é o percentual máximo da sua renda que pode ser comprometido com empréstimos consignados. Para aposentados e pensionistas do INSS, esse limite é de <strong>45% do benefício</strong>, dividido da seguinte forma:</p>
      
      <ul>
        <li><strong>35%</strong> para empréstimos consignados tradicionais</li>
        <li><strong>5%</strong> para cartão de crédito consignado</li>
        <li><strong>5%</strong> para cartão de benefício (saque)</li>
      </ul>
      
      <h3>Por Que Isso É Importante?</h3>
      <p>Conhecer sua margem é essencial porque:</p>
      <ul>
        <li>Define quanto você pode contratar de empréstimo</li>
        <li>Evita que você comprometa demais sua renda</li>
        <li>Ajuda no planejamento financeiro</li>
      </ul>
      
      <h3>Como Consultar Sua Margem?</h3>
      <p>Você pode consultar sua margem através do:</p>
      <ul>
        <li>Aplicativo Meu INSS</li>
        <li>Site do Meu INSS</li>
        <li>Ligando para o 135</li>
        <li>Ou entre em contato conosco que fazemos a consulta para você!</li>
      </ul>
    `,
  },
  {
    id: "consignado-vs-pessoal",
    icon: ArrowLeftRight,
    titulo: "Diferença Entre Consignado e Pessoal",
    descricao: "Compare os dois tipos de empréstimo e descubra qual é melhor para você.",
    tempoLeitura: "4 min",
    conteudo: `
      <h3>Empréstimo Consignado</h3>
      <ul>
        <li><strong>Taxas:</strong> Menores (1,80% a 2,14% a.m. para INSS)</li>
        <li><strong>Desconto:</strong> Automático na folha/benefício</li>
        <li><strong>Aprovação:</strong> Mais fácil, sem análise de score</li>
        <li><strong>Prazo:</strong> Até 84 meses</li>
        <li><strong>Para quem:</strong> Aposentados, pensionistas, servidores</li>
      </ul>
      
      <h3>Empréstimo Pessoal</h3>
      <ul>
        <li><strong>Taxas:</strong> Maiores (3% a 15% a.m.)</li>
        <li><strong>Pagamento:</strong> Boleto ou débito em conta</li>
        <li><strong>Aprovação:</strong> Depende do score de crédito</li>
        <li><strong>Prazo:</strong> Geralmente até 48 meses</li>
        <li><strong>Para quem:</strong> Qualquer pessoa com renda</li>
      </ul>
      
      <h3>Conclusão</h3>
      <p>Se você é aposentado, pensionista ou servidor público, o <strong>consignado é sempre a melhor opção</strong> devido às taxas significativamente menores.</p>
    `,
  },
  {
    id: "aumentar-margem",
    icon: TrendingUp,
    titulo: "Como Aumentar a Margem",
    descricao: "Dicas práticas para liberar mais espaço no seu limite de crédito.",
    tempoLeitura: "6 min",
    conteudo: `
      <h3>Estratégias Para Aumentar Sua Margem</h3>
      
      <h4>1. Quite Empréstimos Antigos</h4>
      <p>Ao quitar um empréstimo consignado, a margem que estava comprometida é liberada automaticamente.</p>
      
      <h4>2. Faça Portabilidade</h4>
      <p>Ao transferir seu empréstimo para um banco com taxa menor, você pode reduzir a parcela e liberar margem.</p>
      
      <h4>3. Refinanciamento</h4>
      <p>Renegociar seu empréstimo atual pode resultar em parcelas menores, liberando parte da margem.</p>
      
      <h4>4. Aguarde Aumento do Benefício</h4>
      <p>Quando o INSS reajusta os benefícios, sua margem em reais também aumenta proporcionalmente.</p>
      
      <h4>5. Cancele Cartões Consignados Não Utilizados</h4>
      <p>Cartões consignados comprometem a margem mesmo sem uso. Cancele os que não utiliza.</p>
      
      <h3>Importante</h3>
      <p>Nossa equipe pode analisar sua situação gratuitamente e indicar a melhor estratégia para você!</p>
    `,
  },
  {
    id: "portabilidade",
    icon: BookOpen,
    titulo: "Como Funciona a Portabilidade",
    descricao: "Saiba como transferir seu empréstimo para taxas menores.",
    tempoLeitura: "5 min",
    conteudo: `
      <h3>O Que É Portabilidade de Crédito?</h3>
      <p>A portabilidade permite transferir sua dívida de um banco para outro que ofereça condições melhores, principalmente <strong>taxas de juros menores</strong>.</p>
      
      <h3>Vantagens da Portabilidade</h3>
      <ul>
        <li>Redução da taxa de juros</li>
        <li>Possibilidade de diminuir o valor da parcela</li>
        <li>Não compromete mais margem</li>
        <li>Processo gratuito e sem custos</li>
        <li>Direito garantido por lei</li>
      </ul>
      
      <h3>Como Fazer a Portabilidade?</h3>
      <ol>
        <li>Solicite o saldo devedor ao banco atual</li>
        <li>Compare as taxas de outros bancos</li>
        <li>Escolha a melhor proposta</li>
        <li>O novo banco quita a dívida antiga</li>
        <li>Você passa a pagar para o novo banco</li>
      </ol>
      
      <h3>Nós Cuidamos de Tudo!</h3>
      <p>Na UP Soluções, fazemos toda a análise e processo de portabilidade para você, sem nenhum custo adicional.</p>
    `,
  },
  {
    id: "evitar-golpes",
    icon: ShieldAlert,
    titulo: "Como Evitar Golpes",
    descricao: "Proteja-se contra fraudes em empréstimos consignados.",
    tempoLeitura: "7 min",
    conteudo: `
      <h3>Principais Golpes no Mercado</h3>
      
      <h4>1. Depósito Antecipado</h4>
      <p><strong>NUNCA</strong> pague qualquer valor antes de receber o empréstimo. Taxas, seguros ou "liberações" antecipadas são golpes.</p>
      
      <h4>2. Falsos Funcionários</h4>
      <p>Golpistas se passam por funcionários do INSS ou bancos. Sempre confirme ligando para os canais oficiais.</p>
      
      <h4>3. Links Falsos</h4>
      <p>Não clique em links recebidos por WhatsApp, SMS ou e-mail. Acesse sempre os sites oficiais.</p>
      
      <h3>Como Se Proteger</h3>
      <ul>
        <li>Nunca forneça senhas ou dados bancários</li>
        <li>Desconfie de taxas muito abaixo do mercado</li>
        <li>Verifique se a empresa está registrada no Banco Central</li>
        <li>Não assine documentos sem ler</li>
        <li>Sempre peça o contrato por escrito</li>
      </ul>
      
      <h3>A UP Soluções É Segura</h3>
      <p>Somos correspondentes bancários autorizados, com registro no Banco Central. Trabalhamos com total transparência e nunca pedimos depósitos antecipados.</p>
    `,
  },
]

const blogs = [
  {
    id: 1,
    titulo: "5 Erros Comuns ao Contratar Empréstimo Consignado",
    resumo: "Evite armadilhas financeiras conhecendo os erros mais frequentes na hora de contratar um consignado.",
    imagem: "/financial-mistakes-warning-money-error.jpg",
    categoria: "Dicas",
    dataPublicacao: "10 Dez 2024",
  },
  {
    id: 2,
    titulo: "Portabilidade de Crédito: Guia Completo 2025",
    resumo: "Tudo o que você precisa saber para transferir seu empréstimo e economizar nas parcelas.",
    imagem: "/money-transfer-bank-switching-savings.jpg",
    categoria: "Portabilidade",
    dataPublicacao: "05 Dez 2024",
  },
  {
    id: 3,
    titulo: "Como Calcular Sua Margem Consignável",
    resumo: "Aprenda passo a passo como descobrir quanto você pode comprometer do seu benefício.",
    imagem: "/calculator-financial-planning-budget-percentage.jpg",
    categoria: "Educação Financeira",
    dataPublicacao: "01 Dez 2024",
  },
  {
    id: 4,
    titulo: "Golpes no Consignado: Como se Proteger",
    resumo: "Conheça as fraudes mais comuns e saiba como identificar e evitar golpistas.",
    imagem: "/security-protection-shield-fraud-warning.jpg",
    categoria: "Segurança",
    dataPublicacao: "28 Nov 2024",
  },
  {
    id: 5,
    titulo: "Refinanciamento vs Portabilidade: Qual Escolher?",
    resumo: "Entenda as diferenças entre as duas opções e descubra qual é a melhor para o seu caso.",
    imagem: "/comparison-choice-decision-financial-options.jpg",
    categoria: "Comparativo",
    dataPublicacao: "20 Nov 2024",
  },
  {
    id: 6,
    titulo: "Novidades do Consignado INSS 2025",
    resumo: "Fique por dentro das mudanças nas regras e taxas do empréstimo consignado para aposentados.",
    imagem: "/news-update-changes-retirement-inss-brazil.jpg",
    categoria: "Notícias",
    dataPublicacao: "15 Nov 2024",
  },
]

export function GuiasEducacionais() {
  const [guiaAberto, setGuiaAberto] = useState<string | null>(null)

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 bg-secondary/10 text-secondary rounded-full text-sm font-semibold mb-4">
            Central de Conhecimento
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Guias Educacionais Sobre <span className="text-primary">Crédito Consignado</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Aprenda tudo sobre empréstimo consignado e tome decisões mais inteligentes. Quanto mais você sabe, melhor
            negocia.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {guias.map((guia) => {
            const Icon = guia.icon
            const isAberto = guiaAberto === guia.id

            return (
              <Card
                key={guia.id}
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${isAberto ? "ring-2 ring-primary" : "hover:border-primary"}`}
                onClick={() => setGuiaAberto(isAberto ? null : guia.id)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <Icon className="text-primary" size={24} />
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock size={12} />
                      {guia.tempoLeitura}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-4">{guia.titulo}</CardTitle>
                  <CardDescription className="leading-relaxed">{guia.descricao}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="ghost" className="w-full justify-between group">
                    {isAberto ? "Fechar" : "Ler mais"}
                    <ChevronRight
                      className={`transition-transform ${isAberto ? "rotate-90" : "group-hover:translate-x-1"}`}
                      size={16}
                    />
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Conteúdo expandido */}
        {guiaAberto && (
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="border-2 border-primary">
              <CardHeader className="border-b border-border">
                <div className="flex items-center gap-4">
                  {(() => {
                    const guia = guias.find((g) => g.id === guiaAberto)
                    if (!guia) return null
                    const Icon = guia.icon
                    return (
                      <>
                        <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                          <Icon className="text-primary" size={28} />
                        </div>
                        <div>
                          <CardTitle className="text-2xl">{guia.titulo}</CardTitle>
                          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock size={14} />
                              {guia.tempoLeitura} de leitura
                            </span>
                            <span className="flex items-center gap-1">
                              <User size={14} />
                              Equipe UP Soluções
                            </span>
                          </div>
                        </div>
                      </>
                    )
                  })()}
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div
                  className="prose prose-lg dark:prose-invert max-w-none
                    prose-headings:text-foreground prose-headings:font-bold
                    prose-h3:text-xl prose-h3:mt-6 prose-h3:mb-3
                    prose-h4:text-lg prose-h4:mt-4 prose-h4:mb-2
                    prose-p:text-muted-foreground prose-p:leading-relaxed
                    prose-ul:text-muted-foreground prose-li:my-1
                    prose-ol:text-muted-foreground
                    prose-strong:text-foreground"
                  dangerouslySetInnerHTML={{
                    __html: guias.find((g) => g.id === guiaAberto)?.conteudo || "",
                  }}
                />
                <div className="mt-8 pt-6 border-t border-border">
                  <Button variant="outline" onClick={() => setGuiaAberto(null)} className="mr-4">
                    Voltar aos guias
                  </Button>
                  <Button asChild>
                    <a href="/contato">Falar com um especialista</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="mt-20">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-semibold mb-4">
              Blog
            </span>
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Artigos e <span className="text-primary">Notícias</span>
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Fique por dentro das últimas novidades, dicas e informações sobre crédito consignado
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogs.map((blog) => (
              <Card key={blog.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <div className="relative overflow-hidden">
                  <Image
                    src={blog.imagem || "/placeholder.svg"}
                    alt={blog.titulo}
                    width={350}
                    height={200}
                    className="w-full h-[200px] object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-3 py-1 bg-primary text-white text-xs font-semibold rounded-full">
                      {blog.categoria}
                    </span>
                  </div>
                </div>
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                    <Calendar size={12} />
                    {blog.dataPublicacao}
                  </div>
                  <h4 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                    {blog.titulo}
                  </h4>
                  <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{blog.resumo}</p>
                  <Button variant="link" className="p-0 h-auto font-semibold text-primary">
                    Ler artigo completo
                    <ChevronRight size={16} className="ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
