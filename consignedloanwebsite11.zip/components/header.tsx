"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, Moon, Sun, ChevronDown } from "lucide-react"
import { useTheme } from "@/components/theme-provider"
import Link from "next/link"
import Image from "next/image"

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isFaqOpen, setIsFaqOpen] = useState(false)
  const [isServicosOpen, setIsServicosOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur-md shadow-md" : "bg-slate-950/80 backdrop-blur-sm"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link href="/" className="flex items-center gap-2 group mr-auto">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden shadow-lg">
              <Image src="/up-solucoes-logo.png" alt="UP Soluções Logo" fill className="object-cover" priority />
            </div>
          </Link>

          {/* Menu Desktop */}
          <nav className="hidden md:flex items-center gap-8">
            <div className="relative group">
              <button
                className={`text-sm font-medium transition-colors flex items-center gap-1 ${
                  isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
                }`}
                onMouseEnter={() => setIsServicosOpen(true)}
                onMouseLeave={() => setIsServicosOpen(false)}
              >
                Serviços
                <ChevronDown className="w-4 h-4" />
              </button>
              <div
                className={`absolute top-full left-0 mt-2 w-56 bg-card border border-border rounded-lg shadow-lg overflow-hidden transition-all duration-200 ${
                  isServicosOpen ? "opacity-100 visible translate-y-0" : "opacity-0 invisible -translate-y-2"
                }`}
                onMouseEnter={() => setIsServicosOpen(true)}
                onMouseLeave={() => setIsServicosOpen(false)}
              >
                <Link
                  href="/servicos"
                  className="block px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors"
                >
                  Todos os Serviços
                </Link>
                <Link
                  href="/margem-extra"
                  className="block px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors border-t border-border"
                >
                  Margem Extra
                </Link>
              </div>
            </div>

            <Link
              href="/vantagens"
              className={`text-sm font-medium transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
            >
              Vantagens
            </Link>

            <Link
              href="/sobre"
              className={`text-sm font-medium transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
            >
              Sobre Nós
            </Link>

            <div className="relative group">
              <button
                className={`text-sm font-medium transition-colors flex items-center gap-1 ${
                  isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
                }`}
                onMouseEnter={() => setIsFaqOpen(true)}
                onMouseLeave={() => setIsFaqOpen(false)}
              >
                FAQ
                <ChevronDown className="w-4 h-4" />
              </button>
              <div
                className={`absolute top-full left-0 mt-2 w-56 bg-card border border-border rounded-lg shadow-lg overflow-hidden transition-all duration-200 ${
                  isFaqOpen ? "opacity-100 visible translate-y-0" : "opacity-0 invisible -translate-y-2"
                }`}
                onMouseEnter={() => setIsFaqOpen(true)}
                onMouseLeave={() => setIsFaqOpen(false)}
              >
                <Link href="/faq" className="block px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors">
                  Perguntas Frequentes
                </Link>
                <Link
                  href="/comparativo-produtos"
                  className="block px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors border-t border-border"
                >
                  Comparativo de Produtos
                </Link>
                <Link
                  href="/guias"
                  className="block px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors border-t border-border"
                >
                  Guias Educacionais
                </Link>
              </div>
            </div>

            <Link
              href="/contato"
              className={`text-sm font-medium transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
            >
              Contato
            </Link>
            <Link
              href="/depoimentos"
              className={`text-sm font-medium transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
            >
              Depoimentos
            </Link>
          </nav>

          {/* Botão de tema e CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className={`transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
              aria-label={theme === "light" ? "Ativar modo escuro" : "Ativar modo claro"}
            >
              {theme === "light" ? <Moon size={20} /> : <Sun size={20} />}
            </Button>
            <Link href="/contato">
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
                Simular Empréstimo
              </Button>
            </Link>
          </div>

          {/* Menu Mobile */}
          <div className="md:hidden flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className={`transition-colors ${
                isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-secondary"
              }`}
              aria-label={theme === "light" ? "Ativar modo escuro" : "Ativar modo claro"}
            >
              {theme === "light" ? <Moon size={24} /> : <Sun size={24} />}
            </Button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`p-2 ${isScrolled ? "text-foreground" : "text-white"}`}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Menu Mobile Expandido */}
        {isMobileMenuOpen && (
          <div className="md:hidden pb-6 pt-2 animate-in slide-in-from-top bg-background rounded-lg">
            <nav className="flex flex-col gap-4">
              <Link
                href="/servicos"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Serviços
              </Link>
              <Link
                href="/margem-extra"
                className="text-left px-4 py-2 pl-8 text-muted-foreground hover:bg-accent rounded-lg transition-colors text-sm"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                → Margem Extra
              </Link>
              <Link
                href="/vantagens"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Vantagens
              </Link>
              <Link
                href="/sobre"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Sobre Nós
              </Link>
              <Link
                href="/faq"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                FAQ
              </Link>
              <Link
                href="/comparativo-produtos"
                className="text-left px-4 py-2 pl-8 text-muted-foreground hover:bg-accent rounded-lg transition-colors text-sm"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                → Comparativo de Produtos
              </Link>
              <Link
                href="/guias"
                className="text-left px-4 py-2 pl-8 text-muted-foreground hover:bg-accent rounded-lg transition-colors text-sm"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                → Guias Educacionais
              </Link>
              <Link
                href="/contato"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contato
              </Link>
              <Link
                href="/depoimentos"
                className="text-left px-4 py-2 text-foreground hover:bg-accent rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Depoimentos
              </Link>
              <Link href="/contato" onClick={() => setIsMobileMenuOpen(false)}>
                <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 w-full">
                  Simular Empréstimo
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
