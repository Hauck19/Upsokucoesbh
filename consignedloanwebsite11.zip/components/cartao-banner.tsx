"use client"

import {
  CheckCircle,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Shield,
  Percent,
  Clock,
  Zap,
  DollarSign,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const TELEFONE_WHATSAPP = "5531982190475"
const MENSAGEM_WHATSAPP = "Olá, quero fazer uma simulação gratuita de empréstimo consignado!"

export function CartaoBanner() {
  const handleWhatsAppClick = () => {
    const mensagemCodificada = encodeURIComponent(MENSAGEM_WHATSAPP)
    const url = `https://wa.me/${TELEFONE_WHATSAPP}?text=${mensagemCodificada}`
    window.open(url, "_blank")
  }

  return (
    <section className="relative py-24 overflow-hidden">
      {/* Gradiente de fundo vibrante */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-blue-600 to-cyan-500" />

      {/* Padrão de fundo */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Elementos decorativos flutuantes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full animate-pulse" />
        <div
          className="absolute top-32 right-20 w-16 h-16 bg-secondary/30 rounded-full animate-bounce"
          style={{ animationDuration: "3s" }}
        />
        <div
          className="absolute bottom-20 left-1/4 w-12 h-12 bg-yellow-400/20 rounded-full animate-pulse"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute bottom-32 right-1/3 w-24 h-24 bg-white/5 rounded-full animate-pulse"
          style={{ animationDelay: "2s" }}
        />

        {/* Ícones flutuantes */}
        <div className="absolute top-20 right-1/4 text-white/20 animate-bounce" style={{ animationDuration: "4s" }}>
          <DollarSign size={40} />
        </div>
        <div className="absolute bottom-40 left-20 text-white/20 animate-pulse" style={{ animationDuration: "3s" }}>
          <Percent size={35} />
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left text-white">
            {/* Badge chamativo */}
            <div className="inline-flex items-center gap-2 bg-yellow-400 text-yellow-900 px-5 py-2.5 rounded-full mb-6 font-bold shadow-lg animate-pulse">
              <Sparkles size={20} />
              <span className="text-sm uppercase tracking-wide">Simulação 100% Gratuita</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance leading-tight">
              Empréstimo Consignado
              <span className="block text-yellow-300 mt-2">Dinheiro na Hora!</span>
            </h1>

            {/* Destaque das taxas */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-white/20">
              <div className="flex items-center justify-center lg:justify-start gap-4 mb-4">
                <div className="bg-yellow-400 text-yellow-900 px-4 py-2 rounded-lg font-bold">
                  <span className="text-3xl">1,80%</span>
                  <span className="text-sm ml-1">a.m.</span>
                </div>
                <div className="text-white/90">
                  <p className="font-semibold">Taxas a partir de</p>
                  <p className="text-sm text-white/70">Sem consulta ao SPC/Serasa</p>
                </div>
              </div>
              <p className="text-white/90 text-lg leading-relaxed">
                Libere seu crédito em até <strong>24 horas</strong> com as melhores condições do mercado. Atendimento
                100% online e seguro.
              </p>
            </div>

            {/* Lista de benefícios */}
            <div className="grid grid-cols-2 gap-3 mb-8">
              {[
                { icon: Clock, text: "Aprovação rápida" },
                { icon: Shield, text: "100% Seguro" },
                { icon: TrendingUp, text: "Melhores taxas" },
                { icon: Users, text: "+5.000 clientes" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-3 rounded-xl border border-white/20"
                >
                  <item.icon size={20} className="text-yellow-300 flex-shrink-0" />
                  <span className="text-white font-medium text-sm">{item.text}</span>
                </div>
              ))}
            </div>

            {/* Botão principal */}
            <Button
              onClick={handleWhatsAppClick}
              size="lg"
              className="bg-yellow-400 hover:bg-yellow-300 text-yellow-900 shadow-2xl text-lg px-12 py-8 h-auto font-bold group transition-all hover:scale-105 hover:shadow-yellow-400/50 w-full sm:w-auto"
            >
              <Zap className="mr-3 group-hover:rotate-12 transition-transform" size={28} />
              SIMULAR AGORA GRÁTIS
              <ArrowRight className="ml-3 group-hover:translate-x-1 transition-transform" size={24} />
            </Button>

            <p className="mt-4 text-white/70 text-sm">Sem compromisso • Resposta imediata • 100% Online</p>
          </div>

          {/* Imagem ilustrativa */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Efeito de brilho atrás da imagem */}
              <div className="absolute -inset-4 bg-gradient-to-br from-yellow-400/30 via-white/20 to-secondary/30 rounded-3xl blur-2xl" />

              {/* Card com estatísticas */}
              <div
                className="absolute -top-6 -left-6 bg-white rounded-xl p-4 shadow-2xl z-20 animate-bounce"
                style={{ animationDuration: "3s" }}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <CheckCircle className="text-green-600" size={24} />
                  </div>
                  <div>
                    <p className="text-green-600 font-bold text-lg">Aprovado!</p>
                    <p className="text-gray-500 text-sm">Crédito liberado</p>
                  </div>
                </div>
              </div>

              {/* Para trocar: substitua o src pela sua imagem em public/ */}
              <Image
                src="/happy-senior-couple-celebrating-financial-success-.jpg"
                alt="Casal feliz com crédito aprovado"
                width={500}
                height={500}
                className="relative z-10 rounded-3xl shadow-2xl object-cover"
              />

              {/* Badge de valor */}
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-secondary to-green-500 text-white rounded-xl p-4 shadow-2xl z-20">
                <p className="text-sm font-medium">Libere até</p>
                <p className="text-2xl font-bold">R$ 150.000</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
