import { CheckCircle, Clock, Shield, Percent, FileText, ThumbsUp } from "lucide-react"

const benefits = [
  {
    icon: Percent,
    title: "Taxas Competitivas",
    description: "As menores taxas de juros do mercado para você economizar mais.",
  },
  {
    icon: Clock,
    title: "Aprovação Rápida",
    description: "Análise e aprovação em até 24 horas úteis.",
  },
  {
    icon: Shield,
    title: "Segurança Total",
    description: "Processos seguros e transparentes, com total proteção de dados.",
  },
  {
    icon: FileText,
    title: "Sem Burocracia",
    description: "Documentação simplificada e processo 100% digital.",
  },
  {
    icon: ThumbsUp,
    title: "Atendimento Personalizado",
    description: "Equipe especializada pronta para ajudar você.",
  },
  {
    icon: CheckCircle,
    title: "Parcelas Fixas",
    description: "Parcelas que cabem no seu bolso, sem surpresas.",
  },
]

export function Benefits() {
  return (
    <section id="benefits" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Por Que Escolher a <span className="text-primary">UP Soluções</span>?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Somos referência em empréstimo consignado em Belo Horizonte, oferecendo as melhores condições e atendimento
            humanizado.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon
            return (
              <div
                key={index}
                className="flex flex-col items-center text-center p-6 rounded-2xl hover:bg-accent transition-colors duration-300"
              >
                <div className="w-16 h-16 bg-secondary/10 rounded-2xl flex items-center justify-center mb-4">
                  <Icon className="text-secondary" size={32} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
