"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Shield,
  Users,
  Award,
  Headphones,
  Building2,
  Instagram,
  Facebook,
} from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"
import { WhatsAppIcon } from "./whatsapp-icon"
import Image from "next/image"

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const mensagem = `Olá! Meu nome é ${formData.name}.

Telefone: ${formData.phone}
E-mail: ${formData.email}

Mensagem: ${formData.message}

Gostaria de mais informações sobre os serviços de vocês.`

    window.open(getWhatsAppLink(mensagem), "_blank")
  }

  const mapsUrl =
    "https://www.google.com/maps/search/?api=1&query=R.+Erico+Verissimo+2340+Santa+Monica+Belo+Horizonte+MG"

  const motivosContato = [
    {
      icon: Shield,
      title: "Segurança Total",
      description: "Seus dados estão protegidos e trabalhamos com total transparência",
    },
    {
      icon: Users,
      title: "Atendimento Humanizado",
      description: "Consultores especializados prontos para tirar todas as suas dúvidas",
    },
    {
      icon: Award,
      title: "Empresa Certificada",
      description: "Correspondente bancário autorizado pelos principais bancos do país",
    },
    {
      icon: Headphones,
      title: "Suporte Completo",
      description: "Acompanhamos seu processo do início ao fim, sem deixar você na mão",
    },
  ]

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="relative rounded-3xl overflow-hidden mb-16">
          <div className="absolute inset-0">
            <Image
              src="/professional-call-center-team-with-headsets-smilin.jpg"
              alt="Equipe de atendimento"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70" />
          </div>
          <div className="relative z-10 py-16 px-8 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Entre em Contato Conosco</h2>
            <p className="text-lg text-white/90 leading-relaxed max-w-2xl mx-auto">
              Nossa equipe está pronta para atender você e encontrar a melhor solução de crédito para suas necessidades.
            </p>
          </div>
        </div>

        {/* Cards de motivos */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-16">
          {motivosContato.map((motivo, index) => (
            <Card key={index} className="text-center border-2 hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <motivo.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{motivo.title}</h3>
                <p className="text-sm text-muted-foreground">{motivo.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Solicite uma Proposta</CardTitle>
                <CardDescription>Preencha o formulário e entraremos em contato em breve</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Nome Completo
                      </label>
                      <Input
                        id="name"
                        placeholder="Seu nome"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Telefone
                      </label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="(31) 99999-9999"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      E-mail
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Mensagem
                    </label>
                    <Textarea
                      id="message"
                      placeholder="Conte-nos sobre sua necessidade de crédito..."
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                    />
                  </div>
                  <Button type="submit" size="lg" className="w-full bg-[#25D366] text-white hover:bg-[#128C7E] gap-2">
                    <WhatsAppIcon className="h-5 w-5" />
                    Enviar pelo WhatsApp
                  </Button>
                </form>

                <div className="mt-8 relative rounded-xl overflow-hidden">
                  <Image
                    src="/friendly-financial-consultant-helping-happy-senior.jpg"
                    alt="Consultor ajudando casal de idosos"
                    width={600}
                    height={300}
                    className="w-full h-auto object-cover rounded-xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                    <div className="text-white">
                      <p className="font-semibold text-lg">Atendimento Personalizado</p>
                      <p className="text-sm text-white/80">Nossa equipe está pronta para ajudar você</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            <Card className="bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle className="text-primary-foreground">Informações de Contato</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="flex-shrink-0 mt-1" size={20} />
                  <div>
                    <p className="font-medium mb-1">Endereço</p>
                    <p className="text-sm text-primary-foreground/90 leading-relaxed">
                      R. Erico Verissimo, 2340a
                      <br />
                      Santa Monica
                      <br />
                      Belo Horizonte - MG
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="flex-shrink-0 mt-1" size={20} />
                  <div>
                    <p className="font-medium mb-1">Telefone</p>
                    <p className="text-sm text-primary-foreground/90">(31) 98219-0475</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="flex-shrink-0 mt-1" size={20} />
                  <div>
                    <p className="font-medium mb-1">E-mail</p>
                    <p className="text-sm text-primary-foreground/90">contato@upsolucoes.com.br</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="flex-shrink-0 mt-1" size={20} />
                  <div>
                    <p className="font-medium mb-1">Horário de Atendimento</p>
                    <p className="text-sm text-primary-foreground/90">Segunda a Sexta: 9h às 17h</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-primary/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Siga-nos nas Redes Sociais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <a
                  href="https://www.instagram.com/upsolucoes5"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white hover:opacity-90 transition-opacity"
                >
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Instagram className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-semibold">Instagram</p>
                    <p className="text-sm text-white/90">@upsolucoes5</p>
                  </div>
                </a>

                <a
                  href="https://www.facebook.com/share/1Em6RKoLwB/?mibextid=wwXIfr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-lg bg-[#1877F2] text-white hover:opacity-90 transition-opacity"
                >
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Facebook className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-semibold">Facebook</p>
                    <p className="text-sm text-white/90">UP Soluções</p>
                  </div>
                </a>
              </CardContent>
            </Card>

            <Card className="bg-[#25D366] text-white">
              <CardHeader>
                <CardTitle className="text-primary-foreground">Atendimento Rápido</CardTitle>
              </CardHeader>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mx-auto mb-4">
                  <WhatsAppIcon className="h-10 w-10 text-[#25D366]" />
                </div>
                <p className="font-semibold text-lg mb-1">Atendimento Rápido</p>
                <p className="text-sm text-white/90 mb-4">Fale agora com um consultor pelo WhatsApp</p>
                <Button
                  asChild
                  variant="outline"
                  className="w-full bg-white text-[#25D366] hover:bg-white/90 border-0 font-semibold"
                >
                  <a href={getWhatsAppLink(mensagensWhatsApp.geral)} target="_blank" rel="noopener noreferrer">
                    Chamar no WhatsApp
                  </a>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-primary/30 bg-primary/5">
              <CardContent className="p-6 text-center">
                <Building2 className="h-10 w-10 mx-auto mb-3 text-primary" />
                <p className="font-semibold mb-2 text-foreground">UP Soluções</p>
                <p className="text-sm text-muted-foreground mb-3">
                  Correspondente bancário autorizado, especializado em crédito consignado há mais de 5 anos.
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">Consignado</span>
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">Portabilidade</span>
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">Refinanciamento</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="max-w-6xl mx-auto mb-12">
          <Card className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground overflow-hidden">
            <CardContent className="p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold mb-2">Pronto para começar?</h3>
                <p className="text-primary-foreground/90">
                  Faça uma simulação gratuita e descubra quanto você pode liberar hoje mesmo!
                </p>
              </div>
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90 gap-2 whitespace-nowrap">
                <a href={getWhatsAppLink(mensagensWhatsApp.simulacao)} target="_blank" rel="noopener noreferrer">
                  <WhatsAppIcon className="h-5 w-5" />
                  Simular Agora
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Mapa */}
        <Card className="max-w-6xl mx-auto">
          <CardHeader>
            <CardTitle>Localização</CardTitle>
            <CardDescription>R. Erico Verissimo, 2340a - Santa Monica, Belo Horizonte - MG</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full h-[400px] rounded-b-lg overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
              aria-label="Abrir localização no Google Maps"
            >
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3751.5968649892727!2d-43.9857344!3d-19.8583333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xa699de2aa0f3e9%3A0x7f6f4cf6e3d7c8e5!2sR.%20%C3%89rico%20Ver%C3%ADssimo%2C%202340%20-%20Santa%20M%C3%B4nica%2C%20Belo%20Horizonte%20-%20MG!5e0!3m2!1spt-BR!2sbr!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0, pointerEvents: "none" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Mapa da UP Soluções"
              ></iframe>
            </a>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
