"use client"

import { useState } from "react"
import {
  ChevronDown,
  Clock,
  CheckCircle2,
  Smartphone,
  DollarSign,
  Shield,
  FileText,
  Users,
  TrendingUp,
  CreditCard,
  RefreshCw,
  ArrowRightLeft,
  Banknote,
  Wallet,
} from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

// Perguntas e respostas do FAQ
const faqData = [
  {
    question: "Quanto tempo demora para cair na conta?",
    answer:
      "O prazo para o dinheiro cair na sua conta é de 24 a 48 horas úteis após a aprovação completa do crédito. Em alguns casos específicos, o valor pode estar disponível em até 2 horas! Isso depende do banco conveniado e da instituição pagadora. Trabalhamos para tornar o processo o mais ágil possível, garantindo que você tenha acesso rápido ao seu crédito.",
    icon: Clock,
  },
  {
    question: "Precisa ter nome limpo?",
    answer:
      "Não! Uma das maiores vantagens do empréstimo consignado é que você NÃO precisa ter o nome limpo. Mesmo com restrições no CPF ou negativação (SPC/Serasa), você pode contratar. Isso porque o desconto é feito diretamente na folha de pagamento ou benefício, o que reduz o risco para as instituições financeiras e facilita a aprovação do seu crédito.",
    icon: CheckCircle2,
  },
  {
    question: "Posso contratar pelo celular?",
    answer:
      "Sim! Você pode contratar seu empréstimo consignado 100% online pelo celular, de forma rápida e segura. Basta entrar em contato conosco pelo WhatsApp, enviar os documentos solicitados (RG, CPF, comprovante de residência e holerite), e nossa equipe faz toda a simulação e processo de contratação. Tudo pelo conforto do seu smartphone, sem precisar sair de casa!",
    icon: Smartphone,
  },
  {
    question: "Qual é a taxa atual?",
    answer:
      "As taxas de juros do empréstimo consignado estão entre as mais baixas do mercado, variando de 1,50% a 2,50% ao mês, dependendo da sua margem consignável, prazo escolhido e convênio. Para aposentados e pensionistas do INSS, as taxas podem ser ainda menores. Entre em contato conosco para uma simulação personalizada e descubra a melhor taxa para o seu perfil!",
    icon: DollarSign,
  },
  {
    question: "Quais documentos são necessários?",
    answer:
      "Para contratar seu empréstimo consignado, você precisará de: RG e CPF (originais ou cópias legíveis), comprovante de residência atualizado (até 3 meses), último holerite ou extrato de benefício do INSS, e dados bancários para depósito. Em alguns casos, podemos solicitar documentos adicionais. Nossa equipe orienta você em cada etapa do processo!",
    icon: FileText,
  },
  {
    question: "Qual o valor mínimo e máximo que posso contratar?",
    answer:
      "O valor disponível para você depende da sua margem consignável (até 35% do salário ou benefício). Trabalhamos com valores a partir de R$ 500,00. O valor máximo varia conforme sua renda mensal e o prazo escolhido, podendo chegar a valores bastante atrativos. Faça uma simulação conosco e descubra quanto você pode contratar!",
    icon: TrendingUp,
  },
  {
    question: "É seguro fazer empréstimo consignado online?",
    answer:
      "Sim! O empréstimo consignado online é 100% seguro quando feito com empresas sérias e registradas. A UP Soluções trabalha apenas com instituições financeiras autorizadas pelo Banco Central. Todos os seus dados são protegidos por criptografia e seguimos rigorosamente a LGPD (Lei Geral de Proteção de Dados). Você tem total segurança e transparência em todo o processo.",
    icon: Shield,
  },
  {
    question: "Aposentados e pensionistas podem contratar?",
    answer:
      "Sim! Aposentados e pensionistas do INSS têm acesso ao empréstimo consignado com condições especiais e taxas ainda mais baixas. O desconto é feito diretamente no benefício previdenciário. É uma das modalidades mais vantajosas do mercado, com menos burocracia e aprovação rápida. Entre em contato e faça sua simulação!",
    icon: Users,
  },
]

const produtosComparacao = [
  {
    nome: "Consignado",
    icon: Banknote,
    descricao: "Empréstimo tradicional com desconto em folha",
    taxaJuros: "1,50% a 2,14% a.m.",
    prazo: "Até 84 meses",
    vantagens: ["Menores taxas do mercado", "Desconto automático", "Sem consulta SPC/Serasa"],
    ideal: "Quem precisa de dinheiro na conta",
  },
  {
    nome: "Cartão Consignado",
    icon: CreditCard,
    descricao: "Cartão de crédito com desconto em folha",
    taxaJuros: "2,50% a 3,00% a.m.",
    prazo: "Pagamento mínimo mensal",
    vantagens: ["Limite disponível sempre", "Aceito em todo Brasil", "Saque no débito"],
    ideal: "Quem quer ter um limite disponível",
  },
  {
    nome: "Portabilidade",
    icon: ArrowRightLeft,
    descricao: "Transferência de dívida para outro banco",
    taxaJuros: "Negociável",
    prazo: "Mantém ou aumenta prazo",
    vantagens: ["Reduz taxa de juros", "Pode liberar troco", "Mantém mesmo desconto"],
    ideal: "Quem já tem consignado e quer melhorar",
  },
  {
    nome: "Refinanciamento",
    icon: RefreshCw,
    descricao: "Renegociação do contrato atual",
    taxaJuros: "1,70% a 2,30% a.m.",
    prazo: "Estende prazo",
    vantagens: ["Diminui parcela", "Libera novo dinheiro", "Aproveita margem paga"],
    ideal: "Quem precisa de mais dinheiro",
  },
  {
    nome: "Saque Suplementar",
    icon: Wallet,
    descricao: "Saque extra do cartão consignado",
    taxaJuros: "2,00% a 2,70% a.m.",
    prazo: "Até 84 meses",
    vantagens: ["Usa margem do cartão", "Dinheiro na conta", "Sem burocracia extra"],
    ideal: "Quem já tem cartão consignado",
  },
]

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4">
        {/* Cabeçalho da seção */}
        <div className="text-center mb-12 md:mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Perguntas Frequentes
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Tire suas dúvidas sobre empréstimo consignado. Reunimos as perguntas mais comuns para te ajudar a entender
            melhor nossos serviços.
          </p>
        </div>

        {/* Grid com imagem e FAQ */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-start max-w-7xl mx-auto">
          {/* Coluna da esquerda - Imagem decorativa */}
          <div className="hidden lg:block sticky top-24">
            <div className="relative w-full aspect-square rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-primary/20 to-secondary/20">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8">
                  <Shield className="w-24 h-24 text-primary mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-foreground mb-2">Tire suas dúvidas</h3>
                  <p className="text-muted-foreground">Estamos aqui para ajudar</p>
                </div>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent" />
            </div>

            {/* Cards de destaque */}
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="bg-card border border-border rounded-xl p-4 shadow-lg">
                <Clock className="w-8 h-8 text-primary mb-2" />
                <p className="font-semibold text-sm">Aprovação Rápida</p>
                <p className="text-xs text-muted-foreground">24-48h</p>
              </div>
              <div className="bg-card border border-border rounded-xl p-4 shadow-lg">
                <DollarSign className="w-8 h-8 text-secondary mb-2" />
                <p className="font-semibold text-sm">Taxas Baixas</p>
                <p className="text-xs text-muted-foreground">A partir 1,50%</p>
              </div>
            </div>
          </div>

          {/* Coluna da direita - FAQ Accordion */}
          <div className="space-y-4">
            {faqData.map((faq, index) => {
              const Icon = faq.icon
              const isOpen = openIndex === index

              return (
                <div
                  key={index}
                  className={`bg-card border border-border rounded-xl overflow-hidden shadow-md transition-all duration-300 ${
                    isOpen ? "ring-2 ring-primary" : "hover:border-primary/50"
                  }`}
                >
                  {/* Pergunta */}
                  <button
                    onClick={() => toggleQuestion(index)}
                    className="w-full text-left px-6 py-5 flex items-start gap-4 group"
                  >
                    <div
                      className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                        isOpen
                          ? "bg-primary text-primary-foreground"
                          : "bg-primary/10 text-primary group-hover:bg-primary/20"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                        {faq.question}
                      </h3>
                    </div>

                    <ChevronDown
                      className={`flex-shrink-0 w-6 h-6 text-muted-foreground transition-transform duration-300 ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {/* Resposta */}
                  <div className={`overflow-hidden transition-all duration-300 ${isOpen ? "max-h-96" : "max-h-0"}`}>
                    <div className="px-6 pb-6 pl-20">
                      <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Compare Nossos Produtos</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Entenda as diferenças entre cada modalidade de crédito consignado e escolha a melhor opção para você.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {produtosComparacao.map((produto, index) => {
              const Icon = produto.icon
              return (
                <div
                  key={index}
                  className="bg-card border border-border rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:border-primary/50"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold">{produto.nome}</h3>
                  </div>

                  <p className="text-muted-foreground text-sm mb-4">{produto.descricao}</p>

                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Taxa de Juros:</span>
                      <span className="font-semibold text-primary">{produto.taxaJuros}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Prazo:</span>
                      <span className="font-semibold">{produto.prazo}</span>
                    </div>
                  </div>

                  <div className="border-t border-border pt-4 mb-4">
                    <p className="text-xs font-semibold text-muted-foreground mb-2">VANTAGENS:</p>
                    <ul className="space-y-1">
                      {produto.vantagens.map((vantagem, idx) => (
                        <li key={idx} className="text-sm flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                          {vantagem}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-secondary/10 rounded-lg p-3">
                    <p className="text-xs font-semibold text-secondary">IDEAL PARA:</p>
                    <p className="text-sm">{produto.ideal}</p>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Link para página de comparação detalhada */}
          <div className="text-center mt-8">
            <Link href="/comparativo-produtos">
              <Button size="lg" variant="outline" className="gap-2 bg-transparent">
                <ArrowRightLeft className="w-5 h-5" />
                Ver Comparativo Completo
              </Button>
            </Link>
          </div>
        </div>

        {/* Call to action no final */}
        <div className="mt-12 md:mt-16 text-center">
          <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 md:p-12 max-w-4xl mx-auto shadow-xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Ainda tem dúvidas?</h2>
            <p className="text-white/90 text-lg mb-6">
              Nossa equipe está pronta para atender você pelo WhatsApp e esclarecer todas as suas dúvidas!
            </p>
            <a
              href="https://wa.me/5531982190475?text=Olá,%20tenho%20dúvidas%20sobre%20empréstimo%20consignado!"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/90 transition-all hover:scale-105 shadow-lg"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Falar com Especialista
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
