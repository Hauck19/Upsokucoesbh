import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CreditCard, Wallet, TrendingUp, Shield, ArrowRight } from "lucide-react"
import { getWhatsAppLink, mensagensWhatsApp } from "@/lib/whatsapp"

// LISTA DE SERVIÇOS - ADICIONE, REMOVA OU EDITE AQUI
const services = [
  {
    icon: CreditCard,
    title: "Empréstimo Consignado INSS",
    description: "Crédito com desconto direto no benefício do INSS, com as menores taxas e prazos de até 84 meses.",
    features: ["Taxas a partir de 1,80% a.m.", "Até 84 meses para pagar", "Aprovação rápida"],
    mensagem: mensagensWhatsApp.consignado,
  },
  {
    icon: Wallet,
    title: "Empréstimo Consignado Servidor Público",
    description:
      "Soluções especiais para servidores públicos federais, estaduais e municipais com condições exclusivas.",
    features: ["Condições diferenciadas", "Limite pré-aprovado", "Sem burocracia"],
    mensagem: mensagensWhatsApp.consignado,
  },
  {
    icon: TrendingUp,
    title: "Refinanciamento",
    description: "Reduza suas parcelas e tenha mais dinheiro no bolso refinanciando seu empréstimo consignado.",
    features: ["Diminua suas parcelas", "Troque por taxas menores", "Processo simplificado"],
    mensagem: mensagensWhatsApp.refinanciamento,
  },
  {
    icon: Shield,
    title: "Cartão Consignado",
    description: "Cartão de crédito com limite aprovado e desconto automático no seu benefício ou salário.",
    features: ["Sem anuidade", "Limite garantido", "Aceito em todo Brasil"],
    mensagem: mensagensWhatsApp.cartaoConsignado,
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 bg-accent/30">
      <div className="container mx-auto px-4">
        {/* Título e descrição da seção - EDITE AQUI */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Soluções de Crédito para Todas as Necessidades
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Oferecemos as melhores condições do mercado com atendimento personalizado e processos transparentes.
          </p>
        </div>

        {/* Grid de serviços */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <Card key={index} className="border-2 hover:border-primary transition-all duration-300 hover:shadow-lg">
                <CardHeader>
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                    <Icon className="text-primary" size={28} />
                  </div>
                  <CardTitle className="text-xl mb-2">{service.title}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 bg-secondary rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="w-full">
                    <a href={getWhatsAppLink(service.mensagem)} target="_blank" rel="noopener noreferrer">
                      Simular Agora
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
