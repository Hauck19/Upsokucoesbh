"use client"

import Image from "next/image"
import { Building2, Users, Handshake, Award } from "lucide-react"

const fotosEmpresa = [
  {
    src: "/modern-financial-services-office-interior-with-des.jpg",
    alt: "Escritório moderno da UP Soluções",
    titulo: "Nosso Escritório",
    descricao: "Ambiente moderno e acolhedor",
    icon: Building2,
  },
  {
    src: "/diverse-professional-team-posing-together-in-offic.jpg",
    alt: "Equipe da UP Soluções",
    titulo: "Nossa Equipe",
    descricao: "Profissionais dedicados",
    icon: Users,
  },
  {
    src: "/customer-service-representative-helping-elderly-cl.jpg",
    alt: "Atendimento ao cliente",
    titulo: "Atendimento",
    descricao: "Personalizado para você",
    icon: Handshake,
  },
  {
    src: "/modern-office-reception-area-with-comfortable-seat.jpg",
    alt: "Recepção da UP Soluções",
    titulo: "Recepção",
    descricao: "Conforto e praticidade",
    icon: Award,
  },
]

export function FotosEmpresa() {
  return (
    <section className="py-16 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4">
        {/* Cabeçalho */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Building2 size={18} />
            <span>Conheça a UP Soluções</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Nossa Estrutura</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ambiente profissional e equipe especializada para oferecer o melhor atendimento.
          </p>
        </div>

        {/* Grid de fotos */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {fotosEmpresa.map((foto, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-500"
            >
              <Image
                src={foto.src || "/placeholder.svg"}
                alt={foto.alt}
                width={400}
                height={300}
                className="w-full h-48 md:h-56 object-cover group-hover:scale-110 transition-transform duration-700"
              />
              {/* Overlay com gradiente */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />

              {/* Conteúdo */}
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <div className="flex items-center gap-2 mb-1">
                  <div className="p-1.5 rounded-lg bg-white/20 backdrop-blur-sm">
                    <foto.icon className="w-4 h-4" />
                  </div>
                  <p className="font-bold text-sm md:text-base">{foto.titulo}</p>
                </div>
                <p className="text-white/70 text-xs md:text-sm">{foto.descricao}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
