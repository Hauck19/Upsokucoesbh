# INSTRUÇÕES COMPLETAS - SISTEMA DE DEPOIMENTOS

## Índice
1. [Visão Geral do Sistema](#1-visão-geral-do-sistema)
2. [Como Funciona Antes de Publicar](#2-como-funciona-antes-de-publicar)
3. [Entendendo a Publicação na Vercel](#3-entendendo-a-publicação-na-vercel)
4. [O Que Fazer Após Publicar o Site](#4-o-que-fazer-após-publicar-o-site)
5. [Como Gerenciar Depoimentos no Site Publicado](#5-como-gerenciar-depoimentos-no-site-publicado)
6. [Passo a Passo Completo de Uso](#6-passo-a-passo-completo-de-uso)
7. [Solução de Problemas](#7-solução-de-problemas)
8. [Perguntas Frequentes](#8-perguntas-frequentes)
9. [Resumo das Páginas e Componentes](#9-resumo-das-páginas-e-componentes)

---

## 1. Visão Geral do Sistema

O sistema de depoimentos tem **duas partes**:

### Página Pública (para clientes)
- **URL:** `/depoimentos`
- **O que faz:** Mostra os depoimentos aprovados e permite que clientes enviem novos depoimentos
- **Quem usa:** Seus clientes

### Painel Administrativo (para você)
- **URL:** `/admin/depoimentos`
- **O que faz:** Permite aprovar, editar e excluir depoimentos
- **Quem usa:** Você (administrador)

### Fluxo de um Depoimento

```
CLIENTE envia depoimento → Fica como "PENDENTE" → VOCÊ aprova → Aparece no site
```

---

## 2. Como Funciona Antes de Publicar

Enquanto você está testando no v0.dev:

1. **Acesse a prévia do site**
2. **Navegue para `/depoimentos`** - Você verá a página pública
3. **Navegue para `/admin/depoimentos`** - Você verá o painel de administração

Tudo funciona igual ao site publicado, só que no ambiente de teste.

---

## 3. Entendendo a Publicação na Vercel

### O Que é a Vercel?

A Vercel é a empresa que hospeda seu site na internet. Quando você clica em "Publish" no v0, seu site vai para os servidores da Vercel e fica disponível para qualquer pessoa no mundo acessar.

### Antes de Publicar (Agora)

- Você está no **modo de desenvolvimento/prévia**
- O site funciona apenas para você testar
- A URL muda toda vez que você faz alterações
- **Não é permanente** - serve apenas para testes

### Depois de Publicar

- Seu site fica **permanente** na internet
- Você recebe uma **URL fixa** que nunca muda
- Qualquer pessoa pode acessar
- Os depoimentos ficam salvos para sempre

### Como a URL Funciona

Quando você publicar, a Vercel vai criar uma URL única para você. Exemplo:

```
https://upsolucoesconsignado.vercel.app
```

Essa URL é composta por:
- `https://` - protocolo seguro (sempre igual)
- `upsolucoesconsignado` - nome do seu projeto (você escolhe)
- `.vercel.app` - domínio da Vercel (sempre igual)

### Exemplo Prático com URLs Reais

Vamos supor que ao publicar, sua URL seja `upsolucoesconsignado.vercel.app`:

| O que você quer acessar | URL Completa |
|-------------------------|--------------|
| Página inicial do site | `https://upsolucoesconsignado.vercel.app` |
| Página de Depoimentos (pública) | `https://upsolucoesconsignado.vercel.app/depoimentos` |
| Painel Admin de Depoimentos | `https://upsolucoesconsignado.vercel.app/admin/depoimentos` |
| Página Margem Extra | `https://upsolucoesconsignado.vercel.app/margem-extra` |
| Página de Serviços | `https://upsolucoesconsignado.vercel.app/servicos` |
| Página Sobre | `https://upsolucoesconsignado.vercel.app/sobre` |
| Página de Contato | `https://upsolucoesconsignado.vercel.app/contato` |

### Como Saber Sua URL Real

1. **Durante a publicação:** A Vercel mostra a URL na tela
2. **Depois de publicar:** Acesse [vercel.com/dashboard](https://vercel.com/dashboard) e clique no seu projeto
3. **Na página do projeto:** A URL aparece no topo

### Domínio Personalizado (Opcional - Para o Futuro)

Se você comprar um domínio próprio (ex: `upsolucoesconsignado.com.br`), pode conectar ao site:

1. Compre o domínio em um registrador (Registro.br, GoDaddy, etc.)
2. Acesse o painel da Vercel ([vercel.com](https://vercel.com))
3. Clique no seu projeto
4. Vá em "Settings" > "Domains"
5. Adicione seu domínio personalizado
6. Siga as instruções para configurar o DNS

Com domínio próprio, suas URLs ficariam assim:
- `https://upsolucoesconsignado.com.br/depoimentos`
- `https://upsolucoesconsignado.com.br/admin/depoimentos`

**Nota:** Isso é opcional e pode ser feito depois. O site funciona perfeitamente com a URL `.vercel.app`.

---

## 4. O Que Fazer Após Publicar o Site

### Passo 1: Publicar o Site

1. No v0.dev, clique no botão **"Publish"** (canto superior direito)
2. Se for a primeira vez, faça login com sua conta (Google, GitHub, etc.)
3. Escolha um nome para o projeto (ex: `upsolucoesconsignado`)
   - Use apenas letras minúsculas, números e hífens
   - Evite espaços e caracteres especiais
4. Clique em "Deploy" ou "Publicar"
5. Aguarde 1-2 minutos até a publicação terminar
6. **ANOTE A URL** que aparecer na tela (ex: `https://upsolucoesconsignado.vercel.app`)

### Passo 2: Anotar as URLs Importantes

Pegue a URL que você recebeu e anote estas variações:

```
URL do seu site: https://______________.vercel.app

Preencha abaixo:
- Site Principal:      https://______________.vercel.app
- Depoimentos:         https://______________.vercel.app/depoimentos
- Painel Admin:        https://______________.vercel.app/admin/depoimentos
```

### Passo 3: Salvar nos Favoritos

**MUITO IMPORTANTE:** Salve o link do painel admin nos favoritos do navegador:

1. Acesse: `https://SEU-SITE.vercel.app/admin/depoimentos`
2. Pressione `Ctrl+D` (Windows) ou `Cmd+D` (Mac)
3. Dê um nome fácil como "Admin Depoimentos UP"
4. Salve

Assim você sempre terá acesso rápido ao painel.

### Passo 4: Testar Tudo Funciona

1. **Teste a página pública:**
   - Acesse `https://SEU-SITE.vercel.app/depoimentos`
   - Preencha o formulário com um depoimento de teste
   - Clique em "Enviar"
   - Deve aparecer: "Depoimento enviado com sucesso!"

2. **Teste o painel admin:**
   - Acesse `https://SEU-SITE.vercel.app/admin/depoimentos`
   - Você deve ver o depoimento de teste como "Pendente"
   - Clique em "Aprovar"

3. **Confirme que funcionou:**
   - Volte para `https://SEU-SITE.vercel.app/depoimentos`
   - O depoimento aprovado deve aparecer na lista

Se tudo funcionou, seu sistema está pronto!

---

## 5. Como Gerenciar Depoimentos no Site Publicado

### Acessando o Painel Admin

**Toda vez que quiser gerenciar depoimentos:**

1. Abra o navegador (Chrome, Firefox, Edge, etc.)
2. Digite na barra de endereço: `https://SEU-SITE.vercel.app/admin/depoimentos`
   - Ou clique no favorito que você salvou
3. A página do painel admin vai carregar
4. Você verá todos os depoimentos listados

### O Que Você Verá no Painel Admin

```
┌─────────────────────────────────────────────────────────┐
│  Gerenciar Depoimentos                                   │
│                                                          │
│  [Todos] [Aprovados] [Pendentes]  ← Filtros              │
│                                                          │
│  ┌─────────────────────────────────────────────────────┐│
│  │ ⭐⭐⭐⭐⭐  João Silva                              ││
│  │ "Excelente atendimento, consegui meu crédito..."    ││
│  │ Status: ✅ Aprovado                                  ││
│  │ [Editar] [Reprovar] [Excluir]                       ││
│  └─────────────────────────────────────────────────────┘│
│                                                          │
│  ┌─────────────────────────────────────────────────────┐│
│  │ ⭐⭐⭐⭐  Maria Santos                              ││
│  │ "Muito bom o serviço..."                            ││
│  │ Status: ⏳ Pendente                                  ││
│  │ [Editar] [Aprovar] [Excluir]                        ││
│  └─────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

### Funções Disponíveis

#### Aprovar um Depoimento
- **Quando usar:** Quando um cliente enviar um depoimento e você quiser que apareça no site
- **Como fazer:**
  1. Encontre o depoimento com status "Pendente"
  2. Leia o conteúdo para verificar se está OK
  3. Clique no botão verde **"Aprovar"**
  4. Pronto! O depoimento agora aparece na página pública

#### Reprovar um Depoimento
- **Quando usar:** Quando quiser esconder um depoimento que já estava aprovado
- **Como fazer:**
  1. Encontre o depoimento aprovado
  2. Clique no botão **"Reprovar"**
  3. O depoimento fica oculto (mas não é excluído)
  4. Você pode aprovar novamente depois se quiser

#### Editar um Depoimento
- **Quando usar:** Para corrigir erros de digitação ou remover informações sensíveis
- **Como fazer:**
  1. Clique no botão **"Editar"** no depoimento
  2. Um formulário vai abrir
  3. Modifique o que precisar (nome, texto, estrelas)
  4. Clique em **"Salvar"**

#### Excluir um Depoimento
- **Quando usar:** Para remover permanentemente depoimentos falsos, spam ou inapropriados
- **Como fazer:**
  1. Clique no botão vermelho **"Excluir"**
  2. Confirme a exclusão
  3. **ATENÇÃO:** Não tem como recuperar depois!

### Usando os Filtros

No topo do painel, você tem três botões de filtro:

| Filtro | O que mostra |
|--------|--------------|
| **Todos** | Todos os depoimentos (aprovados + pendentes) |
| **Aprovados** | Apenas os que aparecem no site |
| **Pendentes** | Apenas os que aguardam sua aprovação |

**Dica:** Use o filtro "Pendentes" para ver rapidamente quais depoimentos novos chegaram.

---

## 6. Passo a Passo Completo de Uso

### Cenário 1: Cliente Enviou um Depoimento Novo

1. **O cliente acessa seu site** e vai em `/depoimentos`
2. **Ele preenche o formulário** e clica em enviar
3. **O depoimento fica como "Pendente"** no sistema
4. **Você acessa o painel admin:** `https://SEU-SITE.vercel.app/admin/depoimentos`
5. **Você vê o depoimento novo** com status "Pendente"
6. **Você lê o conteúdo** e decide:
   - ✅ Se estiver OK → Clica em "Aprovar"
   - ✏️ Se tiver erro → Clica em "Editar", corrige, salva, e depois "Aprovar"
   - ❌ Se for spam → Clica em "Excluir"
7. **O depoimento aprovado** aparece na página pública

### Cenário 2: Você Quer Adicionar um Depoimento de um Cliente

Às vezes um cliente elogia seu serviço por telefone ou WhatsApp. Você pode adicionar manualmente:

1. **Acesse seu site:** `https://SEU-SITE.vercel.app/depoimentos`
2. **Preencha o formulário** com o nome do cliente e o que ele disse
3. **Escolha a avaliação** em estrelas (geralmente 5 para elogios)
4. **Clique em Enviar**
5. **Vá no painel admin** e aprove o depoimento

### Cenário 3: Você Quer Esconder um Depoimento Temporariamente

1. **Acesse o painel admin**
2. **Encontre o depoimento**
3. **Clique em "Reprovar"**
4. O depoimento some da página pública mas continua salvo
5. Se quiser mostrar novamente, clique em "Aprovar"

### Cenário 4: Um Depoimento Tem Informação Errada

1. **Acesse o painel admin**
2. **Encontre o depoimento**
3. **Clique em "Editar"**
4. **Corrija** o nome, texto ou avaliação
5. **Clique em "Salvar"**
6. As alterações aparecem imediatamente no site

---

## 7. Solução de Problemas

### Problema: "Erro ao enviar depoimento"

**O que significa:** O sistema não conseguiu salvar o depoimento no banco de dados.

**Soluções:**
1. Verifique sua conexão com a internet
2. Tente novamente em 30 segundos
3. Se persistir, tente usar outro navegador
4. Se continuar, entre em contato com suporte técnico

---

### Problema: "Depoimento não aparece após aprovar"

**O que significa:** O navegador está mostrando uma versão antiga da página.

**Soluções:**
1. **Atualize a página:** Pressione `F5` ou `Ctrl+R`
2. **Atualize forçado:** Pressione `Ctrl+Shift+R` (limpa o cache)
3. **Limpe o cache:**
   - Chrome: `Ctrl+Shift+Delete` > Selecione "Imagens e arquivos em cache" > Limpar
4. Aguarde 1 minuto e tente novamente

---

### Problema: "Página admin não carrega"

**O que significa:** Problema de conexão ou URL incorreta.

**Soluções:**
1. **Verifique a URL:** Deve ser exatamente `/admin/depoimentos`
2. **Verifique a internet:** Tente abrir outro site
3. **Tente outro navegador:** Chrome, Firefox, Edge
4. **Limpe o cache:** `Ctrl+Shift+Delete`

---

### Problema: "Erro 401" ou "Row Level Security"

**O que significa:** Problema de permissão no banco de dados.

**Soluções:**
1. Esse erro foi corrigido na última atualização
2. Tente atualizar a página
3. Se aparecer novamente, pode ser necessário republicar o site
4. Entre em contato com suporte técnico

---

### Problema: "Lista de depoimentos vazia"

**O que significa:** Nenhum depoimento foi enviado ainda ou erro ao carregar.

**Soluções:**
1. **Teste enviando um depoimento:**
   - Vá em `/depoimentos`
   - Preencha e envie um teste
   - Volte ao admin
2. **Atualize a página:** `F5`
3. **Verifique os filtros:** Certifique-se que está em "Todos"

---

### Problema: "Erro ao excluir/editar depoimento"

**O que significa:** Falha na comunicação com o banco de dados.

**Soluções:**
1. Atualize a página e tente novamente
2. Verifique sua conexão com a internet
3. Tente em alguns minutos

---

### Problema: "Site não abre"

**O que significa:** O site pode estar fora do ar ou a URL está errada.

**Soluções:**
1. **Verifique a URL:** Está digitando corretamente?
2. **Acesse o painel Vercel:** [vercel.com/dashboard](https://vercel.com/dashboard)
3. **Verifique o status do projeto:** Deve estar como "Ready"
4. Se mostrar erro, pode ser necessário republicar

---

## 8. Perguntas Frequentes

### O painel admin é protegido por senha?

**Resposta:** Não atualmente. O painel é acessível por URL direta. A segurança está em manter a URL em segredo.

**Recomendação:** 
- Não compartilhe a URL do admin publicamente
- Não coloque em redes sociais
- Compartilhe apenas com pessoas de confiança

**Quer adicionar senha?** Solicite ao desenvolvedor para implementar autenticação.

---

### Posso acessar o admin pelo celular?

**Resposta:** Sim! O painel funciona em qualquer dispositivo com navegador de internet.

Basta abrir o navegador do celular e digitar a URL do admin.

---

### Os depoimentos ficam salvos onde?

**Resposta:** No **Supabase**, que é um banco de dados na nuvem.

- Seus dados estão seguros
- São feitos backups automáticos
- Os dados ficam em servidores profissionais
- Não é necessário fazer nada para manter os dados seguros

---

### Quantos depoimentos posso ter?

**Resposta:** Não há limite. Você pode ter centenas ou milhares de depoimentos.

---

### Posso ter mais de um administrador?

**Resposta:** Sim. Basta compartilhar a URL do painel admin com outra pessoa de confiança.

---

### O que acontece se eu excluir um depoimento?

**Resposta:** Ele é **removido permanentemente**. Não tem como recuperar.

**Dica:** Se não tiver certeza, use "Reprovar" em vez de "Excluir". Assim o depoimento fica escondido mas não é apagado.

---

### Preciso aprovar todos os depoimentos?

**Resposta:** Não é obrigatório, mas é recomendado. 

Depoimentos pendentes nunca aparecem na página pública. Só aparecem os que você aprovar.

---

### Os depoimentos aparecem em qual ordem?

**Resposta:** Do mais recente para o mais antigo. O último depoimento aprovado aparece primeiro.

---

### Posso mudar a quantidade de estrelas de um depoimento?

**Resposta:** Sim. Clique em "Editar" e altere a avaliação.

---

### Quanto tempo demora para um depoimento aparecer após aprovar?

**Resposta:** Imediatamente. Assim que você clicar em "Aprovar", o depoimento já aparece na página pública.

Se não aparecer, atualize a página com `F5`.

---

### O sistema notifica quando chega um depoimento novo?

**Resposta:** Não atualmente. Você precisa acessar o painel admin para verificar se há depoimentos pendentes.

**Dica:** Crie o hábito de verificar o painel uma vez por dia.

---

### Posso colocar foto no depoimento?

**Resposta:** O sistema está preparado para isso, mas atualmente os clientes não conseguem enviar foto pelo formulário. 

Se quiser adicionar esta funcionalidade, solicite ao desenvolvedor.

---

## 9. Resumo das Páginas e Componentes

### Estrutura do Site

| Página | URL | Componentes Principais |
|--------|-----|------------------------|
| Inicial | `/` | `hero-principal.tsx`, `fotos-empresa.tsx`, `mini-simulador.tsx`, `galeria-empresa.tsx` |
| Serviços | `/servicos` | `hero-servicos.tsx` (Cartão Consignado), `services.tsx` |
| Margem Extra | `/margem-extra` | `banner-margem-extra.tsx` |
| Depoimentos | `/depoimentos` | `formulario-depoimento.tsx`, `depoimentos-publicos.tsx` |
| Admin Depoimentos | `/admin/depoimentos` | Painel de gerenciamento |
| Sobre | `/sobre` | `about.tsx` |
| Contato | `/contato` | `contact.tsx` |

### Arquivos de Instruções Disponíveis

| Arquivo | Conteúdo |
|---------|----------|
| `GUIA-DE-EDICAO.md` | Como alterar textos, cores, imagens e todos os componentes do site |
| `INSTRUCOES-DEPOIMENTOS.md` | Guia completo do sistema de depoimentos (este arquivo) |

---

*Documento atualizado em: Dezembro 2025*
