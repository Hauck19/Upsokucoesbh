// Utilitário para gerar links de WhatsApp com mensagens personalizadas
const WHATSAPP_NUMBER = "5531982190475"

export function getWhatsAppLink(mensagem: string): string {
  const mensagemCodificada = encodeURIComponent(mensagem)
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${mensagemCodificada}`
}

// Mensagens padrão para cada tipo de serviço
export const mensagensWhatsApp = {
  consignado: "Olá! Gostaria de fazer uma simulação de empréstimo consignado. Podem me ajudar?",
  cartaoConsignado: "Olá! Tenho interesse no cartão consignado. Podem me dar mais informações?",
  portabilidade: "Olá! Quero fazer a portabilidade do meu empréstimo para reduzir os juros. Como funciona?",
  refinanciamento: "Olá! Gostaria de refinanciar meu empréstimo e liberar crédito extra. Podem me ajudar?",
  margemExtra: "Olá! Quero consultar se tenho direito à margem extra. Podem verificar para mim?",
  saqueSupplementar: "Olá! Tenho interesse no saque suplementar. Podem me explicar como funciona?",
  proposta: "Olá! Gostaria de solicitar uma proposta de crédito consignado.",
  simulacao: "Olá! Quero fazer uma simulação gratuita. Podem me ajudar?",
  creditoRapido: "Olá! Preciso de crédito rápido com liberação no mesmo dia. É possível?",
  duvidas: "Olá! Tenho algumas dúvidas sobre os serviços de vocês. Podem me ajudar?",
  elegibilidade: "Olá! Quero verificar minha elegibilidade para crédito consignado.",
  geral: "Olá! Gostaria de mais informações sobre os serviços da UP Soluções.",
}
