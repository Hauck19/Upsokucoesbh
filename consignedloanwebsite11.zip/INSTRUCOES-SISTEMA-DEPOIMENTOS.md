# 📋 Sistema de Depoimentos - Instruções Completas

## 🎯 O que foi criado?

Um sistema completo de depoimentos com:
- ✅ Página pública onde clientes podem deixar depoimentos
- ✅ Sistema de avaliação por estrelas (1-5) com feedback visual
- ✅ Design moderno e formal
- ✅ Painel administrativo para gerenciar depoimentos
- ✅ Banco de dados Supabase para armazenamento
- ✅ Moderação: depoimentos precisam ser aprovados antes de aparecer
- ✅ Estatísticas na página (avaliação média, clientes atendidos, satisfação)

---

## 🚀 Primeiros Passos

### 1. Executar os Scripts SQL

Antes de usar o sistema, você precisa criar as tabelas no banco de dados:

1. Execute os scripts na ordem:
   - `scripts/01-criar-tabela-depoimentos.sql` (cria tabela de depoimentos)
   - `scripts/02-criar-tabela-admin.sql` (cria tabela de administradores)

2. No v0, os scripts são executados automaticamente quando você clica no botão de executar

3. **IMPORTANTE**: Após executar, altere a senha do administrador padrão!

---

## 📱 Como Usar - Visão do Cliente

### Página Pública: `/depoimentos`

A página de depoimentos inclui:

1. **Header moderno** com estatísticas:
   - Avaliação média (4.9 estrelas)
   - +5.000 clientes atendidos
   - 98% de satisfação

2. **Seção de benefícios** explicando:
   - Depoimentos verificados
   - Moderação rápida (24h)
   - Importância da opinião do cliente

3. **Formulário de depoimento** com:
   - Campo para nome completo
   - Sistema de estrelas com hover effect
   - Feedback textual baseado na avaliação
   - Contador de caracteres
   - Mensagens de sucesso/erro visuais

4. **Lista de depoimentos aprovados** com:
   - Cards modernos com ícone de citação
   - Avatar com iniciais do cliente
   - Data formatada em português
   - Efeito hover nos cards

**URL**: `https://seusite.com/depoimentos`

---

## 🔐 Como Usar - Painel Administrativo

### Página Admin: `/admin/depoimentos`

O administrador pode:
- ✅ Ver TODOS os depoimentos (aprovados e pendentes)
- ✅ Aprovar depoimentos pendentes
- ✅ Reprovar depoimentos já aprovados
- ✅ Editar o texto de qualquer depoimento
- ✅ Excluir depoimentos permanentemente
- ✅ Filtrar por: Todos / Aprovados / Pendentes

**URL**: `https://seusite.com/admin/depoimentos`

### Ações disponíveis:

#### 1. Aprovar Depoimento
- Clique no botão verde "Aprovar"
- O depoimento aparecerá na página pública

#### 2. Reprovar Depoimento
- Clique no botão "Reprovar"
- O depoimento será ocultado da página pública

#### 3. Editar Depoimento
- Clique em "Editar"
- Modifique o texto conforme necessário
- Clique em "Salvar"
- Útil para corrigir erros ortográficos ou remover informações sensíveis

#### 4. Excluir Depoimento
- Clique em "Excluir" (botão vermelho)
- Confirme a exclusão
- **ATENÇÃO**: Esta ação é permanente e não pode ser desfeita!

---

## 🎨 Design da Página de Depoimentos

### Elementos Visuais:

1. **Header**:
   - Gradiente de primary para secondary
   - Círculos decorativos com borda
   - Badge "Avaliações Verificadas"
   - Estatísticas em 3 colunas
   - Onda SVG na parte inferior

2. **Seção de Benefícios**:
   - 3 cards com ícones
   - Fundo muted/30

3. **Formulário**:
   - Card com gradiente sutil
   - Estrelas com efeito hover e scale
   - Feedback textual dinâmico
   - Botão com gradiente e loading spinner

4. **Cards de Depoimentos**:
   - Elemento decorativo no canto
   - Ícone de citação
   - Avatar com gradiente
   - Data em português completo

---

## ⚙️ Configuração e Personalização

### Alterar estatísticas do header:

Edite o arquivo: `app/depoimentos/page.tsx`

Procure pela seção de estatísticas:
```tsx
<div className="grid grid-cols-3 gap-6 max-w-lg mx-auto">
  <div className="text-center">
    <span className="text-2xl font-bold">4.9</span>  // Altere aqui
    <p className="text-white/70 text-sm">Avaliação média</p>
  </div>
  ...
</div>
```

### Alterar feedback das estrelas:

Edite o arquivo: `components/formulario-depoimento.tsx`

Procure por:
```tsx
{avaliacao === 5 && "Excelente! Obrigado!"}
{avaliacao === 4 && "Muito bom! Agradecemos!"}
{avaliacao === 3 && "Bom! Podemos melhorar."}
{avaliacao === 2 && "Regular. Vamos melhorar!"}
{avaliacao === 1 && "Precisamos conversar..."}
```

### Modificar cores do sistema:

As cores seguem o tema global do site definido em `app/globals.css`:
- `--primary`: Cor azul principal
- `--secondary`: Cor verde secundária
- `--muted`: Cinza para fundos

---

## 🗄️ Estrutura do Banco de Dados

### Tabela: `depoimentos`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | UUID | Identificador único |
| nome_cliente | VARCHAR(255) | Nome do cliente |
| depoimento | TEXT | Texto do depoimento |
| avaliacao | INTEGER (1-5) | Nota em estrelas |
| imagem_url | TEXT | URL da imagem (opcional) |
| aprovado | BOOLEAN | Se está aprovado ou não |
| criado_em | TIMESTAMP | Data de criação |
| atualizado_em | TIMESTAMP | Data de última atualização |

### Segurança (RLS - Row Level Security)

✅ **Clientes podem:**
- Ler apenas depoimentos aprovados
- Criar novos depoimentos (que ficam pendentes)

❌ **Clientes NÃO podem:**
- Ver depoimentos pendentes de outros
- Aprovar seus próprios depoimentos
- Editar ou excluir depoimentos

✅ **Admin pode:**
- Fazer tudo via Service Role Key no backend

---

## 🔒 Segurança e Boas Práticas

### 1. Senha do Administrador

**IMPORTANTE**: O script cria um usuário admin padrão com senha fraca. Você DEVE alterar isso!

```sql
-- Execute este comando no Supabase SQL Editor:
UPDATE admin_usuarios 
SET senha_hash = 'NOVO_HASH_BCRYPT_AQUI'
WHERE email = 'admin@upsolucoes.com';
```

Para gerar hash bcrypt: use ferramentas online ou bibliotecas bcrypt

### 2. Moderação de Conteúdo

- **SEMPRE** revise depoimentos antes de aprovar
- Verifique por:
  - Linguagem inapropriada
  - Informações falsas
  - Dados pessoais sensíveis
  - Spam ou propaganda

### 3. Imagens Sensíveis

- Oriente clientes a NÃO enviar:
  - Documentos com CPF visível
  - Números de conta bancária
  - Senhas ou códigos de segurança
  - Dados de terceiros

---

## 🛠️ Solução de Problemas

### Depoimentos não aparecem na página pública

**Causa**: Depoimento não foi aprovado
**Solução**: Acesse `/admin/depoimentos` e aprove o depoimento

### Estrelas não funcionam

**Causa 1**: JavaScript desabilitado no navegador
**Solução**: Habilite JavaScript

**Causa 2**: Erro no componente
**Solução**: Verifique o console do navegador (F12) para erros

### Não consigo acessar painel admin

**Causa**: Sistema de autenticação não implementado nesta versão
**Solução**: O painel está aberto. Para adicionar autenticação, você precisa implementar login com Supabase Auth

### Depoimentos desapareceram

**Causa**: Foram excluídos permanentemente
**Solução**: Não há recuperação. Faça backups regulares do banco de dados

### Loading infinito ao carregar depoimentos

**Causa**: Erro de conexão com o banco de dados
**Solução**: 
1. Verifique se o Supabase está configurado corretamente
2. Verifique as variáveis de ambiente
3. Verifique os logs da API

---

## 📊 Monitoramento e Análises

### Estatísticas úteis para acompanhar:

1. **Total de depoimentos**: Todos / Aprovados / Pendentes
2. **Média de avaliação**: Calcule a média das estrelas
3. **Taxa de aprovação**: % de depoimentos aprovados
4. **Depoimentos por período**: Quantos por semana/mês

### Consultas SQL úteis:

```sql
-- Média de avaliação
SELECT AVG(avaliacao) FROM depoimentos WHERE aprovado = true;

-- Total de depoimentos pendentes
SELECT COUNT(*) FROM depoimentos WHERE aprovado = false;

-- Depoimentos dos últimos 7 dias
SELECT * FROM depoimentos 
WHERE criado_em > NOW() - INTERVAL '7 days'
ORDER BY criado_em DESC;

-- Distribuição de avaliações
SELECT avaliacao, COUNT(*) as total 
FROM depoimentos 
WHERE aprovado = true 
GROUP BY avaliacao 
ORDER BY avaliacao DESC;
```

---

## 📧 Suporte

Se precisar de ajuda:
1. Verifique os logs de erro no console do navegador (F12)
2. Revise os arquivos de API em `app/api/depoimentos/`
3. Consulte a documentação do Supabase: https://supabase.com/docs

---

## ✨ Recursos Implementados

- [x] Página pública de depoimentos moderna
- [x] Sistema de avaliação por estrelas com hover
- [x] Feedback visual baseado na avaliação
- [x] Cards de depoimentos com design profissional
- [x] Estatísticas no header
- [x] Seção de benefícios
- [x] Formulário com validação
- [x] Loading states e mensagens de erro
- [x] Responsivo para mobile
- [x] Tema claro/escuro

## 🚀 Próximos Passos (Melhorias Futuras)

Sugestões de recursos para adicionar:

- [ ] Sistema de login para painel admin
- [ ] Notificações por email quando novo depoimento chegar
- [ ] Responder depoimentos (comentários do admin)
- [ ] Destacar depoimentos em destaque na home
- [ ] Filtrar depoimentos por estrelas
- [ ] Estatísticas e dashboard de analytics
- [ ] Exportar depoimentos para PDF/Excel
- [ ] Sistema de denúncia de depoimentos falsos
- [ ] Paginação para muitos depoimentos

---

## 📍 Arquivos Importantes

### Páginas e Componentes:
- `app/depoimentos/page.tsx` - Página pública de depoimentos
- `components/depoimentos-publicos.tsx` - Lista de depoimentos aprovados
- `components/formulario-depoimento.tsx` - Formulário para enviar depoimento
- `app/admin/depoimentos/page.tsx` - Painel administrativo

### Outros Componentes Atualizados:
- `components/cartao-banner.tsx` - Banner chamativo da página de serviços com botão "Simular Agora Grátis"
- `components/contact.tsx` - Página de contato com imagem abaixo do formulário "Solicite uma Proposta"
- `components/banner-margem-extra.tsx` - Banner moderno da página Margem Extra

### APIs:
- `app/api/depoimentos/route.ts` - GET (listar) e POST (criar) depoimentos
- `app/api/depoimentos/[id]/route.ts` - PUT (atualizar) e DELETE (excluir)
- `app/api/admin/depoimentos/route.ts` - Listar todos (admin)

---

## 🎨 Outros Banners do Site

### Banner de Serviços (Página Soluções)
**Arquivo:** `components/cartao-banner.tsx`

Design chamativo com:
- Gradiente azul vibrante
- Animações flutuantes
- Badge "Simulação 100% Gratuita"
- Destaque de taxas
- Botão amarelo "SIMULAR AGORA GRÁTIS"
- Imagem ilustrativa com efeitos
- Card "Aprovado!" animado

### Página de Contato
**Arquivo:** `components/contact.tsx`

Inclui imagem abaixo do formulário "Solicite uma Proposta" com:
- Foto da equipe atendendo cliente
- Overlay com gradiente
- Texto "Atendimento Personalizado"

---

**Criado para UP Soluções - Empréstimo Consignado**
*Sistema completo de gerenciamento de depoimentos com moderação*

**Última atualização:** Dezembro 2024
