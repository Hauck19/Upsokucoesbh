import { Header } from "@/components/header"
import { About } from "@/components/about"
import { Footer } from "@/components/footer"
import { SecaoConfianca } from "@/components/secao-confianca"

export default function SobrePage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-20">
        <About />
        <SecaoConfianca />
      </div>
      <Footer />
    </main>
  )
}
