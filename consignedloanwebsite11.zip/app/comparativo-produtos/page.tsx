import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ComparativoProdutos } from "@/components/comparativo-produtos"

export const metadata = {
  title: "Comparativo de Produtos - UP Soluções",
  description:
    "Compare todos os tipos de crédito consignado: empréstimo, cartão, portabilidade, refinanciamento e saque suplementar.",
}

export default function ComparativoProdutosPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        <ComparativoProdutos />
      </main>
      <Footer />
    </>
  )
}
