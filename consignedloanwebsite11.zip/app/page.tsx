import { Header } from "@/components/header"
import { HeroPrincipal } from "@/components/hero-principal"
import { FotosEmpresa } from "@/components/fotos-empresa"
import { MiniSimulador } from "@/components/mini-simulador"
import { BannerRefinanciamento } from "@/components/banner-refinanciamento"
import { GaleriaEmpresa } from "@/components/galeria-empresa"
import { QuizRapido } from "@/components/quiz-rapido"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroPrincipal />
      <FotosEmpresa />
      <QuizRapido />
      <MiniSimulador />
      <BannerRefinanciamento />
      <GaleriaEmpresa />
      <Footer />
    </main>
  )
}
