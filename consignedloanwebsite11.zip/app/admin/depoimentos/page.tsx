"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, Check, X, Edit2, Trash2 } from "lucide-react"

interface Depoimento {
  id: string
  nome_cliente: string
  depoimento: string
  avaliacao: number
  imagem_url?: string
  aprovado: boolean
  criado_em: string
}

export default function AdminDepoimentos() {
  const [depoimentos, setDepoimentos] = useState<Depoimento[]>([])
  const [carregando, setCarregando] = useState(true)
  const [filtro, setFiltro] = useState<"todos" | "aprovados" | "pendentes">("todos")
  const [editando, setEditando] = useState<string | null>(null)
  const [textoEditado, setTextoEditado] = useState("")

  useEffect(() => {
    carregarDepoimentos()
  }, [])

  const carregarDepoimentos = async () => {
    try {
      const response = await fetch("/api/admin/depoimentos")
      if (response.ok) {
        const data = await response.json()
        setDepoimentos(data)
      }
    } catch (error) {
      console.error("[v0] Erro ao carregar depoimentos:", error)
    } finally {
      setCarregando(false)
    }
  }

  const aprovarDepoimento = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/depoimentos/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aprovado: true }),
      })

      if (response.ok) {
        carregarDepoimentos()
      }
    } catch (error) {
      console.error("[v0] Erro ao aprovar:", error)
    }
  }

  const reprovarDepoimento = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/depoimentos/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aprovado: false }),
      })

      if (response.ok) {
        carregarDepoimentos()
      }
    } catch (error) {
      console.error("[v0] Erro ao reprovar:", error)
    }
  }

  const excluirDepoimento = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este depoimento?")) return

    try {
      const response = await fetch(`/api/admin/depoimentos/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        carregarDepoimentos()
      }
    } catch (error) {
      console.error("[v0] Erro ao excluir:", error)
    }
  }

  const iniciarEdicao = (id: string, texto: string) => {
    setEditando(id)
    setTextoEditado(texto)
  }

  const salvarEdicao = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/depoimentos/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ depoimento: textoEditado }),
      })

      if (response.ok) {
        setEditando(null)
        carregarDepoimentos()
      }
    } catch (error) {
      console.error("[v0] Erro ao editar:", error)
    }
  }

  const depoimentosFiltrados = depoimentos.filter((dep) => {
    if (filtro === "aprovados") return dep.aprovado
    if (filtro === "pendentes") return !dep.aprovado
    return true
  })

  if (carregando) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted/30 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8">Gerenciar Depoimentos</h1>

        {/* Filtros */}
        <div className="flex gap-4 mb-8">
          <Button onClick={() => setFiltro("todos")} variant={filtro === "todos" ? "default" : "outline"}>
            Todos ({depoimentos.length})
          </Button>
          <Button onClick={() => setFiltro("aprovados")} variant={filtro === "aprovados" ? "default" : "outline"}>
            Aprovados ({depoimentos.filter((d) => d.aprovado).length})
          </Button>
          <Button onClick={() => setFiltro("pendentes")} variant={filtro === "pendentes" ? "default" : "outline"}>
            Pendentes ({depoimentos.filter((d) => !d.aprovado).length})
          </Button>
        </div>

        {/* Lista de depoimentos */}
        <div className="grid gap-6">
          {depoimentosFiltrados.map((dep) => (
            <Card key={dep.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-bold text-lg">{dep.nome_cliente}</h3>
                  <p className="text-sm text-muted-foreground">{new Date(dep.criado_em).toLocaleString("pt-BR")}</p>
                  <div className="flex gap-1 mt-2">
                    {[1, 2, 3, 4, 5].map((estrela) => (
                      <Star
                        key={estrela}
                        className={`w-4 h-4 ${
                          estrela <= dep.avaliacao ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                </div>

                <div
                  className={`px-3 py-1 rounded-full text-sm ${
                    dep.aprovado ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                  }`}
                >
                  {dep.aprovado ? "Aprovado" : "Pendente"}
                </div>
              </div>

              {/* Depoimento (editável) */}
              <div className="mb-4">
                {editando === dep.id ? (
                  <div>
                    <textarea
                      value={textoEditado}
                      onChange={(e) => setTextoEditado(e.target.value)}
                      className="w-full p-3 border rounded-lg"
                      rows={4}
                    />
                    <div className="flex gap-2 mt-2">
                      <Button onClick={() => salvarEdicao(dep.id)} size="sm">
                        Salvar
                      </Button>
                      <Button onClick={() => setEditando(null)} variant="outline" size="sm">
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-muted-foreground">{dep.depoimento}</p>
                )}
              </div>

              {/* Ações */}
              <div className="flex gap-2 flex-wrap">
                {!dep.aprovado && (
                  <Button
                    onClick={() => aprovarDepoimento(dep.id)}
                    size="sm"
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Aprovar
                  </Button>
                )}

                {dep.aprovado && (
                  <Button onClick={() => reprovarDepoimento(dep.id)} size="sm" variant="outline">
                    <X className="w-4 h-4 mr-2" />
                    Reprovar
                  </Button>
                )}

                <Button onClick={() => iniciarEdicao(dep.id, dep.depoimento)} size="sm" variant="outline">
                  <Edit2 className="w-4 h-4 mr-2" />
                  Editar
                </Button>

                <Button onClick={() => excluirDepoimento(dep.id)} size="sm" variant="destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Excluir
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {depoimentosFiltrados.length === 0 && (
          <p className="text-center text-muted-foreground py-8">Nenhum depoimento encontrado com este filtro.</p>
        )}
      </div>
    </div>
  )
}
