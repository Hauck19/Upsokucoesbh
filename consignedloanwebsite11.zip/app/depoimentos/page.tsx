import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { DepoimentosPublicos } from "@/components/depoimentos-publicos"
import { FormularioDepoimento } from "@/components/formulario-depoimento"
import { Star, MessageSquare, Shield, Clock } from "lucide-react"

export const metadata = {
  title: "Depoimentos | UP Soluções - Crédito Consignado",
  description:
    "Veja o que nossos clientes estão dizendo sobre a UP Soluções. Depoimentos reais de clientes satisfeitos.",
}

export default function DepoimentosPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-background pt-20">
        <section className="relative py-20 overflow-hidden">
          {/* Background gradiente */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-secondary" />

          {/* Padrão decorativo */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 w-32 h-32 border-2 border-white rounded-full" />
            <div className="absolute bottom-10 right-10 w-48 h-48 border-2 border-white rounded-full" />
            <div className="absolute top-1/2 left-1/3 w-24 h-24 border-2 border-white rounded-full" />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center text-white">
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-6 border border-white/20">
                <MessageSquare size={16} />
                Avaliações Verificadas
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
                O Que Nossos Clientes Dizem
              </h1>

              <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
                A confiança de nossos clientes é o nosso maior patrimônio. Confira depoimentos reais de quem já realizou
                seus sonhos com a UP Soluções.
              </p>

              {/* Estatísticas */}
              <div className="grid grid-cols-3 gap-6 max-w-lg mx-auto">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-2xl font-bold">4.9</span>
                  </div>
                  <p className="text-white/70 text-sm">Avaliação média</p>
                </div>
                <div className="text-center border-x border-white/20">
                  <p className="text-2xl font-bold mb-1">+5.000</p>
                  <p className="text-white/70 text-sm">Clientes atendidos</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold mb-1">98%</p>
                  <p className="text-white/70 text-sm">Satisfação</p>
                </div>
              </div>
            </div>
          </div>

          {/* Onda decorativa */}
          <div className="absolute bottom-0 left-0 right-0">
            <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-12 fill-background">
              <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" />
            </svg>
          </div>
        </section>

        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Depoimentos Reais</h3>
                  <p className="text-sm text-muted-foreground">
                    Todos os depoimentos são verificados pela nossa equipe
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="text-secondary" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Moderação Rápida</h3>
                  <p className="text-sm text-muted-foreground">Seu depoimento é analisado em até 24 horas</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Star className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Sua Opinião Importa</h3>
                  <p className="text-sm text-muted-foreground">Ajude outros clientes a conhecer nosso trabalho</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Formulário para novo depoimento */}
        <FormularioDepoimento />

        {/* Depoimentos aprovados */}
        <DepoimentosPublicos />
      </main>
      <Footer />
    </>
  )
}
