import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FaqSection } from "@/components/faq-section"

export const metadata = {
  title: "Perguntas Frequentes - UP Soluções",
  description: "Tire suas dúvidas sobre empréstimo consignado. Saiba sobre prazos, documentação, taxas e muito mais.",
}

export default function FaqPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        <FaqSection />
      </main>
      <Footer />
    </>
  )
}
