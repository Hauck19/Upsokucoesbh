import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BannerMargemExtra } from "@/components/banner-margem-extra"
import { SecaoMargemExtra } from "@/components/secao-margem-extra"
import { VerificadorMargem } from "@/components/verificador-margem"

export const metadata = {
  title: "Margem Extra | UP Soluções - Crédito Consignado",
  description:
    "Descubra se você tem direito à margem extra. Crédito adicional para aposentados, pensionistas e servidores públicos com as melhores taxas.",
}

export default function MargemExtraPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-20">
        <BannerMargemExtra />
        <VerificadorMargem />
        <SecaoMargemExtra />
      </div>
      <Footer />
    </main>
  )
}
