import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

// Função para criar cliente Supabase com chave de serviço (admin)
function getSupabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

// GET - Listar TODOS os depoimentos (aprovados e pendentes)
export async function GET() {
  try {
    const supabase = getSupabaseAdmin()

    const { data, error } = await supabase.from("depoimentos").select("*").order("criado_em", { ascending: false })

    if (error) {
      console.error("[v0] Erro ao buscar depoimentos:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Erro no GET admin depoimentos:", error)
    return NextResponse.json({ error: "Erro ao buscar depoimentos" }, { status: 500 })
  }
}
