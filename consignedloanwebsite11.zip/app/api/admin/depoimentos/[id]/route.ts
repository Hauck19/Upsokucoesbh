import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

function getSupabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

// PATCH - Atualizar depoimento (aprovar/reprovar/editar)
export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = getSupabaseAdmin()
    const body = await request.json()

    const { data, error } = await supabase.from("depoimentos").update(body).eq("id", id).select().single()

    if (error) {
      console.error("[v0] Erro ao atualizar depoimento:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Erro no PATCH depoimento:", error)
    return NextResponse.json({ error: "Erro ao atualizar depoimento" }, { status: 500 })
  }
}

// DELETE - Excluir depoimento
export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = getSupabaseAdmin()

    const { error } = await supabase.from("depoimentos").delete().eq("id", id)

    if (error) {
      console.error("[v0] Erro ao excluir depoimento:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Erro no DELETE depoimento:", error)
    return NextResponse.json({ error: "Erro ao excluir depoimento" }, { status: 500 })
  }
}
