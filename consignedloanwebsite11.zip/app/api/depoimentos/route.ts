import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

function getSupabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

// GET - Listar depoimentos aprovados
export async function GET() {
  try {
    const supabase = getSupabaseAdmin()

    const { data, error } = await supabase
      .from("depoimentos")
      .select("*")
      .eq("aprovado", true)
      .order("criado_em", { ascending: false })

    if (error) {
      console.error("[v0] Erro ao buscar depoimentos:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Erro no GET depoimentos:", error)
    return NextResponse.json({ error: "Erro ao buscar depoimentos" }, { status: 500 })
  }
}

// POST - Criar novo depoimento
export async function POST(request: Request) {
  try {
    const supabase = getSupabaseAdmin()
    const body = await request.json()

    const { nome_cliente, depoimento, avaliacao, imagem_url } = body

    // Validações
    if (!nome_cliente || !depoimento || !avaliacao) {
      return NextResponse.json({ error: "Campos obrigatórios faltando" }, { status: 400 })
    }

    if (avaliacao < 1 || avaliacao > 5) {
      return NextResponse.json({ error: "Avaliação deve ser entre 1 e 5" }, { status: 400 })
    }

    const { data, error } = await supabase
      .from("depoimentos")
      .insert([
        {
          nome_cliente,
          depoimento,
          avaliacao,
          imagem_url: imagem_url || null,
          aprovado: false, // Não aprovado por padrão
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("[v0] Erro ao criar depoimento:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    console.error("[v0] Erro no POST depoimentos:", error)
    return NextResponse.json({ error: "Erro ao criar depoimento" }, { status: 500 })
  }
}
