import { Header } from "@/components/header"
import { GuiasEducacionais } from "@/components/guias-educacionais"
import { Footer } from "@/components/footer"

export const metadata = {
  title: "Guias Educacionais | UP Soluções - Aprenda Sobre Crédito Consignado",
  description:
    "Aprenda tudo sobre empréstimo consignado: margem, portabilidade, como evitar golpes e muito mais. Conteúdo educacional gratuito.",
}

export default function GuiasPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-20">
        <GuiasEducacionais />
      </div>
      <Footer />
    </main>
  )
}
