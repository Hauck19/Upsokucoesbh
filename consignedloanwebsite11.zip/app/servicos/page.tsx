import { Header } from "@/components/header"
import { Services } from "@/components/services"
import { Footer } from "@/components/footer"
import { DocumentosNecessarios } from "@/components/documentos-necessarios"
import { BannerPortabilidade } from "@/components/banner-portabilidade"
import { SecaoPortabilidade } from "@/components/secao-portabilidade"
import { QuemPodeContratar } from "@/components/quem-pode-contratar"
import { HeroServicos } from "@/components/hero-servicos"

export default function ServicosPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-20">
        <HeroServicos />
        <Services />
        <QuemPodeContratar />
        <BannerPortabilidade />
        <SecaoPortabilidade />
        <DocumentosNecessarios />
      </div>
      <Footer />
    </main>
  )
}
