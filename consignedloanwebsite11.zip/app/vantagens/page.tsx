import { Header } from "@/components/header"
import { Benefits } from "@/components/benefits"
import { Diferenciais } from "@/components/diferenciais"
import { BannerLiberacaoRapida } from "@/components/banner-liberacao-rapida"
import { ComparadorOfertas } from "@/components/comparador-ofertas"
import { LinhaTempoProcesso } from "@/components/linha-tempo-processo"
import { Footer } from "@/components/footer"

export default function VantagensPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-20">
        <BannerLiberacaoRapida />
        <Benefits />
        <ComparadorOfertas />
        <LinhaTempoProcesso />
        <Diferenciais />
      </div>
      <Footer />
    </main>
  )
}
