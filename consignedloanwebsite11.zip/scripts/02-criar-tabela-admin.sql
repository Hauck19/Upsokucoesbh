-- Criar tabela de administradores
CREATE TABLE IF NOT EXISTS admin_usuarios (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  senha_hash TEXT NOT NULL,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Inserir usuário admin padrão (senha: admin123 - IMPORTANTE: ALTERAR DEPOIS!)
-- Hash bcrypt para "admin123"
INSERT INTO admin_usuarios (email, senha_hash) 
VALUES ('admin@upsolucoes.com', '$2a$10$rKvDmXJbhYWZk5eZlXk5XeEXAMPLEHASHPLEASECHANGE')
ON CONFLICT (email) DO NOTHING;

-- Habilitar RLS
ALTER TABLE admin_usuarios ENABLE ROW LEVEL SECURITY;

-- Apenas administradores podem ler esta tabela (será controlado no backend)
CREATE POLICY "Apenas via backend" ON admin_usuarios
  FOR ALL
  USING (false);
