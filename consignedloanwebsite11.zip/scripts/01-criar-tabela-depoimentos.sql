-- Criar tabela de depoimentos
CREATE TABLE IF NOT EXISTS depoimentos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome_cliente VARCHAR(255) NOT NULL,
  depoimento TEXT NOT NULL,
  avaliacao INTEGER CHECK (avaliacao >= 1 AND avaliacao <= 5) NOT NULL,
  imagem_url TEXT,
  aprovado BOOLEAN DEFAULT false,
  criado_em TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Criar índice para buscar depoimentos aprovados
CREATE INDEX IF NOT EXISTS idx_depoimentos_aprovado ON depoimentos(aprovado);

-- Criar índice para ordenar por data
CREATE INDEX IF NOT EXISTS idx_depoimentos_criado_em ON depoimentos(criado_em DESC);

-- Habilitar RLS (Row Level Security)
ALTER TABLE depoimentos ENABLE ROW LEVEL SECURITY;

-- Política para permitir que qualquer pessoa leia depoimentos aprovados
CREATE POLICY "Qualquer um pode ler depoimentos aprovados" ON depoimentos
  FOR SELECT
  USING (aprovado = true);

-- Política para permitir que qualquer pessoa insira novos depoimentos (não aprovados)
CREATE POLICY "Qualquer um pode inserir depoimentos" ON depoimentos
  FOR INSERT
  WITH CHECK (aprovado = false);
